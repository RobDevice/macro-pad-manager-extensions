use std::io::{self, BufRead};

use serde::{Deserialize, Serialize};
use serde_json::Value;
use simconnect::proto::codec::PacketReader;
use simconnect::proto::enums::{DataRequestFlags, DataSetFlags, DataType, EventFlags, Period, RecvId};
use simconnect::proto::recv;
use simconnect::SimConnect;
use tokio::time::{timeout, Duration};

#[derive(Deserialize)]
#[serde(tag = "operation", rename_all = "snake_case")]
enum Request {
    Probe { address: String },
    KeyEvent { address: String, event: String, parameter: Option<i32> },
    ReadSimvar { address: String, simvar: String, unit: Option<String>, index: Option<u32>, data_type: Option<String> },
    SetSimvar { address: String, simvar: String, unit: Option<String>, index: Option<u32>, data_type: Option<String>, value: Value },
}

#[derive(Serialize)]
struct Response {
    ok: bool,
    error: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    value: Option<Value>,
}

fn address_parts(address: &str) -> Result<(&str, u16), String> {
    address.rsplit_once(':')
        .ok_or_else(|| "SimConnect address must use host:port".to_owned())
        .and_then(|(host, port)| port.parse::<u16>().map(|port| (host, port)).map_err(|_| "SimConnect port must be a number".to_owned()))
}

fn datum_name(simvar: &str, index: Option<u32>) -> String {
    if simvar.contains(':') || index.unwrap_or(0) == 0 {
        simvar.to_owned()
    } else {
        format!("{}:{}", simvar, index.unwrap_or(0))
    }
}

fn datum_type(data_type: Option<&str>) -> DataType {
    match data_type.unwrap_or("number").to_ascii_lowercase().as_str() {
        "boolean" | "bool" | "integer" | "int" => DataType::Int32,
        "string" => DataType::String256,
        _ => DataType::Float64,
    }
}

fn decode_value(data: &[u8], data_type: DataType) -> Result<Value, String> {
    match data_type {
        DataType::Int32 => data.get(..4)
            .and_then(|bytes| bytes.try_into().ok())
            .map(|bytes| Value::from(i32::from_le_bytes(bytes)))
            .ok_or_else(|| "SimConnect returned an incomplete integer value".to_owned()),
        DataType::Float64 => data.get(..8)
            .and_then(|bytes| bytes.try_into().ok())
            .map(|bytes| Value::from(f64::from_le_bytes(bytes)))
            .ok_or_else(|| "SimConnect returned an incomplete numeric value".to_owned()),
        DataType::String256 => {
            let end = data.iter().position(|byte| *byte == 0).unwrap_or(data.len());
            Ok(Value::from(String::from_utf8_lossy(&data[..end]).trim().to_owned()))
        }
        _ => Err("Unsupported SimConnect data type".to_owned()),
    }
}

fn encode_value(value: Value, data_type: DataType) -> Result<Vec<u8>, String> {
    match data_type {
        DataType::Int32 => {
            let number = value.as_i64().or_else(|| value.as_bool().map(|item| if item { 1 } else { 0 }))
                .ok_or_else(|| "This SimVar needs a whole-number value".to_owned())?;
            Ok((number as i32).to_le_bytes().to_vec())
        }
        DataType::Float64 => value.as_f64()
            .map(|number| number.to_le_bytes().to_vec())
            .ok_or_else(|| "This SimVar needs a numeric value".to_owned()),
        DataType::String256 => {
            let text = value.as_str().ok_or_else(|| "This SimVar needs text".to_owned())?;
            let mut bytes = vec![0; 256];
            let raw = text.as_bytes();
            let length = raw.len().min(255);
            bytes[..length].copy_from_slice(&raw[..length]);
            Ok(bytes)
        }
        _ => Err("Unsupported SimConnect data type".to_owned()),
    }
}

async fn handle(request: Request) -> Result<Option<Value>, String> {
    match request {
        Request::Probe { address } => {
            let (host, port) = address_parts(&address)?;
            SimConnect::open_tcp("macro-pad-manager-msfs", host, port)
                .await
                .map_err(|error| error.to_string())?;
            Ok(None)
        }
        Request::KeyEvent { address, event, parameter } => {
            let (host, port) = address_parts(&address)?;
            let sim = SimConnect::open_tcp("macro-pad-manager-msfs", host, port)
                .await
                .map_err(|error| error.to_string())?;
            const EVENT_ID: u32 = 1;
            sim.map_client_event_to_sim_event(EVENT_ID, &event)
                .await
                .map_err(|error| error.to_string())?;
            sim.transmit_client_event(0, EVENT_ID, parameter.unwrap_or(0), 0, EventFlags::empty())
                .await
                .map_err(|error| error.to_string())?;
            Ok(None)
        }
        Request::ReadSimvar { address, simvar, unit, index, data_type } => {
            let (host, port) = address_parts(&address)?;
            let sim = SimConnect::open_tcp("macro-pad-manager-msfs", host, port)
                .await
                .map_err(|error| error.to_string())?;
            const DEFINE_ID: u32 = 10;
            const REQUEST_ID: u32 = 11;
            let data_type = datum_type(data_type.as_deref());
            sim.add_to_data_definition(DEFINE_ID, &datum_name(&simvar, index), unit.as_deref(), data_type, 0.0, -1)
                .await
                .map_err(|error| error.to_string())?;
            sim.request_data_on_sim_object(REQUEST_ID, DEFINE_ID, 0, Period::Once, DataRequestFlags::empty(), 0, 0, 0)
                .await
                .map_err(|error| error.to_string())?;
            loop {
                let packet = timeout(Duration::from_secs(2), sim.recv()).await
                    .map_err(|_| "Timed out waiting for SimConnect data".to_owned())?
                    .map_err(|error| error.to_string())?;
                let mut reader = PacketReader::new(&packet);
                let header = reader.header().map_err(|error| error.to_string())?;
                if header.id == RecvId::SimObjectData as u32 {
                    let data = recv::parse_sim_object_data(&mut reader).map_err(|error| error.to_string())?;
                    if data.request_id == REQUEST_ID {
                        return decode_value(data.data, data_type).map(Some);
                    }
                }
                if header.id == RecvId::Exception as u32 {
                    let exception = recv::parse_exception(&mut reader).map_err(|error| error.to_string())?;
                    if exception.matches(REQUEST_ID) {
                        return Err(format!("SimConnect rejected the requested SimVar: {exception:?}"));
                    }
                }
            }
        }
        Request::SetSimvar { address, simvar, unit, index, data_type, value } => {
            let (host, port) = address_parts(&address)?;
            let sim = SimConnect::open_tcp("macro-pad-manager-msfs", host, port)
                .await
                .map_err(|error| error.to_string())?;
            const DEFINE_ID: u32 = 20;
            let data_type = datum_type(data_type.as_deref());
            sim.add_to_data_definition(DEFINE_ID, &datum_name(&simvar, index), unit.as_deref(), data_type, 0.0, -1)
                .await
                .map_err(|error| error.to_string())?;
            let bytes = encode_value(value, data_type)?;
            sim.set_data_on_sim_object(DEFINE_ID, 0, DataSetFlags::empty(), 0, bytes.len() as u32, &bytes)
                .await
                .map_err(|error| error.to_string())?;
            Ok(None)
        }
    }
}

#[tokio::main(flavor = "current_thread")]
async fn main() {
    for line in io::stdin().lock().lines() {
        let response = match line {
            Ok(line) => match serde_json::from_str::<Request>(&line) {
                Ok(request) => match handle(request).await {
                    Ok(value) => Response { ok: true, error: None, value },
                    Err(error) => Response { ok: false, error: Some(error), value: None },
                },
                Err(error) => Response { ok: false, error: Some(error.to_string()), value: None },
            },
            Err(error) => Response { ok: false, error: Some(error.to_string()), value: None },
        };
        println!("{}", serde_json::to_string(&response).expect("response is serializable"));
    }
}
