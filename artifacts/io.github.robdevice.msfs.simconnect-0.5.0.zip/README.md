# macro-pad-manager-msfs-simconnect-
# Macro Pad Manager MSFS SimConnect

Macro Pad Manager feature pack for Microsoft Flight Simulator 2020 through
SimConnect. It contributes standard SimVars as inputs and standard Key Events
plus writable SimVars as actions. It intentionally excludes aircraft-specific
L:Vars, H: events, and dynamic Input Events in the first release.

The extension defaults to `127.0.0.1:500`. Configure another endpoint in the
extension's settings when SimConnect is exposed on a different host or port.

## Refreshing the official catalogue

```bash
python3 tools/import_msfs_catalogue.py
```

## Packaging

```bash
python3 scripts/package_extension.py ../extensions-repo/artifacts
```

Commit the resulting ZIP and matching catalogue entry to the distribution-only
`macro-pad-manager-extensions` repository.
