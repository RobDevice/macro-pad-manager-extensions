from __future__ import annotations

import copy
from functools import lru_cache
from io import BytesIO
import json
import math
import os
from pathlib import Path
import platform
import stat
import subprocess
import threading
import time

from PIL import Image, ImageColor, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]


DIAL_CONTROLS: dict[str, dict[str, str | int]] = {
    "Autopilot Altitude": {"left": "AP_ALT_VAR_DEC", "right": "AP_ALT_VAR_INC", "parameter": 1},
    "Heading Bug": {"left": "HEADING_BUG_DEC", "right": "HEADING_BUG_INC", "press": "heading_sync"},
    "Autopilot Vertical Speed": {"left": "AP_VS_VAR_DEC", "right": "AP_VS_VAR_INC"},
    "Autopilot Airspeed": {"left": "AP_SPD_VAR_DEC", "right": "AP_SPD_VAR_INC"},
    "COM 1 Fine Frequency": {"left": "COM1_RADIO_FRACT_DEC", "right": "COM1_RADIO_FRACT_INC"},
    "COM 1 Coarse Frequency": {"left": "COM1_RADIO_WHOLE_DEC", "right": "COM1_RADIO_WHOLE_INC"},
    "COM 2 Fine Frequency": {"left": "COM2_RADIO_FRACT_DEC", "right": "COM2_RADIO_FRACT_INC"},
    "COM 2 Coarse Frequency": {"left": "COM2_RADIO_WHOLE_DEC", "right": "COM2_RADIO_WHOLE_INC"},
    "NAV 1 Fine Frequency": {"left": "NAV1_RADIO_FRACT_DEC", "right": "NAV1_RADIO_FRACT_INC"},
    "NAV 1 Coarse Frequency": {"left": "NAV1_RADIO_WHOLE_DEC", "right": "NAV1_RADIO_WHOLE_INC"},
    "NAV 2 Fine Frequency": {"left": "NAV2_RADIO_FRACT_DEC", "right": "NAV2_RADIO_FRACT_INC"},
    "NAV 2 Coarse Frequency": {"left": "NAV2_RADIO_WHOLE_DEC", "right": "NAV2_RADIO_WHOLE_INC"},
    "NAV 1 Course": {"left": "VOR1_OBI_DEC", "right": "VOR1_OBI_INC"},
    "NAV 1 Course (10 degrees)": {"left": "VOR1_OBI_FAST_DEC", "right": "VOR1_OBI_FAST_INC"},
    "NAV 2 Course": {"left": "VOR2_OBI_DEC", "right": "VOR2_OBI_INC"},
    "NAV 2 Course (10 degrees)": {"left": "VOR2_OBI_FAST_DEC", "right": "VOR2_OBI_FAST_INC"},
    "Transponder Digit 1": {"left": "XPNDR_1000_DEC", "right": "XPNDR_1000_INC"},
    "Transponder Digit 2": {"left": "XPNDR_100_DEC", "right": "XPNDR_100_INC"},
    "Transponder Digit 3": {"left": "XPNDR_10_DEC", "right": "XPNDR_10_INC"},
    "Transponder Digit 4": {"left": "XPNDR_1_DEC", "right": "XPNDR_1_INC"},
    "Altimeter Pressure": {"left": "KOHLSMAN_DEC", "right": "KOHLSMAN_INC"},
    "G1000 PFD Page": {"left": "G1000_PFD_PAGE_KNOB_DEC", "right": "G1000_PFD_PAGE_KNOB_INC", "press": "G1000_PFD_CURSOR_BUTTON"},
    "G1000 PFD Page Group": {"left": "G1000_PFD_GROUP_KNOB_DEC", "right": "G1000_PFD_GROUP_KNOB_INC", "press": "G1000_PFD_CURSOR_BUTTON"},
}


class _HelperBridge:
    """Keep the helper process alive while a profile polls SimConnect values."""

    def __init__(self) -> None:
        self._process: subprocess.Popen[str] | None = None
        self._lock = threading.Lock()

    def request(self, helper: Path, payload: dict) -> dict:
        with self._lock:
            if self._process is None or self._process.poll() is not None:
                self._process = subprocess.Popen(
                    [str(helper)], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                    text=True, bufsize=1,
                )
            if self._process.stdin is None or self._process.stdout is None:
                return {"ok": False, "error": "SimConnect helper streams are unavailable"}
            try:
                self._process.stdin.write(json.dumps(payload) + "\n")
                self._process.stdin.flush()
                line = self._process.stdout.readline()
                return json.loads(line or "{}")
            except (OSError, ValueError, json.JSONDecodeError) as error:
                self._process = None
                return {"ok": False, "error": str(error)}


@lru_cache(maxsize=4)
def _catalogue(name: str) -> list[dict]:
    path = ROOT / "catalogue" / name
    if not path.exists():
        return []
    return json.loads(path.read_text(encoding="utf-8"))


class Plugin:
    """Expose standard MSFS 2020 data and commands to the shared registries."""

    def settings_schema(self) -> dict:
        return {
            "properties": {
                "address": {
                    "type": "string",
                    "title": "SimConnect address",
                    "description": "Host and TCP port exposed by SimConnect.",
                    "default": "127.0.0.1:500",
                }
            }
        }

    def __init__(self) -> None:
        self._bridge = _HelperBridge()
        self._session_timer_started_at: dict[str, float] = {}

    def modules(self) -> list[dict]:
        modules = [
            {
                "id": "msfs.cockpit_dial",
                "name": "MSFS Cockpit Dial",
                "group": "Cockpit Controls",
                "description": "Configure a dial for common MSFS cockpit controls through standard SimConnect events.",
                "requires": ["rotary_left", "rotary_right", "press"],
                "default_settings": {"control": "Autopilot Altitude"},
                "settings_schema": {
                    "properties": {
                        "control": {
                            "type": "string",
                            "title": "Control",
                            "description": "The cockpit rotary control this dial represents.",
                            "enum": list(DIAL_CONTROLS),
                            "default": "Autopilot Altitude",
                        }
                    }
                },
            }
        ]
        modules.extend(self._display_modules())
        return modules

    @staticmethod
    def _input_selection(slug: str, **settings: object) -> dict:
        """Create a normal registry selection so display modules work on assignment."""
        return {
            "id": f"simvar.{slug}",
            "extension_id": "io.github.robdevice.msfs.simconnect",
            "settings": settings,
        }

    @classmethod
    def _display_defaults(cls, kind: str) -> dict:
        defaults: dict[str, dict] = {
            "status": {
                "input": cls._input_selection("sim_on_ground"),
                "label": "On Ground",
                "accent": "#39D7A5",
            },
            "level": {
                "input": cls._input_selection("general_eng_throttle_lever_position", index=1),
                "label": "Throttle",
                "accent": "#43B5FF",
                "minimum": 0,
                "maximum": 100,
            },
            "gauge": {
                "input": cls._input_selection("indicated_altitude"),
                "label": "Altitude",
                "accent": "#9D7CFF",
                "minimum": 0,
                "maximum": 20000,
            },
            "compass": {
                "input": cls._input_selection("plane_heading_degrees_magnetic"),
                "label": "Heading",
                "accent": "#39D7A5",
            },
            "frequency": {
                "input": cls._input_selection("com_active_frequency", index=1),
                "label": "COM 1",
                "accent": "#FFB454",
            },
            "clock": {
                "label": "Flight Timer",
                "accent": "#43B5FF",
            },
            "position": {
                "input": cls._input_selection("plane_latitude"),
                "longitude": cls._input_selection("plane_longitude"),
                "label": "Position",
                "accent": "#39D7A5",
            },
            "warning": {
                "input": cls._input_selection("stall_warning"),
                "label": "Stall Warning",
                "accent": "#FFB454",
            },
        }
        return {
            **defaults[kind],
            "action": {},
            "background": "#081323",
            "foreground": "#EDF7FF",
        }

    @staticmethod
    def _display_settings(kind: str) -> dict:
        properties: dict[str, dict] = {
            "label": {"type": "string", "title": "Label"},
            "accent": {"type": "color", "title": "Accent colour"},
            "background": {"type": "color", "title": "Background colour"},
            "foreground": {"type": "color", "title": "Text colour"},
            "action": {"type": "action", "title": "When pressed (optional)"},
        }
        if kind != "clock":
            properties["input"] = {
                "type": "input",
                "title": "Data to show",
                "extension_id": "io.github.robdevice.msfs.simconnect",
            }
        if kind == "position":
            properties["longitude"] = {
                "type": "input",
                "title": "Longitude",
                "extension_id": "io.github.robdevice.msfs.simconnect",
            }
        return {"properties": properties}

    def _display_modules(self) -> list[dict]:
        definitions = (
            ("status", "MSFS Status", "Show a clear simulator status such as whether the aircraft is on the ground."),
            ("level", "MSFS Level", "Show a value such as throttle position as a level bar."),
            ("gauge", "MSFS Gauge", "Show a value such as altitude on a compact gauge."),
            ("compass", "MSFS Compass", "Show heading, bearing, course, or track on a compass display."),
            ("frequency", "MSFS Frequency", "Show a radio, navigation, or transponder frequency."),
            ("clock", "MSFS Flight Timer", "Show elapsed time since SimConnect became available."),
            ("position", "MSFS Position", "Show the aircraft latitude and longitude."),
            ("warning", "MSFS Warning", "Show a clear warning when the selected simulator warning is active."),
        )
        return [
            {
                "id": f"msfs.display_{kind}",
                "name": name,
                "group": "Displays",
                "description": description,
                "requires": [],
                "live_visual": True,
                "icon": "clock-countdown" if kind == "clock" else "monitor-play",
                "migrate_missing_defaults": True,
                "default_settings": self._display_defaults(kind),
                "default_visual": {"background": "#081323", "foreground": "#edf7ff", "asset_mode": "image"},
                "settings_schema": self._display_settings(kind),
            }
            for kind, name, description in definitions
        ]

    @staticmethod
    def _helper() -> Path:
        return ROOT / "runtime" / f"{platform.system().lower()}-{platform.machine()}" / "macro-pad-manager-msfs-helper"

    @staticmethod
    def _address(settings: dict | None) -> str:
        return str((settings or {}).get("address") or "127.0.0.1:500")

    def _request(self, payload: dict) -> dict:
        helper = self._helper()
        if not helper.exists():
            return {"ok": False, "error": "SimConnect helper is unavailable on this platform"}
        if not os.access(helper, os.X_OK):
            return {"ok": False, "error": "The SimConnect helper is not allowed to run. Repair helper permissions in Extension Settings."}
        return self._bridge.request(helper, payload)

    def inputs(self) -> list[dict]:
        inputs: list[dict] = []
        for entry in _catalogue("simvars.json"):
            item = {
                "id": f"simvar.{entry['slug']}",
                "name": entry["name"],
                "description": entry["description"],
                "group": entry["group"],
                "unit": entry["unit"],
                "data_type": entry["data_type"],
                "indexable": entry["indexable"],
                "simvar": entry["name"],
                "presentation": self._presentation_hint(entry),
            }
            properties: dict[str, dict] = {}
            if entry["indexable"]:
                properties["index"] = {"type": "integer", "title": "Index", "default": 1}
            if entry["data_type"] == "number":
                properties["decimal_places"] = {
                    "type": "integer",
                    "title": "Decimal places",
                    "description": "Number of digits to show after the decimal point.",
                    "default": self._default_decimal_places(entry),
                }
            if properties:
                item["settings_schema"] = {"properties": properties}
            inputs.append(item)
        return inputs

    @staticmethod
    def _presentation_hint(entry: dict) -> dict:
        name = str(entry.get("name", "")).upper()
        unit = str(entry.get("unit", ""))
        data_type = str(entry.get("data_type", ""))
        if data_type == "boolean" or unit.lower() == "bool":
            kind = "status"
        elif "FREQUENCY" in name or "TRANSPONDER" in name:
            kind = "frequency"
        elif any(token in name for token in ("HEADING", "BEARING", "COURSE", "TRACK")):
            kind = "compass"
        elif any(token in name for token in ("TIME", "TIMER", "DURATION")):
            kind = "clock"
        elif any(token in name for token in ("LATITUDE", "LONGITUDE", "POSITION")):
            kind = "position"
        elif "ALTITUDE" in name:
            kind = "gauge"
        elif "PERCENT" in unit.upper() or unit.lower() in {"percent over 100", "ratio"}:
            kind = "level"
        elif any(token in name for token in ("RPM", "TEMPERATURE", "PRESSURE", "SPEED", "VOLTAGE", "CURRENT")):
            kind = "gauge"
        else:
            kind = "value"
        hint = {"kind": kind, "unit": unit}
        if "PERCENT" in unit.upper():
            hint.update({"minimum": 0, "maximum": 100})
        elif unit.lower() in {"percent over 100", "ratio"}:
            hint.update({"minimum": 0, "maximum": 1})
        return hint

    @staticmethod
    def _default_decimal_places(entry: dict) -> int:
        name = str(entry.get("name", "")).lower()
        if "altitude" in name:
            return 0
        return 2

    @staticmethod
    def _format_readout_value(value, decimal_places: object) -> object:
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            return value
        try:
            places = max(0, min(6, int(decimal_places)))
        except (TypeError, ValueError):
            places = 2
        if places == 0:
            return str(int(round(value)))
        return f"{value:.{places}f}".rstrip("0").rstrip(".")

    def actions(self) -> list[dict]:
        actions: list[dict] = []
        for entry in _catalogue("key_events.json"):
            actions.append(
                {
                    "id": f"key_event.{entry['slug']}",
                    "name": entry["name"],
                    "description": entry["description"],
                    "group": entry["group"],
                    "key_event": entry["name"],
                    "settings_schema": {
                        "properties": {
                            "parameter": {
                                "type": "integer",
                                "title": "Parameter",
                                "description": entry["parameters"] or "SimConnect event parameter.",
                                "default": 0,
                            }
                        }
                    },
                }
            )
        for entry in _catalogue("simvars.json"):
            if not entry["settable"]:
                continue
            actions.append(
                {
                    "id": f"set_simvar.{entry['slug']}",
                    "name": f"Set {entry['name']}",
                    "description": f"Write {entry['name']} through SimConnect.",
                    "group": f"Set SimVars / {entry['group']}",
                    "simvar": entry["name"],
                    "unit": entry["unit"],
                    "data_type": entry["data_type"],
                    "settings_schema": {
                        "properties": {
                            "value": {"type": entry["data_type"], "title": "Value"},
                            **({"index": {"type": "integer", "title": "Index", "default": 1}} if entry["indexable"] else {}),
                        }
                    },
                }
            )
        actions.append(
            {
                "id": "advanced_simvar_output",
                "name": "Advanced SimVar Output",
                "description": "Write a custom documented SimVar through SimConnect.",
                "group": "Advanced",
                "settings_schema": {
                    "properties": {
                        "simvar": {"type": "string", "title": "Simulation Variable"},
                        "unit": {"type": "string", "title": "Unit"},
                        "value": {"type": "number", "title": "Value"},
                        "index": {"type": "integer", "title": "Index", "default": 0},
                    }
                },
            }
        )
        return actions

    def connection_status(self, settings: dict | None = None) -> dict:
        address = self._address(settings)
        helper = self._helper()
        if not helper.exists():
            return {"address": address, "state": "unsupported_platform"}
        if not os.access(helper, os.X_OK):
            return {
                "address": address,
                "state": "helper_not_executable",
                "error": "The SimConnect helper was installed without permission to run.",
                "remediation": "Repair helper permissions, then test the connection again.",
                "repairable": True,
                "repair_label": "Repair Helper Permissions",
            }
        try:
            response = self._request({"operation": "probe", "address": address})
            if response.get("ok"):
                return {
                    "address": address,
                    "state": "connected",
                    "message": "SimConnect accepted a connection at this address.",
                }
            return self._connection_failure(address, str(response.get("error") or "SimConnect did not return a response"))
        except (OSError, subprocess.SubprocessError, json.JSONDecodeError) as error:
            return self._connection_failure(address, str(error))

    @staticmethod
    def _connection_failure(address: str, error: str) -> dict:
        normalized_error = error.casefold()
        result = {"address": address, "state": "unavailable", "error": error}
        if "connection refused" in normalized_error:
            result.update(
                {
                    "message": f"No SimConnect service is listening at {address}.",
                    "remediation": (
                        "Start MSFS and the SimConnect TCP listener, or change the address to the endpoint "
                        "that MSFS is exposing. The extension cannot start SimConnect itself."
                    ),
                }
            )
        elif "timed out" in normalized_error:
            result.update(
                {
                    "message": f"SimConnect at {address} did not respond in time.",
                    "remediation": "Confirm that MSFS is running and that the configured host and port are reachable from this computer.",
                }
            )
        else:
            result.update(
                {
                    "message": f"SimConnect could not be reached at {address}.",
                    "remediation": "Check that MSFS is running and that the configured host and port are correct, then test again.",
                }
            )
        return result

    def repair_connection(self, settings: dict | None = None) -> dict:
        """Restore user execute permission on the packaged native helper."""
        helper = self._helper()
        if not helper.exists():
            return {"ok": False, "error": "SimConnect helper is unavailable on this platform"}
        try:
            helper.chmod(helper.stat().st_mode | stat.S_IXUSR)
        except OSError as error:
            return {"ok": False, "error": f"Could not repair helper permissions: {error}"}
        return {"ok": True, "message": "Helper permissions repaired"}

    def read_input(self, input_definition: dict, input_settings: dict | None = None, extension_settings: dict | None = None) -> dict:
        input_settings = input_settings or {}
        response = self._request(
            {
                "operation": "read_simvar",
                "address": self._address(extension_settings),
                "simvar": input_definition.get("simvar", ""),
                "unit": input_definition.get("unit") or None,
                "index": input_settings.get("index"),
                "data_type": input_definition.get("data_type", "number"),
            }
        )
        if not response.get("ok"):
            raise RuntimeError(str(response.get("error") or "SimConnect read failed"))
        return {
            "value": self._format_readout_value(
                response.get("value", "--"),
                input_settings.get("decimal_places", self._default_decimal_places(input_definition)),
            ),
            "raw_value": response.get("value", "--"),
            "unit": input_definition.get("unit", ""),
            "presentation": dict(input_definition.get("presentation", {})),
        }

    def execute_action(
        self,
        action: dict,
        action_settings: dict | None = None,
        extension_settings: dict | None = None,
    ) -> dict:
        """Run a documented Key Event or writable SimVar through SimConnect."""
        action_settings = action_settings or {}
        address = self._address(extension_settings)
        event = str(action.get("key_event") or "").strip()
        if event:
            return self._request({"operation": "key_event", "address": address, "event": event, "parameter": action_settings.get("parameter", 0)})
        simvar = str(action_settings.get("simvar") or action.get("simvar") or "").strip()
        if not simvar:
            return {"ok": False, "error": "No SimVar was selected"}
        return self._request(
            {
                "operation": "set_simvar",
                "address": address,
                "simvar": simvar,
                "unit": action_settings.get("unit") or action.get("unit") or None,
                "index": action_settings.get("index"),
                "data_type": action.get("data_type", "number"),
                "value": action_settings.get("value", 0),
            }
        )

    def execute_module(
        self,
        module_payload: dict,
        event: dict,
        _context,
        extension_settings: dict | None = None,
    ) -> None:
        """Handle the fixed, real-world control mappings exposed by MSFS Cockpit Dial."""
        module_type = str(module_payload.get("type", ""))
        if module_type.startswith("msfs.display_"):
            selection = dict(module_payload.get("settings", {}).get("action", {}))
            if str(event.get("trigger_id", "")) in {"press", "touch"} and selection.get("id") and _context is not None:
                _context.extension_action(selection, control_id=str(event.get("control_id", "plugin")))
            return
        if module_type != "msfs.cockpit_dial":
            raise RuntimeError(f"Unsupported MSFS module: {module_payload.get('type', '')}")
        control = str(module_payload.get("settings", {}).get("control") or "Autopilot Altitude")
        mapping = DIAL_CONTROLS.get(control)
        if mapping is None:
            raise RuntimeError(f"Unsupported MSFS cockpit dial control: {control}")
        trigger = str(event.get("trigger_id", ""))
        address = self._address(extension_settings)
        if trigger == "press" and mapping.get("press") == "heading_sync":
            heading = self._read_magnetic_heading(address)
            self._send_key_event(address, "HEADING_BUG_SET", heading)
            return
        key_event = mapping.get(trigger)
        if key_event:
            self._send_key_event(address, str(key_event), int(mapping.get("parameter", 0)))

    def _input_definition(self, identifier: str) -> dict | None:
        if not identifier.startswith("simvar."):
            return None
        slug = identifier.removeprefix("simvar.")
        for entry in _catalogue("simvars.json"):
            if str(entry.get("slug", "")) == slug:
                return {
                    "id": identifier,
                    "name": entry["name"],
                    "description": entry["description"],
                    "group": entry["group"],
                    "unit": entry["unit"],
                    "data_type": entry["data_type"],
                    "indexable": entry["indexable"],
                    "simvar": entry["name"],
                    "presentation": self._presentation_hint(entry),
                }
        return None

    @staticmethod
    def _colour(value: str, fallback: str) -> tuple[int, int, int]:
        try:
            return ImageColor.getrgb(value)
        except ValueError:
            return ImageColor.getrgb(fallback)

    @staticmethod
    def _font(size: int, *, bold: bool = False) -> ImageFont.ImageFont:
        names = ("DejaVuSans-Bold.ttf", "DejaVuSans.ttf") if bold else ("DejaVuSans.ttf", "DejaVuSans-Bold.ttf")
        for name in names:
            try:
                return ImageFont.truetype(name, size)
            except OSError:
                continue
        return ImageFont.load_default()

    @staticmethod
    def _number(value: object) -> float | None:
        if isinstance(value, bool):
            return float(value)
        try:
            return float(value)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _timer_text(value: object) -> str:
        seconds = Plugin._number(value)
        if seconds is None:
            return str(value)
        seconds = max(0, int(round(seconds)))
        hours, remainder = divmod(seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        return f"{hours}:{minutes:02}" if hours else f"{minutes:02}:{seconds:02}"

    @staticmethod
    def _compact_unit(unit: str) -> str:
        normalized = unit.casefold().strip()
        return {
            "feet": "ft",
            "feet (ft)": "ft",
            "percent": "%",
            "radians": "",
            "frequency bcd16": "",
            "hours": "",
            "bool": "",
            "boolean": "",
        }.get(normalized, unit)

    def render_live_visual(
        self,
        module_payload: dict,
        extension_settings: dict | None = None,
        render_context: dict | None = None,
    ) -> dict:
        settings = dict(module_payload.get("settings", {}))
        kind = str(module_payload.get("type", "msfs.display_status")).removeprefix("msfs.display_")
        if kind == "clock":
            label = str(settings.get("label") or "Flight Timer")
            try:
                elapsed_seconds = self._session_elapsed_seconds(extension_settings)
            except RuntimeError as error:
                return self._render_failure(module_payload, label, str(error), extension_settings, render_context)
            return self._render_display(
                module_payload,
                label,
                elapsed_seconds,
                "SimConnect session",
                formatted=self._timer_text(elapsed_seconds),
                presentation={"kind": "clock"},
                render_context=render_context,
            )
        selection = settings.get("input", {})
        identifier = str(selection.get("id", "")) if isinstance(selection, dict) else ""
        definition = self._input_definition(identifier)
        if definition is None:
            return self._render_data_unavailable(module_payload, str(settings.get("label") or "MSFS Display"), render_context)
        label = str(settings.get("label") or definition["name"])
        try:
            readout = self.read_input(definition, dict(selection.get("settings", {})), extension_settings)
        except Exception as exc:  # noqa: BLE001
            return self._render_failure(module_payload, label, str(exc), extension_settings, render_context)
        if kind == "position":
            longitude_selection = settings.get("longitude", {})
            longitude_id = str(longitude_selection.get("id", "")) if isinstance(longitude_selection, dict) else ""
            longitude_definition = self._input_definition(longitude_id)
            if longitude_definition is None:
                return self._render_data_unavailable(module_payload, str(settings.get("label") or "Position"), render_context)
            try:
                longitude = self.read_input(
                    longitude_definition,
                    dict(longitude_selection.get("settings", {})),
                    extension_settings,
                )
            except Exception as exc:  # noqa: BLE001
                return self._render_failure(
                    module_payload,
                    str(settings.get("label") or "Position"),
                    str(exc),
                    extension_settings,
                    render_context,
                )
            return self._render_display(
                module_payload,
                str(settings.get("label") or "Position"),
                (readout.get("raw_value"), longitude.get("raw_value")),
                "",
                formatted="Position",
                presentation={"kind": "position"},
                render_context=render_context,
            )
        return self._render_display(
            module_payload,
            label,
            readout.get("raw_value"),
            str(readout.get("unit") or ""),
            formatted=str(readout.get("value") or "--"),
            presentation=dict(readout.get("presentation") or {}),
            render_context=render_context,
        )

    def _session_elapsed_seconds(self, extension_settings: dict | None) -> int:
        address = self._address(extension_settings)
        response = self._request({"operation": "probe", "address": address})
        if not response.get("ok"):
            self._session_timer_started_at.pop(address, None)
            raise RuntimeError(str(response.get("error") or "SimConnect did not return a response"))
        started_at = self._session_timer_started_at.get(address)
        if started_at is None:
            started_at = time.monotonic()
            self._session_timer_started_at[address] = started_at
        return max(0, int(time.monotonic() - started_at))

    def _render_failure(
        self,
        module_payload: dict,
        title: str,
        error: str,
        extension_settings: dict | None,
        render_context: dict | None,
    ) -> dict:
        status = self.connection_status(extension_settings)
        if status.get("state") != "connected":
            return self._render_display(
                module_payload,
                title,
                None,
                "",
                failure="connection",
                render_context=render_context,
            )
        return self._render_data_unavailable(module_payload, title, render_context)

    def _render_data_unavailable(self, module_payload: dict, title: str, render_context: dict | None) -> dict:
        return self._render_display(
            module_payload,
            title,
            None,
            "",
            failure="data",
            render_context=render_context,
        )

    def _render_display(
        self,
        module_payload: dict,
        title: str,
        raw_value: object,
        unit: str,
        *,
        formatted: str = "--",
        failure: str = "",
        presentation: dict | None = None,
        render_context: dict | None = None,
    ) -> dict:
        settings = dict(module_payload.get("settings", {}))
        visual = dict(module_payload.get("visual", {}))
        kind = str(module_payload.get("type", "msfs.display_status")).removeprefix("msfs.display_")
        context = render_context if isinstance(render_context, dict) else {}
        try:
            aspect_ratio = max(0.25, min(4.0, float(context.get("aspect_ratio", 1.0))))
        except (TypeError, ValueError):
            aspect_ratio = 1.0
        if aspect_ratio >= 1.0:
            width, height = 512, max(128, round(512 / aspect_ratio))
        else:
            width, height = max(128, round(512 * aspect_ratio)), 512
        background = self._colour(str(settings.get("background") or visual.get("background", "#081323")), "#081323")
        foreground = self._colour(str(settings.get("foreground") or visual.get("foreground", "#edf7ff")), "#edf7ff")
        accent = self._colour(str(settings.get("accent", "#39d7a5")), "#39d7a5")
        warning_colour = (255, 170, 45)
        image = Image.new("RGB", (width, height), background)
        draw = ImageDraw.Draw(image)
        edge = max(2, min(width, height) // 42)
        margin = max(8, min(width, height) // 12)
        label_font = self._font(max(10, min(width, height) // 9), bold=True)
        value_font = self._font(max(17, min(width, height) // 3), bold=True)
        detail_font = self._font(max(9, min(width, height) // 10))
        draw.rounded_rectangle((margin, margin, width - margin, margin + edge), radius=edge, fill=accent)
        draw.text((margin, margin + edge + 5), title[:22], fill=foreground, font=label_font)

        number = self._number(raw_value)
        shown_value = formatted
        display_unit = self._compact_unit(unit)
        if display_unit:
            shown_value = f"{shown_value}{display_unit if display_unit == '%' else f' {display_unit}'}".strip()
        if kind == "clock":
            elapsed_seconds = number * 3600 if number is not None and unit.casefold() == "hours" else raw_value
            shown_value = self._timer_text(elapsed_seconds)

        suggested_range = dict(presentation or {})
        if failure == "connection":
            draw.text((margin, height // 2 - 2), "SimConnect unavailable", fill=warning_colour, font=label_font)
            draw.text((margin, height // 2 + detail_font.size + 5), "Start MSFS or check settings", fill=foreground, font=detail_font)
            shown_value = "No connection"
        elif failure == "data":
            draw.text((margin, height // 2 - 2), "Data unavailable", fill=warning_colour, font=label_font)
            draw.text((margin, height // 2 + detail_font.size + 5), "Choose another value or check the aircraft", fill=foreground, font=detail_font)
            shown_value = "Data unavailable"
        elif kind in {"status", "warning"}:
            active = bool(raw_value)
            colour = warning_colour if kind == "warning" and active else accent if active else (112, 128, 150)
            dot_size = max(18, min(width, height) // 4)
            dot_top = height // 2 - dot_size // 2 + 8
            draw.ellipse((margin, dot_top, margin + dot_size, dot_top + dot_size), fill=colour)
            if kind == "warning":
                state = "STALL" if active else "CLEAR"
            elif title.casefold() == "on ground":
                state = "ON GROUND" if active else "IN FLIGHT"
            else:
                state = "ON" if active else "OFF"
            draw.text((margin + dot_size + 9, dot_top + max(0, dot_size // 5)), state, fill=foreground, font=label_font)
            shown_value = state
        elif kind == "level":
            minimum, maximum = float(settings.get("minimum", 0)), float(settings.get("maximum", 100))
            if minimum == 0 and maximum == 100 and suggested_range.get("maximum") == 1:
                maximum = 1
            ratio = 0.0 if number is None or maximum <= minimum else max(0.0, min(1.0, (number - minimum) / (maximum - minimum)))
            draw.text((margin, height // 2 - 8), shown_value, fill=foreground, font=value_font)
            bar_top = height - margin - max(12, height // 9)
            draw.rounded_rectangle((margin, bar_top, width - margin, height - margin), radius=edge * 2, fill=(30, 47, 66))
            if ratio:
                draw.rounded_rectangle((margin, bar_top, margin + int((width - 2 * margin) * ratio), height - margin), radius=edge * 2, fill=accent)
        elif kind == "gauge":
            minimum, maximum = float(settings.get("minimum", 0)), float(settings.get("maximum", 100))
            ratio = 0.0 if number is None or maximum <= minimum else max(0.0, min(1.0, (number - minimum) / (maximum - minimum)))
            diameter = min(width - 2 * margin, height - margin * 3 - label_font.size)
            box = ((width - diameter) // 2, height - margin - diameter, (width + diameter) // 2, height - margin)
            stroke = max(4, diameter // 12)
            draw.arc(box, 135, 405, fill=(30, 47, 66), width=stroke)
            draw.arc(box, 135, 135 + int(270 * ratio), fill=accent, width=stroke)
            draw.text((width // 2, box[1] + diameter // 2 + 3), shown_value, anchor="mm", fill=foreground, font=label_font)
        elif kind == "clock":
            draw.text((width // 2, height // 2 + 8), shown_value, anchor="mm", fill=foreground, font=value_font)
            draw.text((width // 2, height - margin), "SIMCONNECT SESSION", anchor="ms", fill=accent, font=detail_font)
        elif kind == "compass":
            degrees = 0.0 if number is None else number
            if abs(degrees) <= (math.tau + 0.01):
                degrees = math.degrees(degrees)
            degrees %= 360
            center = (width // 2, height // 2 + 9)
            radius = max(22, min(width, height) // 4)
            draw.ellipse((center[0] - radius, center[1] - radius, center[0] + radius, center[1] + radius), outline=accent, width=max(3, radius // 12))
            angle = math.radians(degrees - 90)
            tip = (center[0] + int(math.cos(angle) * radius * 0.72), center[1] + int(math.sin(angle) * radius * 0.72))
            draw.line((center, tip), fill=foreground, width=max(3, radius // 9))
            draw.text((center[0], height - margin), f"{degrees:03.0f}°", anchor="ms", fill=foreground, font=label_font)
        elif kind == "frequency":
            draw.text((width // 2, height // 2 + 8), shown_value, anchor="mm", fill=accent, font=value_font)
        elif kind == "position":
            latitude, longitude = raw_value if isinstance(raw_value, tuple) and len(raw_value) == 2 else (None, None)
            latitude_text = self._coordinate_text(latitude, "N", "S")
            longitude_text = self._coordinate_text(longitude, "E", "W")
            shown_value = f"{latitude_text}\n{longitude_text}"
            draw.multiline_text((margin, height // 2 - 3), shown_value, fill=foreground, font=label_font, spacing=max(4, detail_font.size // 2))
        else:
            draw.text((width // 2, height // 2 + 8), shown_value, anchor="mm", fill=foreground, font=value_font)

        buffer = BytesIO()
        image.save(buffer, format="PNG")
        return {"title": title, "value": shown_value, "subtitle": unit or "MSFS", "image_png": buffer.getvalue()}

    @staticmethod
    def _coordinate_text(value: object, positive: str, negative: str) -> str:
        number = Plugin._number(value)
        if number is None:
            return "--"
        if abs(number) <= math.tau + 0.01:
            number = math.degrees(number)
        hemisphere = positive if number >= 0 else negative
        return f"{abs(number):.4f}° {hemisphere}"

    def _read_magnetic_heading(self, address: str) -> int:
        response = self._request(
            {
                "operation": "read_simvar",
                "address": address,
                "simvar": "PLANE HEADING DEGREES MAGNETIC",
                "unit": "Degrees",
                "index": None,
                "data_type": "number",
            }
        )
        if not response.get("ok"):
            raise RuntimeError(str(response.get("error") or "Could not read the current magnetic heading"))
        try:
            return int(round(float(response.get("value")))) % 360
        except (TypeError, ValueError) as error:
            raise RuntimeError("SimConnect returned an invalid magnetic heading") from error

    def _send_key_event(self, address: str, event: str, parameter: int = 0) -> None:
        response = self._request(
            {"operation": "key_event", "address": address, "event": event, "parameter": parameter}
        )
        if not response.get("ok"):
            raise RuntimeError(str(response.get("error") or f"SimConnect rejected {event}"))

    def copy_input(self, identifier: str) -> dict | None:
        return next((copy.deepcopy(item) for item in self.inputs() if item["id"] == identifier), None)
