from __future__ import annotations

import copy
import json
import os
from pathlib import Path
import platform
import stat
import subprocess
import threading


ROOT = Path(__file__).resolve().parents[1]


class _HelperBridge:
    """Keep the helper process alive while a profile polls SimConnect values."""

    def __init__(self) -> None:
        self._process: subprocess.Popen[str] | None = None
        self._lock = threading.Lock()

    def request(self, helper: Path, payload: dict) -> dict:
        with self._lock:
            if self._process is None or self._process.poll() is not None:
                self._process = subprocess.Popen(
                    [str(helper)], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                    text=True, bufsize=1,
                )
            if self._process.stdin is None or self._process.stdout is None:
                return {"ok": False, "error": "SimConnect helper streams are unavailable"}
            try:
                self._process.stdin.write(json.dumps(payload) + "\n")
                self._process.stdin.flush()
                line = self._process.stdout.readline()
                return json.loads(line or "{}")
            except (OSError, ValueError, json.JSONDecodeError) as error:
                self._process = None
                return {"ok": False, "error": str(error)}


def _catalogue(name: str) -> list[dict]:
    path = ROOT / "catalogue" / name
    if not path.exists():
        return []
    return json.loads(path.read_text(encoding="utf-8"))


class Plugin:
    """Expose standard MSFS 2020 data and commands to the shared registries."""

    def settings_schema(self) -> dict:
        return {
            "properties": {
                "address": {
                    "type": "string",
                    "title": "SimConnect address",
                    "description": "Host and TCP port exposed by SimConnect.",
                    "default": "127.0.0.1:500",
                }
            }
        }

    def __init__(self) -> None:
        self._bridge = _HelperBridge()

    @staticmethod
    def _helper() -> Path:
        return ROOT / "runtime" / f"{platform.system().lower()}-{platform.machine()}" / "macro-pad-manager-msfs-helper"

    @staticmethod
    def _address(settings: dict | None) -> str:
        return str((settings or {}).get("address") or "127.0.0.1:500")

    def _request(self, payload: dict) -> dict:
        helper = self._helper()
        if not helper.exists():
            return {"ok": False, "error": "SimConnect helper is unavailable on this platform"}
        if not os.access(helper, os.X_OK):
            return {"ok": False, "error": "The SimConnect helper is not allowed to run. Repair helper permissions in Extension Settings."}
        return self._bridge.request(helper, payload)

    def inputs(self) -> list[dict]:
        inputs: list[dict] = []
        for entry in _catalogue("simvars.json"):
            item = {
                "id": f"simvar.{entry['slug']}",
                "name": entry["name"],
                "description": entry["description"],
                "group": entry["group"],
                "unit": entry["unit"],
                "data_type": entry["data_type"],
                "indexable": entry["indexable"],
                "simvar": entry["name"],
            }
            properties: dict[str, dict] = {}
            if entry["indexable"]:
                properties["index"] = {"type": "integer", "title": "Index", "default": 1}
            if entry["data_type"] == "number":
                properties["decimal_places"] = {
                    "type": "integer",
                    "title": "Decimal places",
                    "description": "Number of digits to show after the decimal point.",
                    "default": self._default_decimal_places(entry),
                }
            if properties:
                item["settings_schema"] = {"properties": properties}
            inputs.append(item)
        return inputs

    @staticmethod
    def _default_decimal_places(entry: dict) -> int:
        name = str(entry.get("name", "")).lower()
        if "altitude" in name:
            return 0
        return 2

    @staticmethod
    def _format_readout_value(value, decimal_places: object) -> object:
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            return value
        try:
            places = max(0, min(6, int(decimal_places)))
        except (TypeError, ValueError):
            places = 2
        if places == 0:
            return str(int(round(value)))
        return f"{value:.{places}f}".rstrip("0").rstrip(".")

    def actions(self) -> list[dict]:
        actions: list[dict] = []
        for entry in _catalogue("key_events.json"):
            actions.append(
                {
                    "id": f"key_event.{entry['slug']}",
                    "name": entry["name"],
                    "description": entry["description"],
                    "group": entry["group"],
                    "key_event": entry["name"],
                    "settings_schema": {
                        "properties": {
                            "parameter": {
                                "type": "integer",
                                "title": "Parameter",
                                "description": entry["parameters"] or "SimConnect event parameter.",
                                "default": 0,
                            }
                        }
                    },
                }
            )
        for entry in _catalogue("simvars.json"):
            if not entry["settable"]:
                continue
            actions.append(
                {
                    "id": f"set_simvar.{entry['slug']}",
                    "name": f"Set {entry['name']}",
                    "description": f"Write {entry['name']} through SimConnect.",
                    "group": f"Set SimVars / {entry['group']}",
                    "simvar": entry["name"],
                    "unit": entry["unit"],
                    "data_type": entry["data_type"],
                    "settings_schema": {
                        "properties": {
                            "value": {"type": entry["data_type"], "title": "Value"},
                            **({"index": {"type": "integer", "title": "Index", "default": 1}} if entry["indexable"] else {}),
                        }
                    },
                }
            )
        actions.append(
            {
                "id": "advanced_simvar_output",
                "name": "Advanced SimVar Output",
                "description": "Write a custom documented SimVar through SimConnect.",
                "group": "Advanced",
                "settings_schema": {
                    "properties": {
                        "simvar": {"type": "string", "title": "Simulation Variable"},
                        "unit": {"type": "string", "title": "Unit"},
                        "value": {"type": "number", "title": "Value"},
                        "index": {"type": "integer", "title": "Index", "default": 0},
                    }
                },
            }
        )
        return actions

    def connection_status(self, settings: dict | None = None) -> dict:
        address = self._address(settings)
        helper = self._helper()
        if not helper.exists():
            return {"address": address, "state": "unsupported_platform"}
        if not os.access(helper, os.X_OK):
            return {
                "address": address,
                "state": "helper_not_executable",
                "error": "The SimConnect helper was installed without permission to run.",
                "remediation": "Repair helper permissions, then test the connection again.",
                "repairable": True,
                "repair_label": "Repair Helper Permissions",
            }
        try:
            response = self._request({"operation": "probe", "address": address})
            if response.get("ok"):
                return {
                    "address": address,
                    "state": "connected",
                    "message": "SimConnect accepted a connection at this address.",
                }
            return self._connection_failure(address, str(response.get("error") or "SimConnect did not return a response"))
        except (OSError, subprocess.SubprocessError, json.JSONDecodeError) as error:
            return self._connection_failure(address, str(error))

    @staticmethod
    def _connection_failure(address: str, error: str) -> dict:
        normalized_error = error.casefold()
        result = {"address": address, "state": "unavailable", "error": error}
        if "connection refused" in normalized_error:
            result.update(
                {
                    "message": f"No SimConnect service is listening at {address}.",
                    "remediation": (
                        "Start MSFS and the SimConnect TCP listener, or change the address to the endpoint "
                        "that MSFS is exposing. The extension cannot start SimConnect itself."
                    ),
                }
            )
        elif "timed out" in normalized_error:
            result.update(
                {
                    "message": f"SimConnect at {address} did not respond in time.",
                    "remediation": "Confirm that MSFS is running and that the configured host and port are reachable from this computer.",
                }
            )
        else:
            result.update(
                {
                    "message": f"SimConnect could not be reached at {address}.",
                    "remediation": "Check that MSFS is running and that the configured host and port are correct, then test again.",
                }
            )
        return result

    def repair_connection(self, settings: dict | None = None) -> dict:
        """Restore user execute permission on the packaged native helper."""
        helper = self._helper()
        if not helper.exists():
            return {"ok": False, "error": "SimConnect helper is unavailable on this platform"}
        try:
            helper.chmod(helper.stat().st_mode | stat.S_IXUSR)
        except OSError as error:
            return {"ok": False, "error": f"Could not repair helper permissions: {error}"}
        return {"ok": True, "message": "Helper permissions repaired"}

    def read_input(self, input_definition: dict, input_settings: dict | None = None, extension_settings: dict | None = None) -> dict:
        input_settings = input_settings or {}
        response = self._request(
            {
                "operation": "read_simvar",
                "address": self._address(extension_settings),
                "simvar": input_definition.get("simvar", ""),
                "unit": input_definition.get("unit") or None,
                "index": input_settings.get("index"),
                "data_type": input_definition.get("data_type", "number"),
            }
        )
        if not response.get("ok"):
            raise RuntimeError(str(response.get("error") or "SimConnect read failed"))
        return {
            "value": self._format_readout_value(
                response.get("value", "--"),
                input_settings.get("decimal_places", self._default_decimal_places(input_definition)),
            ),
            "unit": input_definition.get("unit", ""),
        }

    def execute_action(
        self,
        action: dict,
        action_settings: dict | None = None,
        extension_settings: dict | None = None,
    ) -> dict:
        """Run a documented Key Event or writable SimVar through SimConnect."""
        action_settings = action_settings or {}
        address = self._address(extension_settings)
        event = str(action.get("key_event") or "").strip()
        if event:
            return self._request({"operation": "key_event", "address": address, "event": event, "parameter": action_settings.get("parameter", 0)})
        simvar = str(action_settings.get("simvar") or action.get("simvar") or "").strip()
        if not simvar:
            return {"ok": False, "error": "No SimVar was selected"}
        return self._request(
            {
                "operation": "set_simvar",
                "address": address,
                "simvar": simvar,
                "unit": action_settings.get("unit") or action.get("unit") or None,
                "index": action_settings.get("index"),
                "data_type": action.get("data_type", "number"),
                "value": action_settings.get("value", 0),
            }
        )

    def copy_input(self, identifier: str) -> dict | None:
        return next((copy.deepcopy(item) for item in self.inputs() if item["id"] == identifier), None)
