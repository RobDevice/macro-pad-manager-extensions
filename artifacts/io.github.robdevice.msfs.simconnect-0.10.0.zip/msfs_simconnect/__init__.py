from __future__ import annotations

import copy
from functools import lru_cache
from io import BytesIO
import json
import math
import os
from pathlib import Path
import platform
import stat
import subprocess
import threading

from PIL import Image, ImageColor, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]


DIAL_CONTROLS: dict[str, dict[str, str | int]] = {
    "Autopilot Altitude": {"left": "AP_ALT_VAR_DEC", "right": "AP_ALT_VAR_INC", "parameter": 1},
    "Heading Bug": {"left": "HEADING_BUG_DEC", "right": "HEADING_BUG_INC", "press": "heading_sync"},
    "Autopilot Vertical Speed": {"left": "AP_VS_VAR_DEC", "right": "AP_VS_VAR_INC"},
    "Autopilot Airspeed": {"left": "AP_SPD_VAR_DEC", "right": "AP_SPD_VAR_INC"},
    "COM 1 Fine Frequency": {"left": "COM1_RADIO_FRACT_DEC", "right": "COM1_RADIO_FRACT_INC"},
    "COM 1 Coarse Frequency": {"left": "COM1_RADIO_WHOLE_DEC", "right": "COM1_RADIO_WHOLE_INC"},
    "COM 2 Fine Frequency": {"left": "COM2_RADIO_FRACT_DEC", "right": "COM2_RADIO_FRACT_INC"},
    "COM 2 Coarse Frequency": {"left": "COM2_RADIO_WHOLE_DEC", "right": "COM2_RADIO_WHOLE_INC"},
    "NAV 1 Fine Frequency": {"left": "NAV1_RADIO_FRACT_DEC", "right": "NAV1_RADIO_FRACT_INC"},
    "NAV 1 Coarse Frequency": {"left": "NAV1_RADIO_WHOLE_DEC", "right": "NAV1_RADIO_WHOLE_INC"},
    "NAV 2 Fine Frequency": {"left": "NAV2_RADIO_FRACT_DEC", "right": "NAV2_RADIO_FRACT_INC"},
    "NAV 2 Coarse Frequency": {"left": "NAV2_RADIO_WHOLE_DEC", "right": "NAV2_RADIO_WHOLE_INC"},
    "NAV 1 Course": {"left": "VOR1_OBI_DEC", "right": "VOR1_OBI_INC"},
    "NAV 1 Course (10 degrees)": {"left": "VOR1_OBI_FAST_DEC", "right": "VOR1_OBI_FAST_INC"},
    "NAV 2 Course": {"left": "VOR2_OBI_DEC", "right": "VOR2_OBI_INC"},
    "NAV 2 Course (10 degrees)": {"left": "VOR2_OBI_FAST_DEC", "right": "VOR2_OBI_FAST_INC"},
    "Transponder Digit 1": {"left": "XPNDR_1000_DEC", "right": "XPNDR_1000_INC"},
    "Transponder Digit 2": {"left": "XPNDR_100_DEC", "right": "XPNDR_100_INC"},
    "Transponder Digit 3": {"left": "XPNDR_10_DEC", "right": "XPNDR_10_INC"},
    "Transponder Digit 4": {"left": "XPNDR_1_DEC", "right": "XPNDR_1_INC"},
    "Altimeter Pressure": {"left": "KOHLSMAN_DEC", "right": "KOHLSMAN_INC"},
    "G1000 PFD Page": {"left": "G1000_PFD_PAGE_KNOB_DEC", "right": "G1000_PFD_PAGE_KNOB_INC", "press": "G1000_PFD_CURSOR_BUTTON"},
    "G1000 PFD Page Group": {"left": "G1000_PFD_GROUP_KNOB_DEC", "right": "G1000_PFD_GROUP_KNOB_INC", "press": "G1000_PFD_CURSOR_BUTTON"},
}


class _HelperBridge:
    """Keep the helper process alive while a profile polls SimConnect values."""

    def __init__(self) -> None:
        self._process: subprocess.Popen[str] | None = None
        self._lock = threading.Lock()

    def request(self, helper: Path, payload: dict) -> dict:
        with self._lock:
            if self._process is None or self._process.poll() is not None:
                self._process = subprocess.Popen(
                    [str(helper)], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                    text=True, bufsize=1,
                )
            if self._process.stdin is None or self._process.stdout is None:
                return {"ok": False, "error": "SimConnect helper streams are unavailable"}
            try:
                self._process.stdin.write(json.dumps(payload) + "\n")
                self._process.stdin.flush()
                line = self._process.stdout.readline()
                return json.loads(line or "{}")
            except (OSError, ValueError, json.JSONDecodeError) as error:
                self._process = None
                return {"ok": False, "error": str(error)}


@lru_cache(maxsize=4)
def _catalogue(name: str) -> list[dict]:
    path = ROOT / "catalogue" / name
    if not path.exists():
        return []
    return json.loads(path.read_text(encoding="utf-8"))


class Plugin:
    """Expose standard MSFS 2020 data and commands to the shared registries."""

    def settings_schema(self) -> dict:
        return {
            "properties": {
                "address": {
                    "type": "string",
                    "title": "SimConnect address",
                    "description": "Host and TCP port exposed by SimConnect.",
                    "default": "127.0.0.1:500",
                }
            }
        }

    def __init__(self) -> None:
        self._bridge = _HelperBridge()

    def modules(self) -> list[dict]:
        modules = [
            {
                "id": "msfs.cockpit_dial",
                "name": "MSFS Cockpit Dial",
                "group": "Cockpit Controls",
                "description": "Configure a dial for common MSFS cockpit controls through standard SimConnect events.",
                "requires": ["rotary_left", "rotary_right", "press"],
                "default_settings": {"control": "Autopilot Altitude"},
                "settings_schema": {
                    "properties": {
                        "control": {
                            "type": "string",
                            "title": "Control",
                            "description": "The cockpit rotary control this dial represents.",
                            "enum": list(DIAL_CONTROLS),
                            "default": "Autopilot Altitude",
                        }
                    }
                },
            }
        ]
        modules.extend(self._display_modules())
        return modules

    @staticmethod
    def _display_settings(*, ranges: bool = False, warning: bool = False) -> dict:
        properties: dict[str, dict] = {
            "input": {
                "type": "input",
                "title": "Input",
                "extension_id": "io.github.robdevice.msfs.simconnect",
            },
            "action": {"type": "action", "title": "Action (optional)"},
            "label": {"type": "string", "title": "Label", "default": ""},
            "show_label": {"type": "boolean", "title": "Show label", "default": True},
            "show_unit": {"type": "boolean", "title": "Show unit", "default": True},
            "accent": {"type": "string", "title": "Accent colour", "default": "#39d7a5"},
        }
        if ranges:
            properties.update(
                {
                    "minimum": {"type": "number", "title": "Minimum", "default": 0},
                    "maximum": {"type": "number", "title": "Maximum", "default": 100},
                }
            )
        if warning:
            properties.update(
                {
                    "warning_enabled": {"type": "boolean", "title": "Enable warning", "default": False},
                    "warning_threshold": {"type": "number", "title": "Warning threshold", "default": 0},
                    "warning_direction": {
                        "type": "string",
                        "title": "Warn when",
                        "enum": ["Below threshold", "Above threshold"],
                        "default": "Below threshold",
                    },
                }
            )
        return {"properties": properties}

    def _display_modules(self) -> list[dict]:
        definitions = (
            ("status", "MSFS Status", "Show a clear on/off or named simulator status.", False, False),
            ("level", "MSFS Level", "Show a simulator value as a horizontal level bar.", True, True),
            ("gauge", "MSFS Gauge", "Show a simulator value on a compact gauge.", True, True),
            ("compass", "MSFS Compass", "Show heading, bearing, course, or track on a compass display.", False, False),
            ("frequency", "MSFS Frequency", "Show a radio, navigation, or transponder frequency.", False, False),
            ("clock", "MSFS Clock & Timer", "Show a simulator clock or elapsed time.", False, False),
            ("position", "MSFS Position", "Show a position, coordinate, or altitude value.", False, False),
            ("warning", "MSFS Warning", "Show a warning when a status or threshold requires attention.", False, True),
        )
        return [
            {
                "id": f"msfs.display_{kind}",
                "name": name,
                "group": "Displays",
                "description": description,
                "requires": [],
                "live_visual": True,
                "default_settings": {
                    "input": {},
                    "action": {},
                    "label": "",
                    "show_label": True,
                    "show_unit": True,
                    "accent": "#39d7a5",
                    **({"minimum": 0, "maximum": 100} if ranges else {}),
                    **({"warning_enabled": False, "warning_threshold": 0, "warning_direction": "Below threshold"} if warning else {}),
                },
                "default_visual": {"background": "#081323", "foreground": "#edf7ff", "asset_mode": "image"},
                "settings_schema": self._display_settings(ranges=ranges, warning=warning),
            }
            for kind, name, description, ranges, warning in definitions
        ]

    @staticmethod
    def _helper() -> Path:
        return ROOT / "runtime" / f"{platform.system().lower()}-{platform.machine()}" / "macro-pad-manager-msfs-helper"

    @staticmethod
    def _address(settings: dict | None) -> str:
        return str((settings or {}).get("address") or "127.0.0.1:500")

    def _request(self, payload: dict) -> dict:
        helper = self._helper()
        if not helper.exists():
            return {"ok": False, "error": "SimConnect helper is unavailable on this platform"}
        if not os.access(helper, os.X_OK):
            return {"ok": False, "error": "The SimConnect helper is not allowed to run. Repair helper permissions in Extension Settings."}
        return self._bridge.request(helper, payload)

    def inputs(self) -> list[dict]:
        inputs: list[dict] = []
        for entry in _catalogue("simvars.json"):
            item = {
                "id": f"simvar.{entry['slug']}",
                "name": entry["name"],
                "description": entry["description"],
                "group": entry["group"],
                "unit": entry["unit"],
                "data_type": entry["data_type"],
                "indexable": entry["indexable"],
                "simvar": entry["name"],
                "presentation": self._presentation_hint(entry),
            }
            properties: dict[str, dict] = {}
            if entry["indexable"]:
                properties["index"] = {"type": "integer", "title": "Index", "default": 1}
            if entry["data_type"] == "number":
                properties["decimal_places"] = {
                    "type": "integer",
                    "title": "Decimal places",
                    "description": "Number of digits to show after the decimal point.",
                    "default": self._default_decimal_places(entry),
                }
            if properties:
                item["settings_schema"] = {"properties": properties}
            inputs.append(item)
        return inputs

    @staticmethod
    def _presentation_hint(entry: dict) -> dict:
        name = str(entry.get("name", "")).upper()
        unit = str(entry.get("unit", ""))
        data_type = str(entry.get("data_type", ""))
        if data_type == "boolean" or unit.lower() == "bool":
            kind = "status"
        elif "FREQUENCY" in name or "TRANSPONDER" in name:
            kind = "frequency"
        elif any(token in name for token in ("HEADING", "BEARING", "COURSE", "TRACK")):
            kind = "compass"
        elif any(token in name for token in ("TIME", "TIMER", "DURATION")):
            kind = "clock"
        elif any(token in name for token in ("LATITUDE", "LONGITUDE", "POSITION")):
            kind = "position"
        elif "ALTITUDE" in name:
            kind = "gauge"
        elif "PERCENT" in unit.upper() or unit.lower() in {"percent over 100", "ratio"}:
            kind = "level"
        elif any(token in name for token in ("RPM", "TEMPERATURE", "PRESSURE", "SPEED", "VOLTAGE", "CURRENT")):
            kind = "gauge"
        else:
            kind = "value"
        hint = {"kind": kind, "unit": unit}
        if "PERCENT" in unit.upper():
            hint.update({"minimum": 0, "maximum": 100})
        elif unit.lower() in {"percent over 100", "ratio"}:
            hint.update({"minimum": 0, "maximum": 1})
        return hint

    @staticmethod
    def _default_decimal_places(entry: dict) -> int:
        name = str(entry.get("name", "")).lower()
        if "altitude" in name:
            return 0
        return 2

    @staticmethod
    def _format_readout_value(value, decimal_places: object) -> object:
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            return value
        try:
            places = max(0, min(6, int(decimal_places)))
        except (TypeError, ValueError):
            places = 2
        if places == 0:
            return str(int(round(value)))
        return f"{value:.{places}f}".rstrip("0").rstrip(".")

    def actions(self) -> list[dict]:
        actions: list[dict] = []
        for entry in _catalogue("key_events.json"):
            actions.append(
                {
                    "id": f"key_event.{entry['slug']}",
                    "name": entry["name"],
                    "description": entry["description"],
                    "group": entry["group"],
                    "key_event": entry["name"],
                    "settings_schema": {
                        "properties": {
                            "parameter": {
                                "type": "integer",
                                "title": "Parameter",
                                "description": entry["parameters"] or "SimConnect event parameter.",
                                "default": 0,
                            }
                        }
                    },
                }
            )
        for entry in _catalogue("simvars.json"):
            if not entry["settable"]:
                continue
            actions.append(
                {
                    "id": f"set_simvar.{entry['slug']}",
                    "name": f"Set {entry['name']}",
                    "description": f"Write {entry['name']} through SimConnect.",
                    "group": f"Set SimVars / {entry['group']}",
                    "simvar": entry["name"],
                    "unit": entry["unit"],
                    "data_type": entry["data_type"],
                    "settings_schema": {
                        "properties": {
                            "value": {"type": entry["data_type"], "title": "Value"},
                            **({"index": {"type": "integer", "title": "Index", "default": 1}} if entry["indexable"] else {}),
                        }
                    },
                }
            )
        actions.append(
            {
                "id": "advanced_simvar_output",
                "name": "Advanced SimVar Output",
                "description": "Write a custom documented SimVar through SimConnect.",
                "group": "Advanced",
                "settings_schema": {
                    "properties": {
                        "simvar": {"type": "string", "title": "Simulation Variable"},
                        "unit": {"type": "string", "title": "Unit"},
                        "value": {"type": "number", "title": "Value"},
                        "index": {"type": "integer", "title": "Index", "default": 0},
                    }
                },
            }
        )
        return actions

    def connection_status(self, settings: dict | None = None) -> dict:
        address = self._address(settings)
        helper = self._helper()
        if not helper.exists():
            return {"address": address, "state": "unsupported_platform"}
        if not os.access(helper, os.X_OK):
            return {
                "address": address,
                "state": "helper_not_executable",
                "error": "The SimConnect helper was installed without permission to run.",
                "remediation": "Repair helper permissions, then test the connection again.",
                "repairable": True,
                "repair_label": "Repair Helper Permissions",
            }
        try:
            response = self._request({"operation": "probe", "address": address})
            if response.get("ok"):
                return {
                    "address": address,
                    "state": "connected",
                    "message": "SimConnect accepted a connection at this address.",
                }
            return self._connection_failure(address, str(response.get("error") or "SimConnect did not return a response"))
        except (OSError, subprocess.SubprocessError, json.JSONDecodeError) as error:
            return self._connection_failure(address, str(error))

    @staticmethod
    def _connection_failure(address: str, error: str) -> dict:
        normalized_error = error.casefold()
        result = {"address": address, "state": "unavailable", "error": error}
        if "connection refused" in normalized_error:
            result.update(
                {
                    "message": f"No SimConnect service is listening at {address}.",
                    "remediation": (
                        "Start MSFS and the SimConnect TCP listener, or change the address to the endpoint "
                        "that MSFS is exposing. The extension cannot start SimConnect itself."
                    ),
                }
            )
        elif "timed out" in normalized_error:
            result.update(
                {
                    "message": f"SimConnect at {address} did not respond in time.",
                    "remediation": "Confirm that MSFS is running and that the configured host and port are reachable from this computer.",
                }
            )
        else:
            result.update(
                {
                    "message": f"SimConnect could not be reached at {address}.",
                    "remediation": "Check that MSFS is running and that the configured host and port are correct, then test again.",
                }
            )
        return result

    def repair_connection(self, settings: dict | None = None) -> dict:
        """Restore user execute permission on the packaged native helper."""
        helper = self._helper()
        if not helper.exists():
            return {"ok": False, "error": "SimConnect helper is unavailable on this platform"}
        try:
            helper.chmod(helper.stat().st_mode | stat.S_IXUSR)
        except OSError as error:
            return {"ok": False, "error": f"Could not repair helper permissions: {error}"}
        return {"ok": True, "message": "Helper permissions repaired"}

    def read_input(self, input_definition: dict, input_settings: dict | None = None, extension_settings: dict | None = None) -> dict:
        input_settings = input_settings or {}
        response = self._request(
            {
                "operation": "read_simvar",
                "address": self._address(extension_settings),
                "simvar": input_definition.get("simvar", ""),
                "unit": input_definition.get("unit") or None,
                "index": input_settings.get("index"),
                "data_type": input_definition.get("data_type", "number"),
            }
        )
        if not response.get("ok"):
            raise RuntimeError(str(response.get("error") or "SimConnect read failed"))
        return {
            "value": self._format_readout_value(
                response.get("value", "--"),
                input_settings.get("decimal_places", self._default_decimal_places(input_definition)),
            ),
            "raw_value": response.get("value", "--"),
            "unit": input_definition.get("unit", ""),
            "presentation": dict(input_definition.get("presentation", {})),
        }

    def execute_action(
        self,
        action: dict,
        action_settings: dict | None = None,
        extension_settings: dict | None = None,
    ) -> dict:
        """Run a documented Key Event or writable SimVar through SimConnect."""
        action_settings = action_settings or {}
        address = self._address(extension_settings)
        event = str(action.get("key_event") or "").strip()
        if event:
            return self._request({"operation": "key_event", "address": address, "event": event, "parameter": action_settings.get("parameter", 0)})
        simvar = str(action_settings.get("simvar") or action.get("simvar") or "").strip()
        if not simvar:
            return {"ok": False, "error": "No SimVar was selected"}
        return self._request(
            {
                "operation": "set_simvar",
                "address": address,
                "simvar": simvar,
                "unit": action_settings.get("unit") or action.get("unit") or None,
                "index": action_settings.get("index"),
                "data_type": action.get("data_type", "number"),
                "value": action_settings.get("value", 0),
            }
        )

    def execute_module(
        self,
        module_payload: dict,
        event: dict,
        _context,
        extension_settings: dict | None = None,
    ) -> None:
        """Handle the fixed, real-world control mappings exposed by MSFS Cockpit Dial."""
        module_type = str(module_payload.get("type", ""))
        if module_type.startswith("msfs.display_"):
            selection = dict(module_payload.get("settings", {}).get("action", {}))
            if str(event.get("trigger_id", "")) in {"press", "touch"} and selection.get("id") and _context is not None:
                _context.extension_action(selection, control_id=str(event.get("control_id", "plugin")))
            return
        if module_type != "msfs.cockpit_dial":
            raise RuntimeError(f"Unsupported MSFS module: {module_payload.get('type', '')}")
        control = str(module_payload.get("settings", {}).get("control") or "Autopilot Altitude")
        mapping = DIAL_CONTROLS.get(control)
        if mapping is None:
            raise RuntimeError(f"Unsupported MSFS cockpit dial control: {control}")
        trigger = str(event.get("trigger_id", ""))
        address = self._address(extension_settings)
        if trigger == "press" and mapping.get("press") == "heading_sync":
            heading = self._read_magnetic_heading(address)
            self._send_key_event(address, "HEADING_BUG_SET", heading)
            return
        key_event = mapping.get(trigger)
        if key_event:
            self._send_key_event(address, str(key_event), int(mapping.get("parameter", 0)))

    def _input_definition(self, identifier: str) -> dict | None:
        if not identifier.startswith("simvar."):
            return None
        slug = identifier.removeprefix("simvar.")
        for entry in _catalogue("simvars.json"):
            if str(entry.get("slug", "")) == slug:
                return {
                    "id": identifier,
                    "name": entry["name"],
                    "description": entry["description"],
                    "group": entry["group"],
                    "unit": entry["unit"],
                    "data_type": entry["data_type"],
                    "indexable": entry["indexable"],
                    "simvar": entry["name"],
                    "presentation": self._presentation_hint(entry),
                }
        return None

    @staticmethod
    def _colour(value: str, fallback: str) -> tuple[int, int, int]:
        try:
            return ImageColor.getrgb(value)
        except ValueError:
            return ImageColor.getrgb(fallback)

    @staticmethod
    def _font(size: int, *, bold: bool = False) -> ImageFont.ImageFont:
        names = ("DejaVuSans-Bold.ttf", "DejaVuSans.ttf") if bold else ("DejaVuSans.ttf", "DejaVuSans-Bold.ttf")
        for name in names:
            try:
                return ImageFont.truetype(name, size)
            except OSError:
                continue
        return ImageFont.load_default()

    @staticmethod
    def _number(value: object) -> float | None:
        if isinstance(value, bool):
            return float(value)
        try:
            return float(value)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _timer_text(value: object) -> str:
        seconds = Plugin._number(value)
        if seconds is None:
            return str(value)
        seconds = max(0, int(round(seconds)))
        hours, remainder = divmod(seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        return f"{hours:02}:{minutes:02}:{seconds:02}"

    def render_live_visual(self, module_payload: dict, extension_settings: dict | None = None) -> dict:
        settings = dict(module_payload.get("settings", {}))
        selection = settings.get("input", {})
        identifier = str(selection.get("id", "")) if isinstance(selection, dict) else ""
        definition = self._input_definition(identifier)
        if definition is None:
            return self._render_display(module_payload, "Choose an input", None, "", unavailable=True)
        try:
            readout = self.read_input(definition, dict(selection.get("settings", {})), extension_settings)
        except Exception as exc:  # noqa: BLE001
            return self._render_display(module_payload, str(definition["name"]), None, str(exc)[:32], unavailable=True)
        return self._render_display(
            module_payload,
            str(settings.get("label") or definition["name"]),
            readout.get("raw_value"),
            str(readout.get("unit") or ""),
            formatted=str(readout.get("value") or "--"),
            presentation=dict(readout.get("presentation") or {}),
        )

    def _render_display(
        self,
        module_payload: dict,
        title: str,
        raw_value: object,
        unit: str,
        *,
        formatted: str = "--",
        unavailable: bool = False,
        presentation: dict | None = None,
    ) -> dict:
        settings = dict(module_payload.get("settings", {}))
        visual = dict(module_payload.get("visual", {}))
        kind = str(module_payload.get("type", "msfs.display_status")).removeprefix("msfs.display_")
        width, height = 480, 270
        background = self._colour(str(visual.get("background", "#081323")), "#081323")
        foreground = self._colour(str(visual.get("foreground", "#edf7ff")), "#edf7ff")
        accent = self._colour(str(settings.get("accent", "#39d7a5")), "#39d7a5")
        warning_colour = (255, 170, 45)
        image = Image.new("RGB", (width, height), background)
        draw = ImageDraw.Draw(image)
        draw.rounded_rectangle((4, 4, width - 5, height - 5), radius=20, outline=tuple(max(0, channel - 85) for channel in accent), width=3)
        if settings.get("show_label", True):
            draw.text((24, 20), title[:34], fill=foreground, font=self._font(24, bold=True))

        number = self._number(raw_value)
        shown_value = formatted
        if settings.get("show_unit", True) and unit and unit.lower() not in {"bool", "boolean"}:
            shown_value = f"{shown_value} {unit}".strip()
        if kind == "clock":
            shown_value = self._timer_text(raw_value)

        suggested_range = dict(presentation or {})
        if unavailable:
            draw.text((24, 112), "SimConnect unavailable", fill=warning_colour, font=self._font(27, bold=True))
            draw.text((24, 154), unit or "Check the extension connection setting.", fill=foreground, font=self._font(18))
        elif kind in {"status", "warning"}:
            active = bool(raw_value)
            if number is not None and kind == "warning" and settings.get("warning_enabled", False):
                threshold = float(settings.get("warning_threshold", 0))
                active = number < threshold if settings.get("warning_direction") == "Below threshold" else number > threshold
            colour = warning_colour if kind == "warning" and active else accent if active else (112, 128, 150)
            draw.ellipse((34, 104, 114, 184), fill=colour)
            state = "WARNING" if kind == "warning" and active else "ACTIVE" if active else "NORMAL"
            draw.text((138, 118), state, fill=foreground, font=self._font(36, bold=True))
            draw.text((138, 164), shown_value, fill=colour, font=self._font(19))
        elif kind == "level":
            minimum, maximum = float(settings.get("minimum", 0)), float(settings.get("maximum", 100))
            if minimum == 0 and maximum == 100 and suggested_range.get("maximum") == 1:
                maximum = 1
            ratio = 0.0 if number is None or maximum <= minimum else max(0.0, min(1.0, (number - minimum) / (maximum - minimum)))
            draw.text((24, 88), shown_value, fill=foreground, font=self._font(38, bold=True))
            draw.rounded_rectangle((24, 164, width - 24, 204), radius=20, fill=(30, 47, 66))
            if ratio:
                draw.rounded_rectangle((24, 164, 24 + int((width - 48) * ratio), 204), radius=20, fill=accent)
        elif kind == "gauge":
            minimum, maximum = float(settings.get("minimum", 0)), float(settings.get("maximum", 100))
            ratio = 0.0 if number is None or maximum <= minimum else max(0.0, min(1.0, (number - minimum) / (maximum - minimum)))
            box = (150, 62, 330, 242)
            draw.arc(box, 135, 405, fill=(30, 47, 66), width=16)
            draw.arc(box, 135, 135 + int(270 * ratio), fill=accent, width=16)
            draw.text((width // 2, 145), shown_value, anchor="mm", fill=foreground, font=self._font(29, bold=True))
        elif kind == "compass":
            degrees = 0.0 if number is None else number
            if abs(degrees) <= (math.tau + 0.01):
                degrees = math.degrees(degrees)
            degrees %= 360
            center = (width // 2, 151)
            radius = 76
            draw.ellipse((center[0] - radius, center[1] - radius, center[0] + radius, center[1] + radius), outline=accent, width=6)
            angle = math.radians(degrees - 90)
            tip = (center[0] + int(math.cos(angle) * 60), center[1] + int(math.sin(angle) * 60))
            draw.line((center, tip), fill=foreground, width=7)
            draw.text((center[0], 240), f"{degrees:03.0f}°", anchor="mm", fill=foreground, font=self._font(25, bold=True))
        elif kind == "frequency":
            draw.text((width // 2, 142), shown_value, anchor="mm", fill=accent, font=self._font(52, bold=True))
        elif kind == "position":
            draw.text((24, 112), shown_value, fill=foreground, font=self._font(34, bold=True))
            draw.text((24, 166), "Simulator position", fill=accent, font=self._font(19))
        else:
            draw.text((width // 2, 145), shown_value, anchor="mm", fill=foreground, font=self._font(42, bold=True))

        buffer = BytesIO()
        image.save(buffer, format="PNG")
        return {"title": title, "value": formatted, "subtitle": unit or "MSFS", "image_png": buffer.getvalue()}

    def _read_magnetic_heading(self, address: str) -> int:
        response = self._request(
            {
                "operation": "read_simvar",
                "address": address,
                "simvar": "PLANE HEADING DEGREES MAGNETIC",
                "unit": "Degrees",
                "index": None,
                "data_type": "number",
            }
        )
        if not response.get("ok"):
            raise RuntimeError(str(response.get("error") or "Could not read the current magnetic heading"))
        try:
            return int(round(float(response.get("value")))) % 360
        except (TypeError, ValueError) as error:
            raise RuntimeError("SimConnect returned an invalid magnetic heading") from error

    def _send_key_event(self, address: str, event: str, parameter: int = 0) -> None:
        response = self._request(
            {"operation": "key_event", "address": address, "event": event, "parameter": parameter}
        )
        if not response.get("ok"):
            raise RuntimeError(str(response.get("error") or f"SimConnect rejected {event}"))

    def copy_input(self, identifier: str) -> dict | None:
        return next((copy.deepcopy(item) for item in self.inputs() if item["id"] == identifier), None)
