from __future__ import annotations

import copy
from functools import lru_cache
from io import BytesIO
import json
import math
import os
from pathlib import Path
import platform
import stat
import subprocess
import threading
import time

from PIL import Image, ImageColor, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]


DIAL_CONTROLS: dict[str, dict[str, str | int]] = {
    "Autopilot Altitude": {"left": "AP_ALT_VAR_DEC", "right": "AP_ALT_VAR_INC", "parameter": 1},
    # The relative Heading Bug events only apply to a previously selected bug.
    # Read and set the standard reference instead so this preset works across
    # aircraft without relying on a cockpit-specific selection state.
    "Heading Bug": {"left": "heading_bug_decrement", "right": "heading_bug_increment", "press": "heading_sync"},
    "Autopilot Vertical Speed": {"left": "AP_VS_VAR_DEC", "right": "AP_VS_VAR_INC"},
    "Autopilot Airspeed": {"left": "AP_SPD_VAR_DEC", "right": "AP_SPD_VAR_INC"},
    "COM 1 Fine Frequency": {"left": "COM1_RADIO_FRACT_DEC", "right": "COM1_RADIO_FRACT_INC"},
    "COM 1 Coarse Frequency": {"left": "COM1_RADIO_WHOLE_DEC", "right": "COM1_RADIO_WHOLE_INC"},
    "COM 2 Fine Frequency": {"left": "COM2_RADIO_FRACT_DEC", "right": "COM2_RADIO_FRACT_INC"},
    "COM 2 Coarse Frequency": {"left": "COM2_RADIO_WHOLE_DEC", "right": "COM2_RADIO_WHOLE_INC"},
    "NAV 1 Fine Frequency": {"left": "NAV1_RADIO_FRACT_DEC", "right": "NAV1_RADIO_FRACT_INC"},
    "NAV 1 Coarse Frequency": {"left": "NAV1_RADIO_WHOLE_DEC", "right": "NAV1_RADIO_WHOLE_INC"},
    "NAV 2 Fine Frequency": {"left": "NAV2_RADIO_FRACT_DEC", "right": "NAV2_RADIO_FRACT_INC"},
    "NAV 2 Coarse Frequency": {"left": "NAV2_RADIO_WHOLE_DEC", "right": "NAV2_RADIO_WHOLE_INC"},
    "NAV 1 Course": {"left": "VOR1_OBI_DEC", "right": "VOR1_OBI_INC"},
    "NAV 1 Course (10 degrees)": {"left": "VOR1_OBI_FAST_DEC", "right": "VOR1_OBI_FAST_INC"},
    "NAV 2 Course": {"left": "VOR2_OBI_DEC", "right": "VOR2_OBI_INC"},
    "NAV 2 Course (10 degrees)": {"left": "VOR2_OBI_FAST_DEC", "right": "VOR2_OBI_FAST_INC"},
    "Transponder Digit 1": {"left": "XPNDR_1000_DEC", "right": "XPNDR_1000_INC"},
    "Transponder Digit 2": {"left": "XPNDR_100_DEC", "right": "XPNDR_100_INC"},
    "Transponder Digit 3": {"left": "XPNDR_10_DEC", "right": "XPNDR_10_INC"},
    "Transponder Digit 4": {"left": "XPNDR_1_DEC", "right": "XPNDR_1_INC"},
    "Transponder Code & IDENT": {"left": "XPNDR_DEC_CARRY", "right": "XPNDR_INC_CARRY", "press": "XPNDR_IDENT_TOGGLE"},
    "Transponder Mode": {
        "left": "stepped_simvar_decrement",
        "right": "stepped_simvar_increment",
        "press": "XPNDR_IDENT_TOGGLE",
        "simvar": "TRANSPONDER STATE",
        "unit": "Enum: 0 = Off 1 = Standby 2 = Test 3 = On 4 = Alt 5 = Ground",
        "index": 1,
        "minimum": 0,
        "maximum": 5,
    },
    "Altimeter Pressure": {"left": "KOHLSMAN_DEC", "right": "KOHLSMAN_INC"},
    "G1000 PFD Page": {"left": "G1000_PFD_PAGE_KNOB_DEC", "right": "G1000_PFD_PAGE_KNOB_INC", "press": "G1000_PFD_CURSOR_BUTTON"},
    "G1000 PFD Page Group": {"left": "G1000_PFD_GROUP_KNOB_DEC", "right": "G1000_PFD_GROUP_KNOB_INC", "press": "G1000_PFD_CURSOR_BUTTON"},
    "Magneto & Starter": {"left": "MAGNETO_DECR", "right": "MAGNETO_INCR", "press": "MAGNETO_START"},
    "Cockpit Brightness 1": {"left": "LIGHT_POTENTIOMETER_DEC", "right": "LIGHT_POTENTIOMETER_INC", "parameter": 1},
    "Cockpit Brightness 2": {"left": "LIGHT_POTENTIOMETER_DEC", "right": "LIGHT_POTENTIOMETER_INC", "parameter": 2},
    "Cockpit Brightness 3": {"left": "LIGHT_POTENTIOMETER_DEC", "right": "LIGHT_POTENTIOMETER_INC", "parameter": 3},
    "Cockpit Brightness 4": {"left": "LIGHT_POTENTIOMETER_DEC", "right": "LIGHT_POTENTIOMETER_INC", "parameter": 4},
}


# These cards keep the long-standing control strings as their values, so
# profiles continue to use the same SimConnect event mappings after the UI move.
DIAL_CONTROL_PRESETS: tuple[dict[str, str], ...] = (
    {"value": "Autopilot Altitude", "group": "Autopilot", "icon": "gauge"},
    {"value": "Heading Bug", "group": "Autopilot", "icon": "navigation-arrow"},
    {"value": "Autopilot Vertical Speed", "group": "Autopilot", "icon": "gauge"},
    {"value": "Autopilot Airspeed", "group": "Autopilot", "icon": "gauge"},
    {"value": "COM 1 Fine Frequency", "group": "Communications", "icon": "radio"},
    {"value": "COM 1 Coarse Frequency", "group": "Communications", "icon": "radio"},
    {"value": "COM 2 Fine Frequency", "group": "Communications", "icon": "radio"},
    {"value": "COM 2 Coarse Frequency", "group": "Communications", "icon": "radio"},
    {"value": "NAV 1 Fine Frequency", "group": "Navigation", "icon": "compass"},
    {"value": "NAV 1 Coarse Frequency", "group": "Navigation", "icon": "compass"},
    {"value": "NAV 2 Fine Frequency", "group": "Navigation", "icon": "compass"},
    {"value": "NAV 2 Coarse Frequency", "group": "Navigation", "icon": "compass"},
    {"value": "NAV 1 Course", "group": "Navigation", "icon": "navigation-arrow"},
    {"value": "NAV 1 Course (10 degrees)", "group": "Navigation", "icon": "navigation-arrow"},
    {"value": "NAV 2 Course", "group": "Navigation", "icon": "navigation-arrow"},
    {"value": "NAV 2 Course (10 degrees)", "group": "Navigation", "icon": "navigation-arrow"},
    {"value": "Transponder Digit 1", "group": "Navigation", "icon": "keyboard"},
    {"value": "Transponder Digit 2", "group": "Navigation", "icon": "keyboard"},
    {"value": "Transponder Digit 3", "group": "Navigation", "icon": "keyboard"},
    {"value": "Transponder Digit 4", "group": "Navigation", "icon": "keyboard"},
    {"value": "Transponder Code & IDENT", "group": "Navigation", "icon": "radio"},
    {"value": "Transponder Mode", "group": "Navigation", "icon": "radio"},
    {"value": "Altimeter Pressure", "group": "Navigation", "icon": "gauge"},
    {"value": "G1000 PFD Page", "group": "G1000", "icon": "sliders"},
    {"value": "G1000 PFD Page Group", "group": "G1000", "icon": "sliders"},
    {"value": "Magneto & Starter", "group": "Engines & Systems", "icon": "engine"},
    {"value": "Cockpit Brightness 1", "group": "Cockpit Lighting", "icon": "lightbulb"},
    {"value": "Cockpit Brightness 2", "group": "Cockpit Lighting", "icon": "lightbulb"},
    {"value": "Cockpit Brightness 3", "group": "Cockpit Lighting", "icon": "lightbulb"},
    {"value": "Cockpit Brightness 4", "group": "Cockpit Lighting", "icon": "lightbulb"},
)


STATUS_PRESETS: tuple[dict[str, object], ...] = (
    # Flight and ground operation.
    {"id": "parking_brake", "group": "Flight & Ground", "name": "Parking Brake", "slug": "brake_parking_position", "label": "Parking Brake", "active_text": "SET", "inactive_text": "RELEASED", "active_icon": "car", "inactive_icon": "airplane", "active_colour": "#FFB454", "inactive_colour": "#708096"},
    {"id": "on_ground", "group": "Flight & Ground", "name": "On Ground", "slug": "sim_on_ground", "label": "Aircraft", "active_text": "ON GROUND", "inactive_text": "AIRBORNE", "active_icon": "airplane-landing", "inactive_icon": "airplane-in-flight", "active_colour": "#39D7A5", "inactive_colour": "#43B5FF"},
    {"id": "on_runway", "group": "Flight & Ground", "name": "On Runway", "slug": "on_any_runway", "label": "Runway", "active_text": "ON RUNWAY", "inactive_text": "OFF RUNWAY", "active_icon": "airplane-taxiing", "inactive_icon": "airplane-in-flight", "active_colour": "#39D7A5", "inactive_colour": "#708096"},
    {"id": "parked", "group": "Flight & Ground", "name": "Parked", "slug": "plane_in_parking_state", "label": "Aircraft", "active_text": "PARKED", "inactive_text": "MOVING", "active_icon": "car", "inactive_icon": "airplane", "active_colour": "#39D7A5", "inactive_colour": "#708096"},
    {"id": "pushback_attached", "group": "Flight & Ground", "name": "Pushback Attached", "slug": "pushback_attached", "label": "Pushback", "active_text": "ATTACHED", "inactive_text": "CLEAR", "active_icon": "anchor", "inactive_icon": "circle", "active_colour": "#43B5FF", "inactive_colour": "#708096"},
    {"id": "pushback_available", "group": "Flight & Ground", "name": "Pushback Available", "slug": "pushback_available", "label": "Pushback", "active_text": "AVAILABLE", "inactive_text": "UNAVAILABLE", "active_icon": "anchor", "inactive_icon": "circle", "active_colour": "#39D7A5", "inactive_colour": "#708096"},
    {"id": "spoilers_armed", "group": "Flight & Ground", "name": "Spoilers Armed", "slug": "spoilers_armed", "label": "Spoilers", "active_text": "ARMED", "inactive_text": "DISARMED", "active_icon": "airplane-tilt", "inactive_icon": "airplane", "active_colour": "#FFB454", "inactive_colour": "#708096"},
    # Autopilot.
    {"id": "autopilot_master", "group": "Autopilot", "name": "Autopilot Master", "slug": "autopilot_master", "label": "Autopilot", "active_text": "ENGAGED", "inactive_text": "OFF", "active_icon": "navigation-arrow", "inactive_icon": "power", "active_colour": "#43B5FF", "inactive_colour": "#708096"},
    {"id": "flight_director", "group": "Autopilot", "name": "Flight Director", "slug": "autopilot_flight_director_active", "label": "Flight Director", "active_text": "ACTIVE", "inactive_text": "OFF", "active_icon": "navigation-arrow", "inactive_icon": "circle", "active_colour": "#9D7CFF", "inactive_colour": "#708096"},
    {"id": "heading_hold", "group": "Autopilot", "name": "Heading Mode", "slug": "autopilot_heading_lock", "label": "Heading", "active_text": "HDG", "inactive_text": "OFF", "active_icon": "navigation-arrow", "inactive_icon": "circle", "active_colour": "#43B5FF", "inactive_colour": "#708096"},
    {
        "id": "altitude_hold",
        "group": "Autopilot",
        "name": "Altitude Mode",
        "label": "Altitude",
        "mode": "multi_state",
        "resolver": "altitude_mode",
        "preview_icon": "gauge",
        "states": [
            {"id": "off", "label": "Off", "text": "OFF", "icon": "circle", "colour": "#708096"},
            {"id": "armed", "label": "Armed", "text": "ARM", "icon": "target", "colour": "#FFB454"},
            {"id": "hold", "label": "Holding", "text": "ALT", "icon": "gauge", "colour": "#9D7CFF"},
        ],
    },
    {"id": "altitude_arm", "group": "Autopilot", "name": "Altitude Arm", "slug": "autopilot_altitude_arm", "label": "Altitude", "active_text": "ARMED", "inactive_text": "UNARMED", "active_icon": "gauge", "inactive_icon": "circle", "active_colour": "#FFB454", "inactive_colour": "#708096"},
    {"id": "approach", "group": "Autopilot", "name": "Approach Active", "slug": "autopilot_approach_active", "label": "Approach", "active_text": "ACTIVE", "inactive_text": "OFF", "active_icon": "airplane-landing", "inactive_icon": "circle", "active_colour": "#43B5FF", "inactive_colour": "#708096"},
    {"id": "nav_mode", "group": "Autopilot", "name": "NAV Mode", "slug": "autopilot_nav1_lock", "label": "NAV Mode", "active_text": "ACTIVE", "inactive_text": "OFF", "active_icon": "navigation-arrow", "inactive_icon": "circle", "active_colour": "#43B5FF", "inactive_colour": "#708096"},
    {"id": "glideslope", "group": "Autopilot", "name": "Glideslope", "slug": "autopilot_glideslope_active", "label": "Glideslope", "active_text": "CAPTURED", "inactive_text": "OFF", "active_icon": "airplane-landing", "inactive_icon": "circle", "active_colour": "#9D7CFF", "inactive_colour": "#708096"},
    {"id": "autothrottle", "group": "Autopilot", "name": "Autothrottle", "slug": "autothrottle_active", "label": "Autothrottle", "active_text": "ACTIVE", "inactive_text": "OFF", "active_icon": "gauge", "inactive_icon": "power", "active_colour": "#43B5FF", "inactive_colour": "#708096"},
    {"id": "yaw_damper", "group": "Autopilot", "name": "Yaw Damper", "slug": "autopilot_yaw_damper", "label": "Yaw Damper", "active_text": "ACTIVE", "inactive_text": "OFF", "active_icon": "airplane-tilt", "inactive_icon": "circle", "active_colour": "#39D7A5", "inactive_colour": "#708096"},
    # Electrical system.
    {"id": "battery_master", "group": "Electrical", "name": "Battery Master", "slug": "electrical_master_battery", "label": "Battery", "active_text": "ON", "inactive_text": "OFF", "active_icon": "battery-full", "inactive_icon": "battery-empty", "active_colour": "#39D7A5", "inactive_colour": "#708096"},
    {"id": "alternator", "group": "Electrical", "name": "Alternator", "slug": "general_eng_master_alternator", "label": "Alternator", "active_text": "ON", "inactive_text": "OFF", "active_icon": "lightning", "inactive_icon": "power", "active_colour": "#39D7A5", "inactive_colour": "#708096", "index": 1},
    {"id": "avionics_circuit", "group": "Electrical", "name": "Avionics Circuit", "slug": "circuit_avionics_on", "label": "Avionics", "active_text": "POWERED", "inactive_text": "NO POWER", "active_icon": "gauge", "inactive_icon": "power", "active_colour": "#39D7A5", "inactive_colour": "#FFB454"},
    {"id": "avionics_master_1", "group": "Electrical", "name": "Avionics 1", "slug": "avionics_master_switch", "label": "Avionics 1", "active_text": "ON", "inactive_text": "OFF", "active_icon": "gauge", "inactive_icon": "power", "active_colour": "#39D7A5", "inactive_colour": "#708096", "index": 1},
    {"id": "avionics_master_2", "group": "Electrical", "name": "Avionics 2", "slug": "avionics_master_switch", "label": "Avionics 2", "active_text": "ON", "inactive_text": "OFF", "active_icon": "gauge", "inactive_icon": "power", "active_colour": "#39D7A5", "inactive_colour": "#708096", "index": 2},
    {"id": "battery_bus", "group": "Electrical", "name": "Battery Bus", "slug": "electrical_battery_bus_voltage", "label": "Battery Bus", "mode": "condition", "comparison": "gt", "threshold": 10, "show_value": True, "active_text": "POWERED", "inactive_text": "LOW POWER", "active_icon": "battery-full", "inactive_icon": "battery-empty", "active_colour": "#39D7A5", "inactive_colour": "#FFB454"},
    {"id": "main_bus", "group": "Electrical", "name": "Main Bus", "slug": "electrical_main_bus_voltage", "label": "Main Bus", "mode": "condition", "comparison": "gt", "threshold": 10, "show_value": True, "active_text": "POWERED", "inactive_text": "LOW POWER", "active_icon": "plugs-connected", "inactive_icon": "plugs", "active_colour": "#39D7A5", "inactive_colour": "#FFB454"},
    {"id": "avionics_bus", "group": "Electrical", "name": "Avionics Bus", "slug": "electrical_avionics_bus_voltage", "label": "Avionics Bus", "mode": "condition", "comparison": "gt", "threshold": 10, "show_value": True, "active_text": "POWERED", "inactive_text": "LOW POWER", "active_icon": "gauge", "inactive_icon": "power", "active_colour": "#39D7A5", "inactive_colour": "#FFB454"},
    {"id": "generator_bus", "group": "Electrical", "name": "Generator Bus", "slug": "electrical_genalt_bus_voltage", "label": "Generator Bus", "mode": "condition", "comparison": "gt", "threshold": 10, "show_value": True, "active_text": "POWERED", "inactive_text": "LOW POWER", "active_icon": "lightning", "inactive_icon": "power", "active_colour": "#39D7A5", "inactive_colour": "#FFB454", "index": 1},
    # Engine and aircraft systems.
    {"id": "engine_running", "group": "Engines & Systems", "name": "Engine Running", "slug": "eng_combustion", "label": "Engine", "active_text": "RUNNING", "inactive_text": "STOPPED", "active_icon": "engine", "inactive_icon": "power", "active_colour": "#39D7A5", "inactive_colour": "#708096", "index": 1},
    {"id": "starter_active", "group": "Engines & Systems", "name": "Starter Active", "slug": "general_eng_starter_active", "label": "Starter", "active_text": "STARTING", "inactive_text": "IDLE", "active_icon": "engine", "inactive_icon": "power", "active_colour": "#FFB454", "inactive_colour": "#708096", "index": 1},
    {
        "id": "magneto_starter",
        "group": "Engines & Systems",
        "name": "Magneto & Starter",
        "label": "Magneto",
        "mode": "multi_state",
        "resolver": "magneto_starter",
        "engine_indexed": True,
        "engine": 1,
        "preview_icon": "engine",
        "states": [
            {"id": "off", "label": "Off", "text": "OFF", "icon": "power", "colour": "#708096"},
            {"id": "left", "label": "Left", "text": "LEFT", "icon": "arrow-left", "colour": "#43B5FF"},
            {"id": "right", "label": "Right", "text": "RIGHT", "icon": "arrow-right", "colour": "#9D7CFF"},
            {"id": "both", "label": "Both", "text": "BOTH", "icon": "engine", "colour": "#39D7A5"},
            {"id": "starting", "label": "Starting", "text": "STARTING", "icon": "engine", "colour": "#FFB454"},
        ],
    },
    {"id": "fuel_pump", "group": "Engines & Systems", "name": "Fuel Pump", "slug": "general_eng_fuel_pump_on", "label": "Fuel Pump", "active_text": "ON", "inactive_text": "OFF", "active_icon": "engine", "inactive_icon": "power", "active_colour": "#39D7A5", "inactive_colour": "#708096", "index": 1},
    {"id": "generator", "group": "Engines & Systems", "name": "Generator", "slug": "general_eng_generator_active", "label": "Generator", "active_text": "ONLINE", "inactive_text": "OFFLINE", "active_icon": "power", "inactive_icon": "circle", "active_colour": "#39D7A5", "inactive_colour": "#708096", "index": 1},
    {"id": "engine_anti_ice", "group": "Engines & Systems", "name": "Engine Anti-Ice", "slug": "eng_anti_ice", "label": "Engine Anti-Ice", "active_text": "ON", "inactive_text": "OFF", "active_icon": "snowflake", "inactive_icon": "circle", "active_colour": "#43B5FF", "inactive_colour": "#708096", "index": 1},
    {"id": "carb_heat", "group": "Engines & Systems", "name": "Carb Heat / Alternate Air", "slug": "recip_eng_alternate_air_position", "label": "Carb Heat", "mode": "condition", "comparison": "gt", "threshold": 0, "active_text": "ON", "inactive_text": "OFF", "active_icon": "thermometer-hot", "inactive_icon": "power", "active_colour": "#FFB454", "inactive_colour": "#708096", "index": 1},
    {"id": "pitot_heat", "group": "Engines & Systems", "name": "Pitot Heat", "slug": "pitot_heat", "label": "Pitot Heat", "active_text": "ON", "inactive_text": "OFF", "active_icon": "fan", "inactive_icon": "circle", "active_colour": "#FFB454", "inactive_colour": "#708096"},
    # Lighting and navigation.
    {"id": "landing_lights", "group": "Lights", "name": "Landing Lights", "slug": "light_landing", "label": "Landing Lights", "active_text": "ON", "inactive_text": "OFF", "active_icon": "headlights", "inactive_icon": "circle", "active_colour": "#FFB454", "inactive_colour": "#708096"},
    {"id": "taxi_lights", "group": "Lights", "name": "Taxi Lights", "slug": "light_taxi", "label": "Taxi Lights", "active_text": "ON", "inactive_text": "OFF", "active_icon": "headlights", "inactive_icon": "circle", "active_colour": "#FFB454", "inactive_colour": "#708096"},
    {"id": "navigation_lights", "group": "Lights", "name": "Navigation Lights", "slug": "light_nav", "label": "Navigation Lights", "active_text": "ON", "inactive_text": "OFF", "active_icon": "lightbulb", "inactive_icon": "circle", "active_colour": "#39D7A5", "inactive_colour": "#708096"},
    {"id": "beacon_lights", "group": "Lights", "name": "Beacon Lights", "slug": "light_beacon", "label": "Beacon", "active_text": "ON", "inactive_text": "OFF", "active_icon": "lightbulb", "inactive_icon": "circle", "active_colour": "#FFB454", "inactive_colour": "#708096"},
    {"id": "strobe_lights", "group": "Lights", "name": "Strobe Lights", "slug": "light_strobe", "label": "Strobes", "active_text": "ON", "inactive_text": "OFF", "active_icon": "lightbulb", "inactive_icon": "circle", "active_colour": "#43B5FF", "inactive_colour": "#708096"},
    {"id": "nav_signal", "group": "Navigation", "name": "NAV Signal", "slug": "nav_has_nav", "label": "NAV Signal", "active_text": "RECEIVED", "inactive_text": "NO SIGNAL", "active_icon": "radio", "inactive_icon": "circle", "active_colour": "#39D7A5", "inactive_colour": "#708096"},
    {"id": "dme_signal", "group": "Navigation", "name": "DME Available", "slug": "nav_has_dme", "label": "DME", "active_text": "AVAILABLE", "inactive_text": "NO SIGNAL", "active_icon": "radio", "inactive_icon": "circle", "active_colour": "#39D7A5", "inactive_colour": "#708096"},
    {
        "id": "barometer",
        "group": "Navigation",
        "name": "Barometer",
        "label": "Barometer",
        "slug": "kohlsman_setting_hg",
        "index": 1,
        "input_settings": {"decimal_places": 2, "fixed_decimal_places": True},
        "unit": "inhg",
        "unit_options": [
            {
                "value": "inhg",
                "label": "inHg",
                "slug": "kohlsman_setting_hg",
                "index": 1,
                "input_settings": {"decimal_places": 2, "fixed_decimal_places": True},
                "detail": "inHg",
            },
            {
                "value": "hpa",
                "label": "hPa",
                "slug": "kohlsman_setting_mb",
                "index": 1,
                "input_settings": {"decimal_places": 0, "fixed_decimal_places": True},
                "detail": "hPa",
            },
        ],
        "mode": "readout",
        "preview_icon": "gauge",
        "states": [
            {"id": "readout", "label": "Reading", "text": "inHg", "icon": "gauge", "colour": "#43B5FF"},
        ],
    },
    {"id": "transponder_ident", "group": "Navigation", "name": "Transponder Ident", "slug": "transponder_ident", "label": "Transponder", "active_text": "IDENT", "inactive_text": "STANDBY", "active_icon": "radio", "inactive_icon": "circle", "active_colour": "#FFB454", "inactive_colour": "#708096"},
    {
        "id": "transponder_mode",
        "group": "Navigation",
        "name": "Transponder Mode",
        "label": "Transponder",
        "slug": "transponder_state",
        "index": 1,
        "mode": "multi_state",
        "resolver": "transponder_state",
        "preview_icon": "radio",
        "states": [
            {"id": "off", "label": "Off", "text": "OFF", "icon": "power", "colour": "#708096"},
            {"id": "standby", "label": "Standby", "text": "STANDBY", "icon": "pause", "colour": "#43B5FF"},
            {"id": "test", "label": "Test", "text": "TEST", "icon": "wrench", "colour": "#FFB454"},
            {"id": "on", "label": "On", "text": "ON", "icon": "radio", "colour": "#39D7A5"},
            {"id": "alt", "label": "Altitude", "text": "ALT", "icon": "radio", "colour": "#9D7CFF"},
            {"id": "ground", "label": "Ground", "text": "GROUND", "icon": "airplane-taxiing", "colour": "#39D7A5"},
        ],
    },
)


# These controls safely toggle the same broadly supported simulator state that
# their matching Status preset displays. Presets without a universal toggle do
# not suggest an action.
STATUS_DEFAULT_ACTIONS = {
    "parking_brake": "parking_brakes",
    "battery_master": "toggle_master_battery",
    "alternator": "toggle_master_alternator",
    "spoilers_armed": "spoilers_arm_toggle",
    "autopilot_master": "ap_master",
    "flight_director": "toggle_flight_director",
    "heading_hold": "ap_panel_heading_hold",
    "altitude_hold": "ap_panel_altitude_hold",
    "approach": "ap_approach_hold",
    "nav_mode": "ap_nav1_hold",
    "autothrottle": "auto_throttle_arm",
    "yaw_damper": "yaw_damper_toggle",
    "fuel_pump": "fuel_pump",
    "generator": "toggle_master_alternator",
    "magneto_starter": "magneto_start",
    "engine_anti_ice": "anti_ice_toggle",
    "carb_heat": "anti_ice_toggle",
    "pitot_heat": "pitot_heat_toggle",
    "landing_lights": "landing_lights_toggle",
    "taxi_lights": "toggle_taxi_lights",
    "navigation_lights": "toggle_nav_lights",
    "beacon_lights": "toggle_beacon_lights",
    "strobe_lights": "strobes_toggle",
    "barometer": "barometric",
}


# These are the standard, button-like autopilot controls exposed through
# SimConnect.  Target values stay with Cockpit Dial; this module mirrors the
# labelled switches and annunciators found on an autopilot panel.
AUTOPILOT_BUTTON_PRESETS: tuple[dict[str, object], ...] = (
    {"id": "ap_master", "group": "Autopilot", "name": "Autopilot", "label": "AP", "icon": "navigation-arrow", "event": "AP_MASTER", "state": "autopilot_master"},
    {"id": "flight_director", "group": "Autopilot", "name": "Flight Director", "label": "FD", "icon": "navigation-arrow", "event": "TOGGLE_FLIGHT_DIRECTOR", "state": "autopilot_flight_director_active"},
    {"id": "roll", "group": "Lateral", "name": "Wing Level", "label": "ROL", "icon": "airplane-tilt", "event": "AP_WING_LEVELER", "state": "autopilot_wing_leveler"},
    {"id": "heading", "group": "Lateral", "name": "Heading", "label": "HDG", "icon": "navigation-arrow", "event": "AP_PANEL_HEADING_HOLD", "state": "autopilot_heading_lock"},
    {"id": "nav", "group": "Lateral", "name": "Navigation", "label": "NAV", "icon": "compass", "event": "AP_NAV1_HOLD", "resolver": "lateral", "active_colour": "#43B5FF", "inactive_colour": "#708096"},
    {"id": "localizer", "group": "Lateral", "name": "Localizer", "label": "LOC", "icon": "navigation-arrow", "event": "AP_LOC_HOLD", "state": "autopilot_nav1_lock"},
    {"id": "approach", "group": "Lateral", "name": "Approach", "label": "APR", "icon": "airplane-landing", "event": "AP_APR_HOLD", "resolver": "approach"},
    {"id": "backcourse", "group": "Lateral", "name": "Backcourse", "label": "BC", "icon": "arrow-u-left-up", "event": "AP_BC_HOLD", "state": "autopilot_backcourse_hold"},
    {"id": "altitude", "group": "Vertical", "name": "Altitude", "label": "ALT", "icon": "gauge", "event": "AP_PANEL_ALTITUDE_HOLD", "resolver": "vertical", "reference": "autopilot_altitude_lock_var"},
    {"id": "vertical_speed", "group": "Vertical", "name": "Vertical Speed", "label": "VS", "icon": "arrows-vertical", "event": "AP_PANEL_VS_HOLD", "state": "autopilot_vertical_hold", "reference": "autopilot_vertical_hold_var"},
    {"id": "flight_level_change", "group": "Vertical", "name": "Flight Level Change", "label": "FLC", "icon": "arrows-down-up", "event": "FLIGHT_LEVEL_CHANGE", "state": "autopilot_flight_level_change", "reference": "autopilot_airspeed_hold_var"},
    {"id": "airspeed", "group": "Speed", "name": "Airspeed Hold", "label": "IAS", "icon": "gauge", "event": "AP_PANEL_SPEED_HOLD", "state": "autopilot_airspeed_hold", "reference": "autopilot_airspeed_hold_var"},
    {"id": "mach", "group": "Speed", "name": "Mach Hold", "label": "MACH", "icon": "gauge", "event": "AP_PANEL_MACH_HOLD", "state": "autopilot_mach_hold", "reference": "autopilot_mach_hold_var"},
    {"id": "autothrottle", "group": "Speed", "name": "Autothrottle", "label": "A/T", "icon": "gauge", "event": "AUTO_THROTTLE_ARM", "state": "autopilot_throttle_arm"},
    {"id": "yaw_damper", "group": "Autopilot", "name": "Yaw Damper", "label": "YD", "icon": "airplane-tilt", "event": "YAW_DAMPER_TOGGLE", "state": "autopilot_yaw_damper"},
    {"id": "glideslope", "group": "Vertical", "name": "Glideslope", "label": "GS", "icon": "airplane-landing", "resolver": "glideslope"},
    {"id": "pitch_up", "group": "Pitch", "name": "Nose Up", "label": "NOSE UP", "icon": "arrow-up", "event": "AP_PITCH_REF_INC_UP", "reference": "autopilot_pitch_hold_ref", "action_only": True},
    {"id": "pitch_down", "group": "Pitch", "name": "Nose Down", "label": "NOSE DN", "icon": "arrow-down", "event": "AP_PITCH_REF_INC_DN", "reference": "autopilot_pitch_hold_ref", "action_only": True},
    {"id": "vnav", "group": "Aircraft", "name": "Aircraft VNAV", "label": "VNAV", "icon": "path", "resolver": "dynamic_vnav"},
)


TIMER_PRESETS: tuple[dict[str, object], ...] = (
    {
        "id": "engine_hobbs",
        "group": "Engine",
        "name": "Engine Hobbs Time",
        "detail": "Hobbs counter",
        "mode": "simvar",
        "slug": "general_eng_hobbs_elapsed_time",
        "index": 1,
        "label": "Engine Hobbs",
    },
    {
        "id": "engine_elapsed",
        "group": "Engine",
        "name": "Engine Elapsed Time",
        "detail": "Engine runtime",
        "mode": "simvar",
        "slug": "general_eng_elapsed_time",
        "index": 1,
        "label": "Engine Time",
    },
    {
        "id": "gps_ete",
        "group": "Navigation",
        "name": "Time to Destination",
        "detail": "Flight plan",
        "mode": "simvar",
        "slug": "gps_ete",
        "label": "To Destination",
    },
    {
        "id": "gps_wp_ete",
        "group": "Navigation",
        "name": "Time to Waypoint",
        "detail": "Active waypoint",
        "mode": "simvar",
        "slug": "gps_wp_ete",
        "label": "To Waypoint",
    },
    {
        "id": "stopwatch",
        "group": "Manual",
        "name": "Stopwatch",
        "detail": "Manual timer",
        "mode": "stopwatch",
        "label": "Stopwatch",
    },
)


# Compass presets are intentionally limited to common flight and navigation
# references.  The Custom card remains available for any other documented
# angular SimVar without turning the ordinary setup path into a raw picker.
COMPASS_PRESETS: tuple[dict[str, object], ...] = (
    {
        "id": "magnetic_heading",
        "group": "Aircraft",
        "name": "Magnetic Heading",
        "label": "Heading",
        "icon": "compass",
        "input": {"id": "simvar.plane_heading_degrees_magnetic", "extension_id": "io.github.robdevice.msfs.simconnect", "settings": {}},
    },
    {
        "id": "true_heading",
        "group": "Aircraft",
        "name": "True Heading",
        "label": "True Heading",
        "icon": "compass",
        "input": {"id": "simvar.plane_heading_degrees_true", "extension_id": "io.github.robdevice.msfs.simconnect", "settings": {}},
    },
    {
        "id": "heading_bug",
        "group": "Autopilot",
        "name": "Heading Bug",
        "label": "Heading Bug",
        "icon": "navigation-arrow",
        "mode": "dual",
        "input": {"id": "simvar.plane_heading_degrees_magnetic", "extension_id": "io.github.robdevice.msfs.simconnect", "settings": {}},
        "secondary_input": {"id": "simvar.autopilot_heading_lock_dir", "extension_id": "io.github.robdevice.msfs.simconnect", "settings": {}},
        "secondary_label": "Bug",
        "default_action": {"id": "sync_heading_bug", "extension_id": "io.github.robdevice.msfs.simconnect", "settings": {}},
    },
    {
        "id": "gps_desired_track",
        "group": "GPS Navigation",
        "name": "GPS Desired Track",
        "label": "Desired Track",
        "icon": "navigation-arrow",
        "input": {"id": "simvar.gps_wp_desired_track", "extension_id": "io.github.robdevice.msfs.simconnect", "settings": {}},
    },
    {
        "id": "gps_waypoint_bearing",
        "group": "GPS Navigation",
        "name": "GPS Waypoint Bearing",
        "label": "To Waypoint",
        "icon": "navigation-arrow",
        "input": {"id": "simvar.gps_wp_bearing", "extension_id": "io.github.robdevice.msfs.simconnect", "settings": {}},
    },
    {
        "id": "gps_course_to_steer",
        "group": "GPS Navigation",
        "name": "GPS Course to Steer",
        "label": "Course to Steer",
        "icon": "navigation-arrow",
        "input": {"id": "simvar.gps_course_to_steer", "extension_id": "io.github.robdevice.msfs.simconnect", "settings": {}},
    },
    {
        "id": "gps_ground_track",
        "group": "GPS Navigation",
        "name": "GPS Ground Track",
        "label": "Ground Track",
        "icon": "compass",
        "input": {"id": "simvar.gps_ground_magnetic_track", "extension_id": "io.github.robdevice.msfs.simconnect", "settings": {}},
    },
    {
        "id": "gps_obs_course",
        "group": "Navigation",
        "name": "GPS OBS Course",
        "label": "GPS OBS",
        "icon": "navigation-arrow",
        "input": {"id": "simvar.gps_obs_value", "extension_id": "io.github.robdevice.msfs.simconnect", "settings": {}},
    },
    {
        "id": "hsi_bearing",
        "group": "Navigation",
        "name": "HSI Bearing",
        "label": "HSI Bearing",
        "icon": "compass",
        "input": {"id": "simvar.hsi_bearing", "extension_id": "io.github.robdevice.msfs.simconnect", "settings": {}},
    },
)


# Gauge presets intentionally use only broadly useful state. SimConnect does
# not expose complete operating-limit bands for every aircraft, so named
# presets stay neutral unless a user opts into Custom bands.
GAUGE_PRESETS: tuple[dict[str, object], ...] = (
    {
        "id": "battery_voltage",
        "name": "Battery Voltage",
        "label": "Battery",
        "slug": "electrical_battery_voltage",
        "request_unit": "Volts",
        "display_unit": "V",
        "icon": "battery-full",
        "minimum": 0,
        "maximum": 32,
        "decimal_places": 1,
        "indicator_style": "arc",
    },
    {
        "id": "fuel_quantity",
        "name": "Fuel Quantity",
        "label": "Fuel",
        "slug": "fuel_total_quantity",
        "request_unit": "Gallons",
        "display_unit": "gal",
        "icon": "gas-pump",
        "minimum": 0,
        "maximum": 100,
        "range_max_slug": "fuel_total_capacity",
        "range_max_unit": "Gallons",
        "decimal_places": 1,
        "indicator_style": "arc",
    },
    {
        "id": "fuel_flow",
        "name": "Fuel Flow",
        "label": "Fuel Flow",
        "slug": "eng_fuel_flow_gph",
        "request_unit": "Gallons per hour",
        "display_unit": "gal/h",
        "icon": "gas-pump",
        "minimum": 0,
        "maximum": 20,
        "decimal_places": 1,
        "indicator_style": "arc",
        "engine_indexed": True,
    },
    {
        "id": "engine_rpm",
        "name": "Engine RPM",
        "label": "Engine RPM",
        "slug": "general_eng_rpm",
        "request_unit": "RPM",
        "display_unit": "RPM",
        "icon": "engine",
        "minimum": 0,
        "maximum": 2500,
        "range_max_slug": "eng_max_rpm",
        "range_max_unit": "RPM",
        "band_profile": "upper_limit",
        "decimal_places": 0,
        "indicator_style": "needle",
        "engine_indexed": True,
    },
    {
        "id": "oil_pressure",
        "name": "Oil Pressure",
        "label": "Oil Pressure",
        "slug": "eng_oil_pressure",
        "request_unit": "PSI",
        "display_unit": "PSI",
        "icon": "gauge",
        "minimum": 0,
        "maximum": 100,
        "decimal_places": 0,
        "indicator_style": "needle",
        "engine_indexed": True,
    },
    {
        "id": "oil_temperature",
        "name": "Oil Temperature",
        "label": "Oil Temp",
        "slug": "eng_oil_temperature",
        "request_unit": "Celsius",
        "display_unit": "°C",
        "icon": "thermometer",
        "minimum": -20,
        "maximum": 140,
        "range_max_slug": "max_oil_temperature",
        "range_max_unit": "Celsius",
        "band_profile": "upper_limit",
        "decimal_places": 0,
        "indicator_style": "needle",
        "engine_indexed": True,
    },
    {
        "id": "engine_n1",
        "name": "Engine N1",
        "label": "N1",
        "slug": "eng_n1_rpm",
        "request_unit": "Percent",
        "display_unit": "%",
        "icon": "gauge",
        "minimum": 0,
        "maximum": 100,
        "decimal_places": 1,
        "indicator_style": "needle",
        "band_profile": "upper_limit",
        "engine_indexed": True,
    },
    {
        "id": "engine_n2",
        "name": "Engine N2",
        "label": "N2",
        "slug": "eng_n2_rpm",
        "request_unit": "Percent",
        "display_unit": "%",
        "icon": "gauge",
        "minimum": 0,
        "maximum": 100,
        "decimal_places": 1,
        "indicator_style": "needle",
        "band_profile": "upper_limit",
        "engine_indexed": True,
    },
)


class _HelperBridge:
    """Keep the helper process alive while a profile polls SimConnect values."""

    def __init__(self) -> None:
        self._process: subprocess.Popen[str] | None = None
        self._lock = threading.Lock()

    def request(self, helper: Path, payload: dict) -> dict:
        with self._lock:
            if self._process is None or self._process.poll() is not None:
                self._process = subprocess.Popen(
                    [str(helper)], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                    text=True, bufsize=1,
                )
            if self._process.stdin is None or self._process.stdout is None:
                return {"ok": False, "error": "SimConnect helper streams are unavailable"}
            try:
                self._process.stdin.write(json.dumps(payload) + "\n")
                self._process.stdin.flush()
                line = self._process.stdout.readline()
                return json.loads(line or "{}")
            except (OSError, ValueError, json.JSONDecodeError) as error:
                self._process = None
                return {"ok": False, "error": str(error)}

    def reset(self) -> None:
        """Discard a helper after a failed SimConnect request before retrying."""
        with self._lock:
            process = self._process
            self._process = None
            if process is not None and process.poll() is None:
                process.terminate()


@lru_cache(maxsize=4)
def _catalogue(name: str) -> list[dict]:
    path = ROOT / "catalogue" / name
    if not path.exists():
        return []
    return json.loads(path.read_text(encoding="utf-8"))


class Plugin:
    """Expose standard MSFS 2020 data and commands to the shared registries."""

    def settings_schema(self) -> dict:
        return {
            "properties": {
                "address": {
                    "type": "string",
                    "title": "SimConnect address",
                    "description": "Host and TCP port exposed by SimConnect.",
                    "default": "127.0.0.1:500",
                }
            }
        }

    def __init__(self) -> None:
        self._bridge = _HelperBridge()
        self._stopwatch_state: dict[str, dict[str, float | bool]] = {}
        self._stopwatch_lock = threading.Lock()
        self._gauge_limit_cache: dict[tuple[str, str, int], tuple[float, float]] = {}
        self._gauge_limit_lock = threading.Lock()
        self._autopilot_value_cache: dict[tuple[str, str], tuple[float, object]] = {}
        self._aircraft_input_events_cache: tuple[float, list[dict[str, object]]] | None = None

    def modules(self) -> list[dict]:
        modules = [
            {
                "id": "msfs.cockpit_dial",
                "name": "MSFS Cockpit Dial",
                "group": "Cockpit Controls",
                "description": "Configure a dial for common MSFS cockpit controls through standard SimConnect controls.",
                "icon": "circle-notch",
                "requires": ["rotary_left", "rotary_right", "press"],
                "default_settings": {"control": "Autopilot Altitude"},
                "settings_schema": {
                    "properties": {
                        "control": {
                            "type": "card_enum",
                            "title": "Control",
                            "description": "The cockpit rotary control this dial represents.",
                            "options": [dict(preset, label=preset["value"]) for preset in DIAL_CONTROL_PRESETS],
                            "default": "Autopilot Altitude",
                        }
                    }
                },
            },
            {
                "id": "msfs.autopilot_button",
                "name": "MSFS Autopilot Button",
                "group": "Cockpit Controls",
                "description": "Mirror one standard autopilot-panel control with its matching SimConnect action and live annunciator.",
                "icon": "navigation-arrow",
                "requires": [],
                "live_visual": True,
                "migrate_missing_defaults": False,
                "default_settings": {
                    "control": "ap_master",
                    "background": "#000000",
                    "foreground": "#EDF7FF",
                },
                "default_visual": {"background": "#000000", "foreground": "#EDF7FF", "asset_mode": "image"},
                "settings_schema": {
                    "properties": {
                        "control": {
                            "type": "card_enum",
                            "title": "Autopilot control",
                            "options": [
                                {
                                    "value": str(preset["id"]),
                                    "label": str(preset["name"]),
                                    "group": str(preset["group"]),
                                    "icon": str(preset["icon"]),
                                }
                                for preset in AUTOPILOT_BUTTON_PRESETS
                            ],
                            "default": "ap_master",
                        },
                        "vnav_event": {
                            "type": "runtime_enum",
                            "title": "Aircraft VNAV control",
                            "extension_id": "io.github.robdevice.msfs.simconnect",
                            "provider": "aircraft_input_events",
                            "visible_when": {"control": "vnav"},
                        },
                        "background": {"type": "color", "title": "Background colour"},
                        "foreground": {"type": "color", "title": "Text colour"},
                    }
                },
            },
        ]
        modules.extend(self._display_modules())
        return modules

    @staticmethod
    def _input_selection(slug: str, **settings: object) -> dict:
        """Create a normal registry selection so display modules work on assignment."""
        return {
            "id": f"simvar.{slug}",
            "extension_id": "io.github.robdevice.msfs.simconnect",
            "settings": settings,
        }

    @classmethod
    def _display_defaults(cls, kind: str) -> dict:
        parking_brake = cls._status_preset("parking_brake")
        defaults: dict[str, dict] = {
            "status": {
                "status": parking_brake,
            },
            "level": {
                "input": cls._input_selection("general_eng_throttle_lever_position", index=1),
                "label": "Throttle",
                "accent": "#43B5FF",
                "minimum": 0,
                "maximum": 100,
            },
            "gauge": {
                "gauge": cls._gauge_preset("battery_voltage"),
                "accent": "#43B5FF",
            },
            "compass": {
                "compass": cls._compass_preset("magnetic_heading"),
                "accent": "#39D7A5",
            },
            "frequency": {
                "input": cls._input_selection("com_active_frequency", index=1),
                "label": "COM 1",
                "accent": "#FFB454",
            },
            "clock": {
                "timer": cls._timer_preset("engine_hobbs"),
            },
            "position": {
                "input": cls._input_selection("plane_latitude"),
                "longitude": cls._input_selection("plane_longitude"),
                "label": "Position",
                "accent": "#39D7A5",
            },
            "warning": {
                "input": cls._input_selection("stall_warning"),
                "label": "Stall Warning",
                "accent": "#FFB454",
            },
        }
        value = copy.deepcopy(defaults[kind])
        default_action = dict(value.pop("default_action", {}))
        if kind == "status":
            default_action = dict(value["status"].get("default_action", default_action))
        return {
            **value,
            "action": default_action,
            "background": "#000000",
            "foreground": "#EDF7FF",
        }

    @classmethod
    def _display_settings(cls, kind: str) -> dict:
        if kind == "status":
            return {
                "properties": {
                    "status": {
                        "type": "status_source",
                        "title": "Interactive Status",
                        "extension_id": "io.github.robdevice.msfs.simconnect",
                        "presets": cls._interactive_status_presets(),
                    },
                    "action": {"type": "action", "title": "When pressed (optional)"},
                    "background": {"type": "color", "title": "Background colour"},
                    "foreground": {"type": "color", "title": "Text colour"},
                }
            }
        if kind == "clock":
            return {
                "properties": {
                    "timer": {
                        "type": "timer_source",
                        "title": "Timer",
                        "extension_id": "io.github.robdevice.msfs.simconnect",
                        "presets": [cls._timer_preset(str(preset["id"])) for preset in TIMER_PRESETS],
                    },
                    "action": {"type": "action", "title": "When pressed (optional)"},
                    "background": {"type": "color", "title": "Background colour"},
                    "foreground": {"type": "color", "title": "Text colour"},
                }
            }
        if kind == "gauge":
            return {
                "properties": {
                    "gauge": {
                        "type": "preset_source",
                        "title": "Gauge",
                        "extension_id": "io.github.robdevice.msfs.simconnect",
                        "presets": [cls._gauge_preset(str(preset["id"])) for preset in GAUGE_PRESETS],
                    },
                    "action": {"type": "action", "title": "When pressed (optional)"},
                    "accent": {"type": "color", "title": "Accent colour"},
                    "background": {"type": "color", "title": "Background colour"},
                    "foreground": {"type": "color", "title": "Text colour"},
                }
            }
        if kind == "compass":
            return {
                "properties": {
                    "compass": {
                        "type": "compass_source",
                        "title": "Compass",
                        "extension_id": "io.github.robdevice.msfs.simconnect",
                        "presets": [cls._compass_preset(str(preset["id"])) for preset in COMPASS_PRESETS],
                    },
                    "action": {"type": "action", "title": "When pressed (optional)"},
                    "accent": {"type": "color", "title": "Compass colour"},
                    "background": {"type": "color", "title": "Background colour"},
                    "foreground": {"type": "color", "title": "Text colour"},
                }
            }
        properties: dict[str, dict] = {
            "label": {"type": "string", "title": "Label"},
            "accent": {"type": "color", "title": "Accent colour"},
            "background": {"type": "color", "title": "Background colour"},
            "foreground": {"type": "color", "title": "Text colour"},
            "action": {"type": "action", "title": "When pressed (optional)"},
        }
        if kind != "clock":
            properties["input"] = {
                "type": "input",
                "title": "Data to show",
                "extension_id": "io.github.robdevice.msfs.simconnect",
            }
        if kind == "position":
            properties["longitude"] = {
                "type": "input",
                "title": "Longitude",
                "extension_id": "io.github.robdevice.msfs.simconnect",
            }
        return {"properties": properties}

    @classmethod
    def _status_preset(cls, preset_id: str) -> dict:
        preset = next((entry for entry in STATUS_PRESETS if str(entry.get("id")) == preset_id), STATUS_PRESETS[0])
        value = copy.deepcopy(preset)
        value["preset_id"] = str(value.get("id") or preset_id)
        value["mode"] = str(value.get("mode") or "boolean")
        slug = str(value.pop("slug", ""))
        index = value.pop("index", None)
        input_settings = dict(value.pop("input_settings", {}))
        if index is not None:
            input_settings["index"] = index
        if slug:
            value["input"] = cls._input_selection(slug, **input_settings)
        unit_options: list[dict] = []
        for raw_option in value.get("unit_options", []):
            if not isinstance(raw_option, dict):
                continue
            option = copy.deepcopy(raw_option)
            option_slug = str(option.pop("slug", ""))
            option_index = option.pop("index", None)
            option_settings = dict(option.pop("input_settings", {}))
            if option_index is not None:
                option_settings["index"] = option_index
            if option_slug:
                option["input"] = cls._input_selection(option_slug, **option_settings)
            unit_options.append(option)
        if unit_options:
            value["unit_options"] = unit_options
            selected_unit = str(value.get("unit") or unit_options[0].get("value") or "")
            selected_option = next((option for option in unit_options if str(option.get("value")) == selected_unit), unit_options[0])
            value["unit"] = str(selected_option.get("value") or "")
            if isinstance(selected_option.get("input"), dict):
                value["input"] = copy.deepcopy(selected_option["input"])
            detail = str(selected_option.get("detail") or "")
            if detail:
                value["readout_text"] = detail
        for state in value.get("states", []):
            if not isinstance(state, dict):
                continue
            state_id = str(state.get("id") or "").strip()
            if not state_id:
                continue
            value.setdefault(f"{state_id}_text", str(state.get("text") or state_id.upper()))
            value.setdefault(f"{state_id}_icon", str(state.get("icon") or "circle"))
            value.setdefault(f"{state_id}_colour", str(state.get("colour") or "#708096"))
        value["text_size"] = "medium"
        action_slug = STATUS_DEFAULT_ACTIONS.get(str(value["preset_id"]))
        if action_slug:
            value["default_action"] = cls._action_selection(action_slug)
        return value

    @classmethod
    def _interactive_status_presets(cls) -> list[dict]:
        """Hide AP-panel controls from the general-purpose status picker.

        The backing entries remain available to render existing profiles that
        used them before Autopilot Button was introduced.
        """
        return [
            cls._status_preset(str(preset["id"]))
            for preset in STATUS_PRESETS
            if str(preset.get("group")) != "Autopilot"
        ]

    @classmethod
    def _timer_preset(cls, preset_id: str) -> dict:
        preset = next((entry for entry in TIMER_PRESETS if str(entry.get("id")) == preset_id), TIMER_PRESETS[0])
        value = copy.deepcopy(preset)
        slug = str(value.pop("slug", ""))
        index = value.pop("index", None)
        value["preset_id"] = str(value.get("id") or preset_id)
        value["text_size"] = "medium"
        if slug:
            settings = {"index": index} if index is not None else {}
            value["input"] = cls._input_selection(slug, **settings)
        return value

    @classmethod
    def _gauge_preset(cls, preset_id: str) -> dict:
        preset = next((entry for entry in GAUGE_PRESETS if str(entry.get("id")) == preset_id), GAUGE_PRESETS[0])
        value = copy.deepcopy(preset)
        slug = str(value.pop("slug"))
        engine = int(value.get("engine", 1) or 1)
        settings = {"index": engine} if value.get("engine_indexed") else {}
        value["preset_id"] = str(value.get("id") or preset_id)
        value["input"] = cls._input_selection(slug, **settings)
        value["label_size"] = "medium"
        value["value_size"] = "medium"
        return value

    @classmethod
    def _compass_preset(cls, preset_id: str) -> dict:
        preset = next((entry for entry in COMPASS_PRESETS if str(entry.get("id")) == preset_id), COMPASS_PRESETS[0])
        value = copy.deepcopy(preset)
        value["preset_id"] = str(value.get("id") or preset_id)
        value.setdefault("label_size", "medium")
        value.setdefault("value_size", "medium")
        return value

    @staticmethod
    def _autopilot_button_preset(control: str) -> dict[str, object]:
        return next(
            (dict(preset) for preset in AUTOPILOT_BUTTON_PRESETS if str(preset.get("id")) == control),
            dict(AUTOPILOT_BUTTON_PRESETS[0]),
        )

    @staticmethod
    def _action_selection(slug: str) -> dict:
        return {
            "id": f"key_event.{slug}",
            "extension_id": "io.github.robdevice.msfs.simconnect",
            "settings": {},
        }

    def _display_modules(self) -> list[dict]:
        definitions = (
            ("status", "MSFS Interactive Status", "Show a simulator state and optionally control it when pressed."),
            ("level", "MSFS Level", "Show a value such as throttle position as a level bar."),
            ("gauge", "MSFS Gauge", "Show a value such as altitude on a compact gauge."),
            ("compass", "MSFS Compass", "Show heading, bearing, course, or track on a compass display."),
            ("frequency", "MSFS Frequency", "Show a radio, navigation, or transponder frequency."),
            ("clock", "MSFS Timer", "Show an engine, navigation, or manually controlled flight timer."),
            ("position", "MSFS Position", "Show the aircraft latitude and longitude."),
            ("warning", "MSFS Warning", "Show a clear warning when the selected simulator warning is active."),
        )
        return [
            {
                "id": f"msfs.display_{kind}",
                "name": name,
                "group": "Displays",
                "description": description,
                "requires": [],
                "live_visual": True,
                "icon": {
                    "status": "pulse",
                    "clock": "timer",
                    "gauge": "gauge",
                    "compass": "compass",
                }.get(kind, "monitor-play"),
                # Status has a structural migration path from the old raw input
                # shape. Do not inject the new default over an existing choice.
                "migrate_missing_defaults": kind not in {"status", "clock", "gauge", "compass"},
                "conditional_requires": (
                    [{"setting": "timer.mode", "equals": "stopwatch", "requires": ["press", "release"]}]
                    if kind == "clock"
                    else []
                ),
                "default_settings": self._display_defaults(kind),
                "default_visual": (
                    {
                        "background": "#000000",
                        "foreground": "#edf7ff",
                        "icon_foreground": "#edf7ff",
                        "text_foreground": "#edf7ff",
                        "text": "",
                        "text_position": "middle",
                        "text_size": "medium",
                        "asset_mode": "icon",
                        "icon": None,
                    }
                    if kind == "clock"
                    else {"background": "#000000", "foreground": "#edf7ff", "asset_mode": "image"}
                ),
                "settings_schema": self._display_settings(kind),
            }
            for kind, name, description in definitions
        ]

    @staticmethod
    def _helper() -> Path:
        return ROOT / "runtime" / f"{platform.system().lower()}-{platform.machine()}" / "macro-pad-manager-msfs-helper"

    @staticmethod
    def _address(settings: dict | None) -> str:
        return str((settings or {}).get("address") or "127.0.0.1:500")

    def _request(self, payload: dict) -> dict:
        helper = self._helper()
        if not helper.exists():
            return {"ok": False, "error": "SimConnect helper is unavailable on this platform"}
        if not os.access(helper, os.X_OK):
            return {"ok": False, "error": "The SimConnect helper is not allowed to run. Repair helper permissions in Extension Settings."}
        return self._bridge.request(helper, payload)

    def inputs(self) -> list[dict]:
        inputs: list[dict] = []
        for entry in _catalogue("simvars.json"):
            item = {
                "id": f"simvar.{entry['slug']}",
                "name": entry["name"],
                "description": entry["description"],
                "group": entry["group"],
                "unit": entry["unit"],
                "data_type": entry["data_type"],
                "indexable": entry["indexable"],
                "simvar": entry["name"],
                "presentation": self._presentation_hint(entry),
            }
            properties: dict[str, dict] = {}
            if entry["indexable"]:
                properties["index"] = {"type": "integer", "title": "Index", "default": 1}
            if entry["data_type"] == "number":
                properties["decimal_places"] = {
                    "type": "integer",
                    "title": "Decimal places",
                    "description": "Number of digits to show after the decimal point.",
                    "default": self._default_decimal_places(entry),
                }
            if properties:
                item["settings_schema"] = {"properties": properties}
            inputs.append(item)
        return inputs

    @staticmethod
    def _presentation_hint(entry: dict) -> dict:
        name = str(entry.get("name", "")).upper()
        unit = str(entry.get("unit", ""))
        data_type = str(entry.get("data_type", ""))
        if data_type == "boolean" or unit.lower() == "bool":
            kind = "status"
        elif "FREQUENCY" in name or "TRANSPONDER" in name:
            kind = "frequency"
        elif any(token in name for token in ("HEADING", "BEARING", "COURSE", "TRACK")):
            kind = "compass"
        elif any(token in name for token in ("TIME", "TIMER", "DURATION")):
            kind = "clock"
        elif any(token in name for token in ("LATITUDE", "LONGITUDE", "POSITION")):
            kind = "position"
        elif "ALTITUDE" in name:
            kind = "gauge"
        elif "PERCENT" in unit.upper() or unit.lower() in {"percent over 100", "ratio"}:
            kind = "level"
        elif any(token in name for token in ("RPM", "TEMPERATURE", "PRESSURE", "SPEED", "VOLTAGE", "CURRENT")):
            kind = "gauge"
        else:
            kind = "value"
        hint = {"kind": kind, "unit": unit}
        if "PERCENT" in unit.upper():
            hint.update({"minimum": 0, "maximum": 100})
        elif unit.lower() in {"percent over 100", "ratio"}:
            hint.update({"minimum": 0, "maximum": 1})
        return hint

    @staticmethod
    def _default_decimal_places(entry: dict) -> int:
        name = str(entry.get("name", "")).lower()
        if "altitude" in name:
            return 0
        return 2

    @staticmethod
    def _format_readout_value(value, decimal_places: object, fixed_decimal_places: object = False) -> object:
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            return value
        try:
            places = max(0, min(6, int(decimal_places)))
        except (TypeError, ValueError):
            places = 2
        if places == 0:
            return str(int(round(value)))
        formatted = f"{value:.{places}f}"
        return formatted if bool(fixed_decimal_places) else formatted.rstrip("0").rstrip(".")

    def actions(self) -> list[dict]:
        actions: list[dict] = []
        for entry in _catalogue("key_events.json"):
            actions.append(
                {
                    "id": f"key_event.{entry['slug']}",
                    "name": entry["name"],
                    "description": entry["description"],
                    "group": entry["group"],
                    "key_event": entry["name"],
                    "settings_schema": {
                        "properties": {
                            "parameter": {
                                "type": "integer",
                                "title": "Parameter",
                                "description": entry["parameters"] or "SimConnect event parameter.",
                                "default": 0,
                            }
                        }
                    },
                }
            )
        for entry in _catalogue("simvars.json"):
            if not entry["settable"]:
                continue
            actions.append(
                {
                    "id": f"set_simvar.{entry['slug']}",
                    "name": f"Set {entry['name']}",
                    "description": f"Write {entry['name']} through SimConnect.",
                    "group": f"Set SimVars / {entry['group']}",
                    "simvar": entry["name"],
                    "unit": entry["unit"],
                    "data_type": entry["data_type"],
                    "settings_schema": {
                        "properties": {
                            "value": {"type": entry["data_type"], "title": "Value"},
                            **({"index": {"type": "integer", "title": "Index", "default": 1}} if entry["indexable"] else {}),
                        }
                    },
                }
            )
        actions.append(
            {
                "id": "sync_heading_bug",
                "name": "Synchronise Heading Bug",
                "description": "Set the autopilot heading bug to the aircraft's current magnetic heading.",
                "group": "Autopilot",
                "operation": "sync_heading_bug",
            }
        )
        actions.append(
            {
                "id": "advanced_simvar_output",
                "name": "Advanced SimVar Output",
                "description": "Write a custom documented SimVar through SimConnect.",
                "group": "Advanced",
                "settings_schema": {
                    "properties": {
                        "simvar": {"type": "string", "title": "Simulation Variable"},
                        "unit": {"type": "string", "title": "Unit"},
                        "value": {"type": "number", "title": "Value"},
                        "index": {"type": "integer", "title": "Index", "default": 0},
                    }
                },
            }
        )
        return actions

    def connection_status(self, settings: dict | None = None) -> dict:
        address = self._address(settings)
        helper = self._helper()
        if not helper.exists():
            return {"address": address, "state": "unsupported_platform"}
        if not os.access(helper, os.X_OK):
            return {
                "address": address,
                "state": "helper_not_executable",
                "error": "The SimConnect helper was installed without permission to run.",
                "remediation": "Repair helper permissions, then test the connection again.",
                "repairable": True,
                "repair_label": "Repair Helper Permissions",
            }
        try:
            response = self._request({"operation": "probe", "address": address})
            if response.get("ok"):
                return {
                    "address": address,
                    "state": "connected",
                    "message": "SimConnect accepted a connection at this address.",
                }
            return self._connection_failure(address, str(response.get("error") or "SimConnect did not return a response"))
        except (OSError, subprocess.SubprocessError, json.JSONDecodeError) as error:
            return self._connection_failure(address, str(error))

    @staticmethod
    def _connection_failure(address: str, error: str) -> dict:
        normalized_error = error.casefold()
        result = {"address": address, "state": "unavailable", "error": error}
        if "connection refused" in normalized_error:
            result.update(
                {
                    "message": f"No SimConnect service is listening at {address}.",
                    "remediation": (
                        "Start MSFS and the SimConnect TCP listener, or change the address to the endpoint "
                        "that MSFS is exposing. The extension cannot start SimConnect itself."
                    ),
                }
            )
        elif "timed out" in normalized_error:
            result.update(
                {
                    "message": f"SimConnect at {address} did not respond in time.",
                    "remediation": "Confirm that MSFS is running and that the configured host and port are reachable from this computer.",
                }
            )
        else:
            result.update(
                {
                    "message": f"SimConnect could not be reached at {address}.",
                    "remediation": "Check that MSFS is running and that the configured host and port are correct, then test again.",
                }
            )
        return result

    def repair_connection(self, settings: dict | None = None) -> dict:
        """Restore user execute permission on the packaged native helper."""
        helper = self._helper()
        if not helper.exists():
            return {"ok": False, "error": "SimConnect helper is unavailable on this platform"}
        try:
            helper.chmod(helper.stat().st_mode | stat.S_IXUSR)
        except OSError as error:
            return {"ok": False, "error": f"Could not repair helper permissions: {error}"}
        return {"ok": True, "message": "Helper permissions repaired"}

    def read_input(self, input_definition: dict, input_settings: dict | None = None, extension_settings: dict | None = None) -> dict:
        input_settings = input_settings or {}
        payload = {
            "operation": "read_simvar",
            "address": self._address(extension_settings),
            "simvar": self._simvar_name(input_definition.get("simvar", "")),
            "unit": input_definition.get("unit") or None,
            "index": input_settings.get("index"),
            "data_type": input_definition.get("data_type", "number"),
        }
        response = self._request(payload)
        if not response.get("ok"):
            first_error = str(response.get("error") or "SimConnect read failed")
            self._bridge.reset()
            response = self._request(payload)
            if not response.get("ok"):
                retry_error = str(response.get("error") or "SimConnect read failed")
                raise RuntimeError(f"{first_error}; retry failed: {retry_error}")
        return {
            "value": self._format_readout_value(
                response.get("value", "--"),
                input_settings.get("decimal_places", self._default_decimal_places(input_definition)),
                input_settings.get("fixed_decimal_places", False),
            ),
            "raw_value": response.get("value", "--"),
            "unit": input_definition.get("unit", ""),
            "presentation": dict(input_definition.get("presentation", {})),
        }

    def execute_action(
        self,
        action: dict,
        action_settings: dict | None = None,
        extension_settings: dict | None = None,
    ) -> dict:
        """Run a documented Key Event or writable SimVar through SimConnect."""
        action_settings = action_settings or {}
        address = self._address(extension_settings)
        if str(action.get("operation") or "") == "sync_heading_bug":
            self._send_key_event(address, "HEADING_BUG_SET", self._read_magnetic_heading(address))
            return {"ok": True}
        event = str(action.get("key_event") or "").strip()
        if event:
            return self._request({"operation": "key_event", "address": address, "event": event, "parameter": action_settings.get("parameter", 0)})
        simvar = self._simvar_name(action_settings.get("simvar") or action.get("simvar") or "")
        if not simvar:
            return {"ok": False, "error": "No SimVar was selected"}
        return self._request(
            {
                "operation": "set_simvar",
                "address": address,
                "simvar": simvar,
                "unit": action_settings.get("unit") or action.get("unit") or None,
                "index": action_settings.get("index"),
                "data_type": action.get("data_type", "number"),
                "value": action_settings.get("value", 0),
            }
        )

    @staticmethod
    def _simvar_name(value: object) -> str:
        """Convert documentation's indexed-SimVar notation to the protocol name."""
        name = str(value or "").strip()
        return name[:-6].rstrip() if name.casefold().endswith(":index") else name

    def execute_module(
        self,
        module_payload: dict,
        event: dict,
        _context,
        extension_settings: dict | None = None,
    ) -> None:
        """Handle the fixed, real-world control mappings exposed by MSFS Cockpit Dial."""
        module_type = str(module_payload.get("type", ""))
        if module_type == "msfs.autopilot_button":
            if str(event.get("trigger_id", "")) not in {"press", "touch"}:
                return
            settings = dict(module_payload.get("settings", {}))
            preset = self._autopilot_button_preset(str(settings.get("control") or "ap_master"))
            address = self._address(extension_settings)
            if str(preset.get("id")) == "vnav":
                selected_event = str(settings.get("vnav_event") or "").strip()
                event_info = next((item for item in self._aircraft_input_events(extension_settings) if item["value"] == selected_event), None)
                if event_info is None:
                    raise RuntimeError("The selected aircraft VNAV control is unavailable")
                response = self._request(
                    {
                        "operation": "set_input_event",
                        "address": address,
                        "hash": int(event_info["hash"]),
                        "value": 1.0,
                    }
                )
                if not response.get("ok"):
                    raise RuntimeError(str(response.get("error") or "SimConnect rejected the aircraft VNAV control"))
                return
            key_event = str(preset.get("event") or "")
            if key_event:
                self._send_key_event(address, key_event)
            return
        if module_type.startswith("msfs.display_"):
            if module_type == "msfs.display_clock":
                timer = self._timer_settings(dict(module_payload.get("settings", {})))
                if str(timer.get("mode") or "simvar") == "stopwatch":
                    self._handle_stopwatch_event(module_payload, event)
                    return
            selection = dict(module_payload.get("settings", {}).get("action", {}))
            if str(event.get("trigger_id", "")) in {"press", "touch"} and selection.get("id") and _context is not None:
                _context.extension_action(selection, control_id=str(event.get("control_id", "plugin")))
            return
        if module_type != "msfs.cockpit_dial":
            raise RuntimeError(f"Unsupported MSFS module: {module_payload.get('type', '')}")
        control = str(module_payload.get("settings", {}).get("control") or "Autopilot Altitude")
        mapping = DIAL_CONTROLS.get(control)
        if mapping is None:
            raise RuntimeError(f"Unsupported MSFS cockpit dial control: {control}")
        trigger = str(event.get("trigger_id", ""))
        address = self._address(extension_settings)
        if trigger == "press" and mapping.get("press") == "heading_sync":
            heading = self._read_magnetic_heading(address)
            self._send_key_event(address, "HEADING_BUG_SET", heading)
            return
        key_event = mapping.get(trigger)
        if key_event in {"heading_bug_decrement", "heading_bug_increment"}:
            self._step_heading_bug(address, -1 if key_event == "heading_bug_decrement" else 1)
            return
        if key_event in {"stepped_simvar_decrement", "stepped_simvar_increment"}:
            self._step_simvar(address, mapping, -1 if trigger == "left" else 1)
            return
        if key_event:
            self._send_key_event(address, str(key_event), int(mapping.get("parameter", 0)))

    def _input_definition(self, identifier: str) -> dict | None:
        if not identifier.startswith("simvar."):
            return None
        slug = identifier.removeprefix("simvar.")
        for entry in _catalogue("simvars.json"):
            if str(entry.get("slug", "")) == slug:
                return {
                    "id": identifier,
                    "name": entry["name"],
                    "description": entry["description"],
                    "group": entry["group"],
                    "unit": entry["unit"],
                    "data_type": entry["data_type"],
                    "indexable": entry["indexable"],
                    "simvar": entry["name"],
                    "presentation": self._presentation_hint(entry),
                }
        return None

    @staticmethod
    def _colour(value: str, fallback: str) -> tuple[int, int, int]:
        try:
            return ImageColor.getrgb(value)
        except ValueError:
            return ImageColor.getrgb(fallback)

    @staticmethod
    def _font(size: int, *, bold: bool = False) -> ImageFont.ImageFont:
        names = ("DejaVuSans-Bold.ttf", "DejaVuSans.ttf") if bold else ("DejaVuSans.ttf", "DejaVuSans-Bold.ttf")
        for name in names:
            try:
                return ImageFont.truetype(name, size)
            except OSError:
                continue
        return ImageFont.load_default()

    @staticmethod
    def _number(value: object) -> float | None:
        if isinstance(value, bool):
            return float(value)
        try:
            return float(value)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _timer_text(value: object) -> str:
        seconds = Plugin._number(value)
        if seconds is None:
            return str(value)
        seconds = max(0, int(round(seconds)))
        hours, remainder = divmod(seconds, 3600)
        minutes, seconds = divmod(remainder, 60)
        return f"{hours}:{minutes:02}" if hours else f"{minutes:02}:{seconds:02}"

    @staticmethod
    def _compact_unit(unit: str) -> str:
        normalized = unit.casefold().strip()
        return {
            "feet": "ft",
            "feet (ft)": "ft",
            "percent": "%",
            "radians": "",
            "frequency bcd16": "",
            "hours": "",
            "bool": "",
            "boolean": "",
        }.get(normalized, unit)

    def render_live_visual(
        self,
        module_payload: dict,
        extension_settings: dict | None = None,
        render_context: dict | None = None,
    ) -> dict:
        settings = dict(module_payload.get("settings", {}))
        if str(module_payload.get("type", "")) == "msfs.autopilot_button":
            return self._render_autopilot_button(module_payload, extension_settings, render_context)
        kind = str(module_payload.get("type", "msfs.display_status")).removeprefix("msfs.display_")
        if kind == "clock":
            timer = self._timer_settings(settings)
            label = str(timer.get("label") or "MSFS Timer")
            if str(timer.get("mode") or "simvar") == "stopwatch":
                elapsed_seconds, running = self._stopwatch_snapshot(module_payload)
                return {
                    "title": label,
                    "value": self._timer_text(elapsed_seconds),
                    "subtitle": "Running" if running else "Paused",
                }
            selection = timer.get("input", {})
            identifier = str(selection.get("id", "")) if isinstance(selection, dict) else ""
            definition = self._input_definition(identifier)
            if definition is None:
                return {
                    "title": label,
                    "value": "Data unavailable",
                    "subtitle": "Timer source unavailable",
                    "diagnostic": f"Unknown timer input: {identifier}",
                }
            try:
                readout = self.read_input(definition, dict(selection.get("settings", {})), extension_settings)
            except Exception as exc:  # noqa: BLE001
                state = self.connection_status(extension_settings).get("state")
                source = str(definition.get("simvar") or identifier)
                unit = str(definition.get("unit") or "default")
                index = dict(selection.get("settings", {})).get("index") if isinstance(selection, dict) else None
                return {
                    "title": label,
                    "value": "No connection" if state != "connected" else "Data unavailable",
                    "subtitle": "Check SimConnect settings" if state != "connected" else "MSFS did not return this value",
                    "diagnostic": f"{source} (unit={unit}, index={index}): {exc}",
                }
            elapsed_seconds = readout.get("raw_value")
            if str(readout.get("unit") or "").casefold() == "hours":
                numeric = self._number(elapsed_seconds)
                elapsed_seconds = numeric * 3600 if numeric is not None else elapsed_seconds
            return {
                "title": label,
                "value": self._timer_text(elapsed_seconds),
                "subtitle": str(timer.get("detail") or timer.get("name") or "MSFS Timer"),
            }
        status = self._status_settings(settings) if kind == "status" else None
        gauge = self._gauge_settings(settings) if kind == "gauge" else None
        compass = self._compass_settings(settings) if kind == "compass" else None
        if status is not None and str(status.get("resolver") or ""):
            label = str(status.get("label") or settings.get("label") or "MSFS Interactive Status")
            try:
                state_id = self._resolve_status_state(status, extension_settings)
            except Exception as exc:  # noqa: BLE001 - render a friendly state failure
                return self._render_failure(module_payload, label, str(exc), extension_settings, render_context)
            return self._render_display(
                module_payload,
                label,
                None,
                "",
                formatted="",
                presentation={"kind": "status", "status": status, "state_id": state_id},
                render_context=render_context,
            )
        if compass is not None:
            label = str(compass.get("label") or "Compass")
            selection = compass.get("input", {})
            identifier = str(selection.get("id", "")) if isinstance(selection, dict) else ""
            definition = self._input_definition(identifier)
            if definition is None:
                return self._render_data_unavailable(module_payload, label, render_context)
            try:
                primary = self.read_input(definition, dict(selection.get("settings", {})), extension_settings)
                raw_value: object = primary.get("raw_value")
                if str(compass.get("mode") or "") == "dual":
                    secondary_selection = compass.get("secondary_input", {})
                    secondary_id = str(secondary_selection.get("id", "")) if isinstance(secondary_selection, dict) else ""
                    secondary_definition = self._input_definition(secondary_id)
                    if secondary_definition is None:
                        return self._render_data_unavailable(module_payload, label, render_context)
                    secondary = self.read_input(
                        secondary_definition,
                        dict(secondary_selection.get("settings", {})),
                        extension_settings,
                    )
                    raw_value = (primary.get("raw_value"), secondary.get("raw_value"))
            except Exception as exc:  # noqa: BLE001 - render a friendly state failure
                return self._render_failure(module_payload, label, str(exc), extension_settings, render_context)
            return self._render_display(
                module_payload,
                label,
                raw_value,
                str(primary.get("unit") or ""),
                formatted=str(primary.get("value") or "--"),
                presentation={"kind": "compass", "compass": compass},
                render_context=render_context,
            )
        selection = (
            status.get("input", {})
            if status is not None
            else (gauge.get("input", {}) if gauge is not None else settings.get("input", {}))
        )
        identifier = str(selection.get("id", "")) if isinstance(selection, dict) else ""
        definition = self._input_definition(identifier)
        if definition is None:
            title = str((status or {}).get("label") or settings.get("label") or "MSFS Interactive Status")
            return self._render_data_unavailable(module_payload, title, render_context)
        label = str((status or gauge or {}).get("label") or settings.get("label") or definition["name"])
        try:
            read_definition = dict(definition)
            input_settings = dict(selection.get("settings", {})) if isinstance(selection, dict) else {}
            if gauge is not None:
                request_unit = str(gauge.get("request_unit") or "").strip()
                if request_unit:
                    read_definition["unit"] = request_unit
                input_settings["decimal_places"] = gauge.get("decimal_places", 1)
            readout = self.read_input(read_definition, input_settings, extension_settings)
        except Exception as exc:  # noqa: BLE001
            return self._render_failure(module_payload, label, str(exc), extension_settings, render_context)
        if status is not None:
            readout_mode = str(status.get("mode") or "") == "readout"
            active = None if readout_mode else self._status_is_active(status, readout.get("raw_value"))
            return self._render_display(
                module_payload,
                label,
                readout.get("raw_value"),
                str(readout.get("unit") or ""),
                formatted=str(readout.get("value") or "--"),
                presentation={
                    "kind": "status",
                    "status": status,
                    "state_id": "readout" if readout_mode else ("active" if active else "inactive"),
                },
                render_context=render_context,
            )
        if gauge is not None:
            minimum, maximum, critical = self._gauge_range(gauge, readout.get("raw_value"), extension_settings)
            return self._render_display(
                module_payload,
                label,
                readout.get("raw_value"),
                str(gauge.get("display_unit") or readout.get("unit") or ""),
                formatted=self._format_readout_value(readout.get("raw_value"), gauge.get("decimal_places", 1)),
                presentation={
                    "kind": "gauge",
                    "gauge": {**gauge, "minimum": minimum, "maximum": maximum, "critical": critical},
                },
                render_context=render_context,
            )
        if kind == "position":
            longitude_selection = settings.get("longitude", {})
            longitude_id = str(longitude_selection.get("id", "")) if isinstance(longitude_selection, dict) else ""
            longitude_definition = self._input_definition(longitude_id)
            if longitude_definition is None:
                return self._render_data_unavailable(module_payload, str(settings.get("label") or "Position"), render_context)
            try:
                longitude = self.read_input(
                    longitude_definition,
                    dict(longitude_selection.get("settings", {})),
                    extension_settings,
                )
            except Exception as exc:  # noqa: BLE001
                return self._render_failure(
                    module_payload,
                    str(settings.get("label") or "Position"),
                    str(exc),
                    extension_settings,
                    render_context,
                )
            return self._render_display(
                module_payload,
                str(settings.get("label") or "Position"),
                (readout.get("raw_value"), longitude.get("raw_value")),
                "",
                formatted="Position",
                presentation={"kind": "position"},
                render_context=render_context,
            )
        return self._render_display(
            module_payload,
            label,
            readout.get("raw_value"),
            str(readout.get("unit") or ""),
            formatted=str(readout.get("value") or "--"),
            presentation=dict(readout.get("presentation") or {}),
            render_context=render_context,
        )

    def runtime_options(
        self,
        provider: str,
        _context: dict | None = None,
        extension_settings: dict | None = None,
    ) -> dict:
        if provider != "aircraft_input_events":
            return {"options": [], "message": "Unknown runtime option provider"}
        try:
            return {"options": self._aircraft_input_events(extension_settings), "message": ""}
        except Exception as exc:  # noqa: BLE001 - present a non-fatal editor state
            return {"options": [], "message": str(exc)}

    def _aircraft_input_events(self, extension_settings: dict | None) -> list[dict[str, object]]:
        now = time.monotonic()
        cached = self._aircraft_input_events_cache
        if cached is not None and now - cached[0] < 5.0:
            return copy.deepcopy(cached[1])
        response = self._request({"operation": "list_input_events", "address": self._address(extension_settings)})
        if not response.get("ok"):
            raise RuntimeError(str(response.get("error") or "Could not list aircraft controls"))
        events = response.get("value")
        if not isinstance(events, list):
            raise RuntimeError("SimConnect returned an invalid aircraft control list")
        options: list[dict[str, object]] = []
        for event in events:
            if not isinstance(event, dict):
                continue
            name = str(event.get("name") or "").strip()
            try:
                event_hash = int(event.get("hash") or 0)
            except (TypeError, ValueError):
                continue
            if not name or not event_hash:
                continue
            options.append(
                {
                    "value": name,
                    "label": name,
                    "hash": event_hash,
                    "group": "VNAV candidates" if "vnav" in name.casefold() else "All aircraft controls",
                }
            )
        options.sort(
            key=lambda option: (
                0 if option["group"] == "VNAV candidates" else 1,
                str(option["label"]).casefold(),
            )
        )
        self._aircraft_input_events_cache = (now, copy.deepcopy(options))
        return options

    def _autopilot_value(self, slug: str, extension_settings: dict | None) -> object:
        address = self._address(extension_settings)
        key = (address, slug)
        now = time.monotonic()
        cached = self._autopilot_value_cache.get(key)
        if cached is not None and now - cached[0] < 0.25:
            return cached[1]
        definition = self._input_definition(f"simvar.{slug}")
        if definition is None:
            raise RuntimeError(f"Missing SimConnect input: {slug}")
        value = self.read_input(definition, {}, extension_settings).get("raw_value")
        self._autopilot_value_cache[key] = (now, value)
        return value

    @staticmethod
    def _autopilot_flag(value: object) -> bool:
        number = Plugin._number(value)
        return number != 0 if number is not None else bool(value)

    def _autopilot_button_state(self, preset: dict[str, object], extension_settings: dict | None) -> tuple[str, str]:
        resolver = str(preset.get("resolver") or "")
        if resolver == "vertical":
            return self._autopilot_vertical_mode(extension_settings)
        if resolver == "approach":
            if self._autopilot_flag(self._autopilot_value("autopilot_approach_captured", extension_settings)):
                return "active", "CAP"
            if self._autopilot_flag(self._autopilot_value("autopilot_approach_arm", extension_settings)):
                return "armed", "ARM"
            return "inactive", "OFF"
        if resolver == "glideslope":
            if self._autopilot_flag(self._autopilot_value("autopilot_glideslope_active", extension_settings)):
                return "active", "CAP"
            if self._autopilot_flag(self._autopilot_value("autopilot_glideslope_arm", extension_settings)):
                return "armed", "ARM"
            return "inactive", "OFF"
        if resolver == "lateral":
            return self._autopilot_lateral_mode(extension_settings)
        if resolver == "dynamic_vnav":
            return "active", "READY"
        if bool(preset.get("action_only")):
            return "active", "READY"
        active = self._autopilot_flag(self._autopilot_value(str(preset.get("state") or ""), extension_settings))
        return ("active", "ON") if active else ("inactive", "OFF")

    def _autopilot_reference(self, preset: dict[str, object], extension_settings: dict | None) -> str:
        resolver = str(preset.get("resolver") or "")
        if resolver == "lateral":
            return ""
        slug = str(preset.get("reference") or "")
        if not slug:
            return ""
        value = self._number(self._autopilot_value(slug, extension_settings))
        if value is None:
            return ""
        if slug == "autopilot_heading_lock_dir":
            return f"{value % 360:03.0f} deg"
        if slug == "autopilot_altitude_lock_var":
            return f"{value:,.0f} ft"
        if slug == "autopilot_vertical_hold_var":
            return f"{value:+.0f} fpm"
        if slug == "autopilot_airspeed_hold_var":
            return f"{value:.0f} kt"
        if slug == "autopilot_mach_hold_var":
            return f"M {value:.2f}"
        if slug == "autopilot_pitch_hold_ref":
            return f"{math.degrees(value):+.1f} deg"
        return str(value)

    def _autopilot_nav_source(self, extension_settings: dict | None) -> str:
        if self._autopilot_flag(self._autopilot_value("gps_drives_nav1", extension_settings)):
            return "GPS"
        index = self._number(self._autopilot_value("autopilot_nav_selected", extension_settings))
        return str(int(index)) if index and index > 0 else ""

    def _autopilot_lateral_mode(self, extension_settings: dict | None) -> tuple[str, str]:
        """Return the currently active lateral AP mode for the NAV annunciator."""
        value = lambda slug: self._autopilot_flag(self._autopilot_value(slug, extension_settings))
        if value("autopilot_backcourse_hold"):
            return "active", "BC"

        approach_active = value("autopilot_approach_captured")
        approach_armed = value("autopilot_approach_arm")
        localizer = value("autopilot_approach_is_localizer")
        if approach_active:
            return "active", "LOC" if localizer else "APR"
        if approach_armed:
            return "armed", "LOC ARM" if localizer else "APR ARM"

        if value("autopilot_nav1_lock"):
            source = self._autopilot_nav_source(extension_settings)
            return "active", source or "NAV"
        if value("autopilot_heading_lock"):
            return "active", "HDG"
        if value("autopilot_bank_hold") or value("autopilot_wing_leveler"):
            return "active", "ROL"
        return "inactive", "OFF"

    def _autopilot_vertical_mode(self, extension_settings: dict | None) -> tuple[str, str]:
        """Return the currently active vertical AP mode for the ALT annunciator."""
        value = lambda slug: self._autopilot_flag(self._autopilot_value(slug, extension_settings))
        if value("autopilot_glideslope_active"):
            return "active", "GS"
        if value("autopilot_glideslope_arm"):
            return "armed", "GS ARM"
        if value("autopilot_altitude_lock"):
            return "active", "ALT"
        if value("autopilot_altitude_arm"):
            return "armed", "ALT ARM"
        if value("autopilot_vertical_hold"):
            return "active", "VS"
        if value("autopilot_flight_level_change"):
            return "active", "FLC"
        if value("autopilot_airspeed_hold"):
            return "active", "IAS"
        if value("autopilot_mach_hold"):
            return "active", "MACH"
        return "inactive", "OFF"

    def _render_autopilot_button(
        self,
        module_payload: dict,
        extension_settings: dict | None,
        render_context: dict | None,
    ) -> dict:
        settings = dict(module_payload.get("settings", {}))
        preset = self._autopilot_button_preset(str(settings.get("control") or "ap_master"))
        label = str(preset["label"])
        if str(preset.get("id")) == "vnav" and not str(settings.get("vnav_event") or "").strip():
            return self._render_data_unavailable(module_payload, label, render_context)
        try:
            state_id, state_text = self._autopilot_button_state(preset, extension_settings)
            detail = self._autopilot_reference(preset, extension_settings)
        except Exception as exc:  # noqa: BLE001
            return self._render_failure(module_payload, label, str(exc), extension_settings, render_context)
        status = {
            "mode": "multi_state",
            "text_size": "medium",
            "detail": detail,
            "inactive_text": state_text if state_id == "inactive" else "OFF",
            "inactive_icon": str(preset["icon"]),
            "inactive_colour": str(preset.get("inactive_colour") or "#708096"),
            "armed_text": state_text if state_id == "armed" else "ARM",
            "armed_icon": str(preset["icon"]),
            "armed_colour": "#FFB454",
            "active_text": state_text if state_id == "active" else "ON",
            "active_icon": str(preset["icon"]),
            "active_colour": str(preset.get("active_colour") or "#39D7A5"),
        }
        visual = dict(module_payload.get("visual", {}))
        background = self._colour(str(settings.get("background") or visual.get("background", "#000000")), "#000000")
        foreground = self._colour(str(settings.get("foreground") or visual.get("foreground", "#edf7ff")), "#edf7ff")
        context = render_context if isinstance(render_context, dict) else {}
        aspect_ratio = max(0.25, min(4.0, float(context.get("aspect_ratio", 1.0) or 1.0)))
        width, height = (512, max(128, round(512 / aspect_ratio))) if aspect_ratio >= 1 else (max(128, round(512 * aspect_ratio)), 512)
        return self._render_status_visual(
            width=width,
            height=height,
            title=label,
            status=status,
            state_id=state_id,
            formatted="",
            failure="",
            background=background,
            foreground=foreground,
            visual=visual,
            asset_paths=dict(module_payload.get("asset_paths", {})),
        )

    @classmethod
    def _status_settings(cls, settings: dict) -> dict:
        configured = settings.get("status")
        if isinstance(configured, dict) and (configured.get("input") or configured.get("preset_id")):
            if configured.get("preset_id") == "avionics_master":
                # The original generic preset always read index 1. Preserve
                # those profiles while presenting the explicit aircraft switch.
                replacement = cls._status_preset("avionics_master_1")
                replacement["text_size"] = str(configured.get("text_size") or replacement["text_size"])
                return replacement
            if configured.get("preset_id") == "barometer":
                # Named Barometer assignments predate fixed precision and the
                # selectable unit. Preserve visual customisation while letting
                # the current preset own its documented input selection.
                replacement = cls._status_preset("barometer")
                selected_unit = str(configured.get("unit") or replacement["unit"])
                selected_option = next(
                    (option for option in replacement["unit_options"] if str(option.get("value")) == selected_unit),
                    replacement["unit_options"][0],
                )
                for key, value in configured.items():
                    if key not in {"input", "unit", "unit_options"}:
                        replacement[key] = copy.deepcopy(value)
                replacement["unit"] = str(selected_option["value"])
                replacement["input"] = copy.deepcopy(selected_option["input"])
                replacement.setdefault("readout_text", str(selected_option.get("detail") or ""))
                return replacement
            return dict(configured)
        # Existing profiles used a raw input plus label/accent. Preserve them on first render.
        return {
            "mode": "boolean",
            "input": dict(settings.get("input", {})),
            "label": str(settings.get("label") or "Status"),
            "active_text": "ON",
            "inactive_text": "OFF",
            "active_icon": "circle",
            "inactive_icon": "circle",
            "active_colour": str(settings.get("accent") or "#39D7A5"),
            "inactive_colour": "#708096",
            "show_value": False,
            "text_size": "medium",
        }

    @classmethod
    def _timer_settings(cls, settings: dict) -> dict:
        configured = settings.get("timer")
        if isinstance(configured, dict) and configured.get("preset_id"):
            value = dict(configured)
            # Existing profile assignments retain their label and text size,
            # while gaining descriptive preset metadata from newer releases.
            preset = cls._timer_preset(str(value["preset_id"]))
            for key in ("detail",):
                if key in preset:
                    value.setdefault(key, preset[key])
            for key in ("fallback_input", "fallback_when_zero", "fallback_name", "fallback_label"):
                value.pop(key, None)
            return value
        # Pre-redesign assignments used a SimConnect-session timer. Preserve a
        # user label while replacing that misleading source with Engine Hobbs.
        value = cls._timer_preset("engine_hobbs")
        if settings.get("label"):
            value["label"] = str(settings["label"])
        return value

    @classmethod
    def _gauge_settings(cls, settings: dict) -> dict:
        configured = settings.get("gauge")
        if isinstance(configured, dict) and configured.get("preset_id"):
            configured = dict(configured)
            preset_id = str(configured.get("preset_id") or "custom")
            if preset_id != "custom":
                preset = cls._gauge_preset(preset_id)
                # Named presets own their source and range. Only their visual
                # presentation and engine selection are user-configurable.
                for key in ("label", "label_size", "value_size", "indicator_style", "engine"):
                    if key in configured:
                        preset[key] = configured[key]
                if preset.get("engine_indexed"):
                    preset["input"] = cls._input_selection(
                        str(preset["input"]["id"]).removeprefix("simvar."),
                        index=max(1, int(preset.get("engine", 1) or 1)),
                    )
                return preset
            return configured
        # Profiles created before the preset editor retain their raw source and
        # range as a Custom gauge until they are next edited.
        return {
            "preset_id": "custom",
            "input": dict(settings.get("input", {})),
            "label": str(settings.get("label") or ""),
            "label_size": "medium",
            "value_size": "medium",
            "indicator_style": "arc",
            "minimum": settings.get("minimum", 0),
            "maximum": settings.get("maximum", 100),
            "decimal_places": 2,
            "bands_enabled": False,
        }

    @classmethod
    def _compass_settings(cls, settings: dict) -> dict:
        configured = settings.get("compass")
        if isinstance(configured, dict) and configured.get("preset_id"):
            preset_id = str(configured.get("preset_id") or "custom")
            if preset_id == "custom":
                return dict(configured)
            preset = cls._compass_preset(preset_id)
            for key in ("label", "label_size", "value_size"):
                if key in configured:
                    preset[key] = configured[key]
            return preset
        # The old Compass stored a raw selection at the module level. Keep it
        # usable as Custom rather than silently replacing the user's source.
        return {
            "preset_id": "custom",
            "input": dict(settings.get("input", {})),
            "label": str(settings.get("label") or "Custom Compass"),
            "label_size": "medium",
            "value_size": "medium",
        }

    def _gauge_range(self, gauge: dict, raw_value: object, extension_settings: dict | None) -> tuple[float, float, bool]:
        minimum = self._number(gauge.get("minimum"))
        maximum = self._number(gauge.get("maximum"))
        minimum = 0.0 if minimum is None else minimum
        maximum = minimum + 1.0 if maximum is None or maximum <= minimum else maximum
        range_slug = str(gauge.get("range_max_slug") or "")
        if range_slug:
            index = int(gauge.get("engine", 1) or 1) if gauge.get("engine_indexed") else 0
            address = self._address(extension_settings)
            cache_key = (address, range_slug, index)
            now = time.monotonic()
            with self._gauge_limit_lock:
                cached = self._gauge_limit_cache.get(cache_key)
            if cached is not None and now - cached[0] < 20:
                maximum = max(minimum + 1.0, cached[1])
            else:
                definition = self._input_definition(f"simvar.{range_slug}")
                if definition is not None:
                    definition = dict(definition)
                    definition["unit"] = str(gauge.get("range_max_unit") or definition.get("unit") or "")
                    try:
                        result = self.read_input(definition, {}, extension_settings)
                        limit = self._number(result.get("raw_value"))
                        if limit is not None and limit > minimum:
                            maximum = limit
                            with self._gauge_limit_lock:
                                self._gauge_limit_cache[cache_key] = (now, limit)
                    except Exception:  # noqa: BLE001 - base scale remains useful without optional metadata
                        pass
        value = self._number(raw_value)
        critical = value is not None and (value < minimum or value > maximum)
        if value is not None:
            if value < minimum:
                minimum = math.floor(value - max(1.0, (maximum - minimum) * 0.1))
            elif value > maximum:
                maximum = math.ceil(value + max(1.0, (maximum - minimum) * 0.1))
        return minimum, maximum, critical

    @staticmethod
    def _stopwatch_key(module_payload: dict) -> str:
        return str(module_payload.get("id") or module_payload.get("control_id") or "stopwatch")

    def _stopwatch_snapshot(self, module_payload: dict) -> tuple[int, bool]:
        key = self._stopwatch_key(module_payload)
        now = time.monotonic()
        with self._stopwatch_lock:
            state = self._stopwatch_state.setdefault(key, {"elapsed": 0.0, "running": False, "started_at": now})
            elapsed = float(state.get("elapsed", 0.0))
            running = bool(state.get("running", False))
            if running:
                elapsed += max(0.0, now - float(state.get("started_at", now)))
        return max(0, int(elapsed)), running

    def _handle_stopwatch_event(self, module_payload: dict, event: dict) -> None:
        trigger = str(event.get("trigger_id") or "")
        if trigger not in {"press", "release"}:
            return
        key = self._stopwatch_key(module_payload)
        now = time.monotonic()
        with self._stopwatch_lock:
            state = self._stopwatch_state.setdefault(key, {"elapsed": 0.0, "running": False, "started_at": now})
            if trigger == "press":
                state["pressed_at"] = now
                return
            pressed_at = state.pop("pressed_at", None)
            if not isinstance(pressed_at, (int, float)):
                return
            if now - pressed_at >= 0.65:
                state.update({"elapsed": 0.0, "running": False, "started_at": now})
                return
            if bool(state.get("running", False)):
                state["elapsed"] = float(state.get("elapsed", 0.0)) + max(0.0, now - float(state.get("started_at", now)))
                state["running"] = False
            else:
                state["started_at"] = now
                state["running"] = True

    def _status_is_active(self, status: dict, value: object) -> bool:
        if str(status.get("mode") or "boolean") != "condition":
            return bool(value)
        number = self._number(value)
        threshold = self._number(status.get("threshold"))
        if number is None or threshold is None:
            return False
        comparison = str(status.get("comparison") or "gt")
        return {
            "gt": number > threshold,
            "gte": number >= threshold,
            "lt": number < threshold,
            "lte": number <= threshold,
            "eq": number == threshold,
            "ne": number != threshold,
        }.get(comparison, number > threshold)

    def _resolve_status_state(self, status: dict, extension_settings: dict | None) -> str:
        resolver = str(status.get("resolver") or "")
        if resolver == "transponder_state":
            definition = self._input_definition("simvar.transponder_state")
            if definition is None:
                raise RuntimeError("Missing SimConnect input: transponder_state")
            input_settings = dict(status.get("input", {}).get("settings", {}))
            # Existing profiles predate the explicit transponder index. The
            # documented standard transponder is index 1, so preserve those
            # profile settings while reading the value that MSFS actually uses.
            input_settings.setdefault("index", 1)
            readout = self.read_input(definition, input_settings, extension_settings)
            value = self._number(readout.get("raw_value"))
            states = {0: "off", 1: "standby", 2: "test", 3: "on", 4: "alt", 5: "ground"}
            if value is None or int(value) not in states:
                raise RuntimeError("SimConnect returned an unknown transponder state")
            return states[int(value)]
        if resolver == "altitude_mode":
            states: dict[str, bool] = {}
            for state_id, slug in (
                ("hold", "autopilot_altitude_lock"),
                ("armed", "autopilot_altitude_arm"),
            ):
                definition = self._input_definition(f"simvar.{slug}")
                if definition is None:
                    raise RuntimeError(f"Missing SimConnect input: {slug}")
                readout = self.read_input(definition, {}, extension_settings)
                value = self._number(readout.get("raw_value"))
                states[state_id] = value != 0 if value is not None else bool(readout.get("raw_value"))
            return "hold" if states["hold"] else "armed" if states["armed"] else "off"
        if resolver != "magneto_starter":
            raise RuntimeError(f"Unsupported MSFS status resolver: {resolver}")

        engine = max(1, int(status.get("engine", 1) or 1))
        values: dict[str, bool] = {}
        for key, slug in (
            ("left", "recip_eng_left_magneto"),
            ("right", "recip_eng_right_magneto"),
            ("starting", "general_eng_starter_active"),
        ):
            definition = self._input_definition(f"simvar.{slug}")
            if definition is None:
                raise RuntimeError(f"Missing SimConnect input: {slug}")
            readout = self.read_input(definition, {"index": engine}, extension_settings)
            value = self._number(readout.get("raw_value"))
            values[key] = value != 0 if value is not None else bool(readout.get("raw_value"))

        if values["starting"]:
            return "starting"
        if values["left"] and values["right"]:
            return "both"
        if values["left"]:
            return "left"
        if values["right"]:
            return "right"
        return "off"


    def _render_failure(
        self,
        module_payload: dict,
        title: str,
        error: str,
        extension_settings: dict | None,
        render_context: dict | None,
    ) -> dict:
        status = self.connection_status(extension_settings)
        if status.get("state") != "connected":
            return self._render_display(
                module_payload,
                title,
                None,
                "",
                failure="connection",
                render_context=render_context,
            )
        return self._render_data_unavailable(module_payload, title, render_context)

    def _render_data_unavailable(self, module_payload: dict, title: str, render_context: dict | None) -> dict:
        return self._render_display(
            module_payload,
            title,
            None,
            "",
            failure="data",
            render_context=render_context,
        )

    def _render_status_visual(
        self,
        *,
        width: int,
        height: int,
        title: str,
        status: dict,
        active: bool | None = None,
        state_id: str | None = None,
        formatted: str,
        failure: str,
        background: tuple[int, int, int],
        foreground: tuple[int, int, int],
        visual: dict,
        asset_paths: dict,
    ) -> dict:
        image = Image.new("RGB", (width, height), background)
        draw = ImageDraw.Draw(image)
        margin = max(10, min(width, height) // 12)
        size_scale = {"small": 0.82, "medium": 1.0, "large": 1.18}.get(
            str(status.get("text_size") or "medium"),
            1.0,
        )
        label_font = self._font(max(11, round(min(width, height) // 8 * size_scale)), bold=True)
        state_font = self._font(max(13, round(min(width, height) // 6 * size_scale)), bold=True)
        detail_font = self._font(max(11, round(min(width, height) // 9 * size_scale)), bold=True)
        unavailable = bool(failure)
        if unavailable:
            icon_name = "warning-circle"
            icon_weight = "regular"
            icon_path = ""
            icon_mode = "builtin"
            show_icon = True
            colour = (255, 180, 64)
            state = "NO SIMCONNECT" if failure == "connection" else "DATA UNAVAILABLE"
            detail = "Start MSFS or check settings" if failure == "connection" else "Choose another source or check the aircraft"
        else:
            readout_mode = str(status.get("mode") or "") == "readout"
            resolved_state_id = str(state_id or ("readout" if readout_mode else ("active" if active else "inactive")))
            icon_name = str(status.get(f"{resolved_state_id}_icon") or "")
            icon_weight = str(status.get(f"{resolved_state_id}_icon_weight") or "regular")
            icon_path = str(asset_paths.get(f"status_{resolved_state_id}_icon_path") or "")
            icon_mode = str(status.get(f"{resolved_state_id}_icon_mode") or "")
            if icon_mode not in {"builtin", "imported", "none"}:
                icon_mode = "imported" if icon_path else "builtin"
            show_icon = icon_mode != "none"
            if icon_mode == "builtin" and not icon_name:
                icon_name = "circle"
            colour = self._colour(str(status.get(f"{resolved_state_id}_colour") or "#708096"), "#708096")
            if readout_mode:
                state = formatted
                detail = str(status.get(f"{resolved_state_id}_text") or "")
            else:
                state = str(status.get(f"{resolved_state_id}_text") or resolved_state_id.upper())
                detail = str(status.get("detail") or "")
                if bool(status.get("show_value")):
                    detail = formatted
        wide = width >= height * 1.45
        if wide:
            icon_box = (margin, height // 2 - min(height - margin * 2, width // 3) // 2, min(height - margin * 2, width // 3), min(height - margin * 2, width // 3))
            text_x = icon_box[0] + icon_box[2] + margin
            draw.text((text_x, margin), title[:28], fill=foreground, font=label_font)
            draw.text((text_x, height // 2 - state_font.size // 2), state[:20], fill=foreground, font=state_font)
            if detail:
                draw.text((text_x, height - margin), detail[:28], anchor="ls", fill=colour, font=detail_font)
        else:
            icon_size = min(width - margin * 2, max(38, int(height * 0.42)))
            icon_box = ((width - icon_size) // 2, max(margin + label_font.size + 6, height // 2 - icon_size // 2), icon_size, icon_size)
            draw.text((width // 2, margin), title[:24], anchor="ma", fill=foreground, font=label_font)
            draw.text((width // 2, height - margin), state[:20], anchor="ms", fill=foreground, font=state_font)
            if detail:
                draw.text((width // 2, height - margin - state_font.size - 3), detail[:24], anchor="ms", fill=colour, font=detail_font)
        if show_icon:
            self._draw_status_icon(
                image,
                icon_name if icon_mode != "imported" else "",
                icon_box,
                colour,
                icon_weight=icon_weight,
                asset_path=icon_path if icon_mode == "imported" else "",
            )
        buffer = BytesIO()
        image.save(buffer, format="PNG")
        return {"title": title, "value": state, "subtitle": detail or "MSFS", "image_png": buffer.getvalue()}

    @staticmethod
    def _draw_status_icon(
        image: Image.Image,
        icon_name: str,
        box: tuple[int, int, int, int],
        colour: tuple[int, int, int],
        *,
        icon_weight: str = "regular",
        asset_path: str = "",
    ) -> None:
        if asset_path:
            try:
                from macro_pad_manager.core.svg_assets import rasterize_svg_to_png_bytes

                if str(asset_path).lower().endswith(".svg"):
                    icon = Image.open(
                        BytesIO(
                            rasterize_svg_to_png_bytes(
                                asset_path,
                                (box[2], box[3]),
                                tint="#%02X%02X%02X" % colour,
                            )
                        )
                    ).convert("RGBA")
                else:
                    icon = Image.open(asset_path).convert("RGBA")
                    icon.thumbnail((box[2], box[3]), Image.Resampling.LANCZOS)
                x = box[0] + (box[2] - icon.width) // 2
                y = box[1] + (box[3] - icon.height) // 2
                image.paste(icon, (x, y), icon)
                return
            except Exception:
                pass
        try:
            from macro_pad_manager.builtin.icon_pack import load_icon_index, resolve_icon_path
            from macro_pad_manager.core.svg_assets import rasterize_svg_to_png_bytes

            entry = next(
                item
                for item in load_icon_index()
                if str(item.get("icon")) == icon_name and str(item.get("weight", "regular")) == icon_weight
            )
            icon = Image.open(BytesIO(rasterize_svg_to_png_bytes(resolve_icon_path(entry), (box[2], box[3]), tint="#%02X%02X%02X" % colour))).convert("RGBA")
            image.paste(icon, (box[0], box[1]), icon)
            return
        except Exception:
            pass
        draw = ImageDraw.Draw(image)
        draw.ellipse((box[0], box[1], box[0] + box[2], box[1] + box[3]), outline=colour, width=max(3, box[2] // 12))

    def _render_display(
        self,
        module_payload: dict,
        title: str,
        raw_value: object,
        unit: str,
        *,
        formatted: str = "--",
        failure: str = "",
        presentation: dict | None = None,
        render_context: dict | None = None,
    ) -> dict:
        settings = dict(module_payload.get("settings", {}))
        visual = dict(module_payload.get("visual", {}))
        kind = str(module_payload.get("type", "msfs.display_status")).removeprefix("msfs.display_")
        context = render_context if isinstance(render_context, dict) else {}
        try:
            aspect_ratio = max(0.25, min(4.0, float(context.get("aspect_ratio", 1.0))))
        except (TypeError, ValueError):
            aspect_ratio = 1.0
        if aspect_ratio >= 1.0:
            width, height = 512, max(128, round(512 / aspect_ratio))
        else:
            width, height = max(128, round(512 * aspect_ratio)), 512
        suggested_range = dict(presentation or {})
        timer = dict(suggested_range.get("timer") or {}) if kind == "clock" else {}
        compass = dict(suggested_range.get("compass") or self._compass_settings(settings)) if kind == "compass" else {}
        background = self._colour(str(settings.get("background") or visual.get("background", "#000000")), "#000000")
        foreground = self._colour(str(settings.get("foreground") or visual.get("foreground", "#edf7ff")), "#edf7ff")
        accent = self._colour(
            str((timer or compass).get("accent") or settings.get("accent", "#39d7a5")),
            "#39d7a5",
        )
        warning_colour = (255, 170, 45)
        image = Image.new("RGB", (width, height), background)
        draw = ImageDraw.Draw(image)
        edge = max(2, min(width, height) // 42)
        margin = max(8, min(width, height) // 12)
        text_scale = {"small": 0.82, "medium": 1.0, "large": 1.18}.get(
            str((timer or compass).get("text_size") or "medium"),
            1.0,
        )
        label_font = self._font(max(10, round(min(width, height) // 9 * text_scale)), bold=True)
        value_font = self._font(max(17, round(min(width, height) // 3 * text_scale)), bold=True)
        detail_font = self._font(max(9, min(width, height) // 10))
        if kind == "status":
            status = dict(suggested.get("status") or self._status_settings(settings)) if (suggested := dict(presentation or {})) else self._status_settings(settings)
            state_id = str(suggested.get("state_id") or ("active" if bool(raw_value) else "inactive"))
            return self._render_status_visual(
                width=width,
                height=height,
                title=title,
                status=status,
                state_id=state_id,
                formatted=formatted,
                failure=failure,
                background=background,
                foreground=foreground,
                visual=visual,
                asset_paths=dict(module_payload.get("asset_paths", {})),
            )
        if kind not in {"gauge", "compass"}:
            draw.rounded_rectangle((margin, margin, width - margin, margin + edge), radius=edge, fill=accent)
            draw.text((margin, margin + edge + 5), title[:22], fill=foreground, font=label_font)
        elif kind == "compass":
            compass_label_scale = {"small": 0.82, "medium": 1.0, "large": 1.18}.get(
                str(compass.get("label_size") or "medium"),
                1.0,
            )
            compass_compact = min(width, height) < 190 or aspect_ratio > 2.2
            if not compass_compact:
                compass_title_font = self._font(max(10, round(min(width, height) // 10 * compass_label_scale)), bold=True)
                draw.text((width // 2, margin), title[:24], anchor="ma", fill=foreground, font=compass_title_font)

        number = self._number(raw_value)
        shown_value = formatted
        display_unit = self._compact_unit(unit)
        if display_unit:
            shown_value = f"{shown_value}{display_unit if display_unit == '%' else f' {display_unit}'}".strip()
        if kind == "clock":
            elapsed_seconds = number * 3600 if number is not None and unit.casefold() == "hours" else raw_value
            shown_value = self._timer_text(elapsed_seconds)

        if failure == "connection":
            draw.text((margin, height // 2 - 2), "SimConnect unavailable", fill=warning_colour, font=label_font)
            draw.text((margin, height // 2 + detail_font.size + 5), "Start MSFS or check settings", fill=foreground, font=detail_font)
            shown_value = "No connection"
        elif failure == "data":
            draw.text((margin, height // 2 - 2), "Data unavailable", fill=warning_colour, font=label_font)
            draw.text((margin, height // 2 + detail_font.size + 5), "Choose another value or check the aircraft", fill=foreground, font=detail_font)
            shown_value = "Data unavailable"
        elif kind in {"status", "warning"}:
            active = bool(raw_value)
            colour = warning_colour if kind == "warning" and active else accent if active else (112, 128, 150)
            dot_size = max(18, min(width, height) // 4)
            dot_top = height // 2 - dot_size // 2 + 8
            draw.ellipse((margin, dot_top, margin + dot_size, dot_top + dot_size), fill=colour)
            if kind == "warning":
                state = "STALL" if active else "CLEAR"
            elif title.casefold() == "on ground":
                state = "ON GROUND" if active else "IN FLIGHT"
            else:
                state = "ON" if active else "OFF"
            draw.text((margin + dot_size + 9, dot_top + max(0, dot_size // 5)), state, fill=foreground, font=label_font)
            shown_value = state
        elif kind == "level":
            minimum, maximum = float(settings.get("minimum", 0)), float(settings.get("maximum", 100))
            if minimum == 0 and maximum == 100 and suggested_range.get("maximum") == 1:
                maximum = 1
            ratio = 0.0 if number is None or maximum <= minimum else max(0.0, min(1.0, (number - minimum) / (maximum - minimum)))
            draw.text((margin, height // 2 - 8), shown_value, fill=foreground, font=value_font)
            bar_top = height - margin - max(12, height // 9)
            draw.rounded_rectangle((margin, bar_top, width - margin, height - margin), radius=edge * 2, fill=(30, 47, 66))
            if ratio:
                draw.rounded_rectangle((margin, bar_top, margin + int((width - 2 * margin) * ratio), height - margin), radius=edge * 2, fill=accent)
        elif kind == "gauge":
            gauge = dict(suggested_range.get("gauge") or self._gauge_settings(settings))
            minimum = self._number(gauge.get("minimum"))
            maximum = self._number(gauge.get("maximum"))
            minimum = 0.0 if minimum is None else minimum
            maximum = minimum + 1.0 if maximum is None or maximum <= minimum else maximum
            ratio = 0.0 if number is None else max(0.0, min(1.0, (number - minimum) / (maximum - minimum)))
            style = str(gauge.get("indicator_style") or "arc")
            band_profile = str(gauge.get("band_profile") or "")
            gauge_colour = accent
            track_segments: list[tuple[float, float, tuple[int, int, int]]] = []
            if bool(gauge.get("bands_enabled")) and number is not None:
                normal_minimum = self._number(gauge.get("normal_minimum"))
                normal_maximum = self._number(gauge.get("normal_maximum"))
                normal_start = 0.0 if normal_minimum is None else max(0.0, min(1.0, (normal_minimum - minimum) / (maximum - minimum)))
                normal_end = 1.0 if normal_maximum is None else max(0.0, min(1.0, (normal_maximum - minimum) / (maximum - minimum)))
                track_segments = [
                    (0.0, normal_start, warning_colour),
                    (normal_start, normal_end, (57, 215, 165)),
                    (normal_end, 1.0, warning_colour),
                ]
                if bool(gauge.get("critical")):
                    gauge_colour = (232, 91, 91)
                elif normal_minimum is not None and normal_maximum is not None and normal_minimum <= number <= normal_maximum:
                    gauge_colour = (57, 215, 165)
                else:
                    gauge_colour = warning_colour
            elif band_profile == "upper_limit":
                # SimConnect supplies this preset's upper operating limit.
                # The final 5% is critical and the preceding 10% is caution.
                track_segments = [
                    (0.0, 0.85, (57, 215, 165)),
                    (0.85, 0.95, warning_colour),
                    (0.95, 1.0, (232, 91, 91)),
                ]
                if bool(gauge.get("critical")) or ratio >= 0.95:
                    gauge_colour = (232, 91, 91)
                elif ratio >= 0.85:
                    gauge_colour = warning_colour
                else:
                    gauge_colour = (57, 215, 165)
            small = min(width, height) < 190 or aspect_ratio > 2.2
            # Keep the label and readout proportional on both compact keys and
            # wider touch surfaces; neither should dominate the gauge itself.
            label_scale = {"small": 0.82, "medium": 1.0, "large": 1.18}.get(
                str(gauge.get("label_size") or "medium"), 1.0
            )
            value_scale = {"small": 0.82, "medium": 1.0, "large": 1.18}.get(
                str(gauge.get("value_size") or "medium"), 1.0
            )
            title_font = self._font(max(11, round(min(width, height) // 12 * label_scale)), bold=True)
            gauge_value_font = self._font(max(14, round(min(width, height) // 8 * value_scale)), bold=True)
            unit_font = self._font(max(9, round(min(width, height) // 15 * value_scale)), bold=True)
            value_text = shown_value
            if display_unit:
                value_text = formatted
            if not small:
                draw.text((width // 2, margin), title[:24], anchor="ma", fill=foreground, font=title_font)
            if small:
                center = (width // 2, height // 2)
                radius = max(20, min(width, height) // 2 - margin)
            else:
                center = (width // 2, height // 2 + title_font.size // 3)
                radius = max(20, min(width - 2 * margin, height - title_font.size - margin * 3) // 2)
            box = (center[0] - radius, center[1] - radius, center[0] + radius, center[1] + radius)
            stroke = max(3, radius // 7)
            track_colour = (30, 47, 66)
            def draw_track(start_angle: float, sweep: float) -> None:
                if not track_segments:
                    draw.arc(box, start_angle, start_angle + sweep, fill=track_colour, width=stroke)
                    return
                for segment_start, segment_end, colour in track_segments:
                    if segment_end <= segment_start:
                        continue
                    draw.arc(
                        box,
                        start_angle + sweep * segment_start,
                        start_angle + sweep * segment_end,
                        fill=colour,
                        width=stroke,
                    )
            if style == "ring":
                draw_track(-90, 360)
                draw.arc(box, -90, -90 + int(360 * ratio), fill=gauge_colour, width=stroke)
            else:
                draw_track(135, 270)
                if style == "needle":
                    angle = math.radians(135 + 270 * ratio)
                    needle_length = max(8, radius - stroke * 2)
                    tip = (center[0] + int(math.cos(angle) * needle_length), center[1] + int(math.sin(angle) * needle_length))
                    draw.line((center, tip), fill=gauge_colour, width=max(3, stroke // 2))
                    hub = max(4, stroke // 2)
                    draw.ellipse((center[0] - hub, center[1] - hub, center[0] + hub, center[1] + hub), fill=gauge_colour)
                else:
                    draw.arc(box, 135, 135 + int(270 * ratio), fill=gauge_colour, width=stroke)
            # Needle gauges reserve the lower opening for the readout so the
            # indicator remains legible instead of crossing the live value.
            value_y = center[1] + int(radius * 0.38) if style == "needle" else center[1]
            draw.text((center[0], value_y), value_text, anchor="mm", fill=foreground, font=gauge_value_font)
            if display_unit:
                draw.text((center[0], value_y + gauge_value_font.size // 2 + unit_font.size), display_unit, anchor="mm", fill=gauge_colour, font=unit_font)
        elif kind == "clock":
            draw.text((width // 2, height // 2 + 8), shown_value, anchor="mm", fill=foreground, font=value_font)
            if str(timer.get("mode") or "simvar") == "stopwatch":
                timer_state = "RUNNING" if bool(suggested_range.get("running")) else "PAUSED"
            else:
                timer_state = str(timer.get("name") or timer.get("label") or "MSFS TIMER").upper()
            draw.text((width // 2, height - margin), timer_state[:28], anchor="ms", fill=accent, font=detail_font)
        elif kind == "compass":
            primary, secondary = raw_value if isinstance(raw_value, tuple) else (raw_value, None)
            degrees = self._compass_degrees(primary)
            bug_degrees = self._compass_degrees(secondary) if secondary is not None else None
            compact = min(width, height) < 190 or aspect_ratio > 2.2
            label_scale = {"small": 0.82, "medium": 1.0, "large": 1.18}.get(
                str(compass.get("label_size") or "medium"),
                1.0,
            )
            value_scale = {"small": 0.82, "medium": 1.0, "large": 1.18}.get(
                str(compass.get("value_size") or "medium"),
                1.0,
            )
            title_height = 0 if compact else max(14, round(min(width, height) // 10 * label_scale))
            readout_height = max(16, round(min(width, height) // 7 * value_scale))
            available_height = height - margin * 2 - title_height - readout_height
            radius = max(22, min(width - margin * 2, available_height) // 2)
            center_y = margin + title_height + available_height // 2
            center = (width // 2, center_y)
            card_box = (center[0] - radius, center[1] - radius, center[0] + radius, center[1] + radius)
            stroke = max(2, radius // 13)
            track = (30, 47, 66)
            draw.ellipse(card_box, outline=track, width=stroke)

            # The card turns beneath a fixed aircraft marker. This keeps the
            # same mental model on small keys and wide touch displays.
            tick_inner = max(5, radius // 9)
            tick_font = self._font(max(8, radius // 6), bold=True)
            for bearing, label in ((0, "N"), (90, "E"), (180, "S"), (270, "W")):
                angle = math.radians(bearing - degrees - 90)
                outer = (center[0] + int(math.cos(angle) * radius), center[1] + int(math.sin(angle) * radius))
                inner = (
                    center[0] + int(math.cos(angle) * (radius - tick_inner)),
                    center[1] + int(math.sin(angle) * (radius - tick_inner)),
                )
                draw.line((outer, inner), fill=accent if label == "N" else foreground, width=stroke)
                text_point = (
                    center[0] + int(math.cos(angle) * (radius - tick_inner * 3)),
                    center[1] + int(math.sin(angle) * (radius - tick_inner * 3)),
                )
                draw.text(text_point, label, anchor="mm", fill=accent if label == "N" else foreground, font=tick_font)
            for bearing in range(0, 360, 30):
                if bearing % 90 == 0:
                    continue
                angle = math.radians(bearing - degrees - 90)
                outer = (center[0] + int(math.cos(angle) * radius), center[1] + int(math.sin(angle) * radius))
                inner = (
                    center[0] + int(math.cos(angle) * (radius - max(4, tick_inner // 2))),
                    center[1] + int(math.sin(angle) * (radius - max(4, tick_inner // 2))),
                )
                draw.line((outer, inner), fill=track, width=max(1, stroke // 2))

            marker_width = max(7, radius // 5)
            marker_height = max(10, radius // 4)
            marker_top = center[1] - radius - max(2, stroke // 2)
            draw.polygon(
                [(center[0], marker_top), (center[0] - marker_width, marker_top + marker_height), (center[0] + marker_width, marker_top + marker_height)],
                fill=foreground,
            )
            if bug_degrees is not None:
                bug_angle = math.radians(bug_degrees - degrees - 90)
                bug_center = (
                    center[0] + int(math.cos(bug_angle) * (radius - tick_inner * 2)),
                    center[1] + int(math.sin(bug_angle) * (radius - tick_inner * 2)),
                )
                bug_size = max(6, radius // 8)
                draw.ellipse(
                    (bug_center[0] - bug_size, bug_center[1] - bug_size, bug_center[0] + bug_size, bug_center[1] + bug_size),
                    fill=accent,
                )
                draw.line((center, bug_center), fill=accent, width=max(2, stroke // 2))
            value_font = self._font(max(14, round(min(width, height) // 7 * value_scale)), bold=True)
            value_text = f"{degrees:03.0f}°"
            if bug_degrees is not None:
                value_text = f"{value_text}  {bug_degrees:03.0f}°"
            draw.text((width // 2, height - margin), value_text, anchor="ms", fill=foreground, font=value_font)
            shown_value = value_text
        elif kind == "frequency":
            draw.text((width // 2, height // 2 + 8), shown_value, anchor="mm", fill=accent, font=value_font)
        elif kind == "position":
            latitude, longitude = raw_value if isinstance(raw_value, tuple) and len(raw_value) == 2 else (None, None)
            latitude_text = self._coordinate_text(latitude, "N", "S")
            longitude_text = self._coordinate_text(longitude, "E", "W")
            shown_value = f"{latitude_text}\n{longitude_text}"
            draw.multiline_text((margin, height // 2 - 3), shown_value, fill=foreground, font=label_font, spacing=max(4, detail_font.size // 2))
        else:
            draw.text((width // 2, height // 2 + 8), shown_value, anchor="mm", fill=foreground, font=value_font)

        buffer = BytesIO()
        image.save(buffer, format="PNG")
        return {"title": title, "value": shown_value, "subtitle": unit or "MSFS", "image_png": buffer.getvalue()}

    @staticmethod
    def _coordinate_text(value: object, positive: str, negative: str) -> str:
        number = Plugin._number(value)
        if number is None:
            return "--"
        if abs(number) <= math.tau + 0.01:
            number = math.degrees(number)
        hemisphere = positive if number >= 0 else negative
        return f"{abs(number):.4f}° {hemisphere}"

    @classmethod
    def _compass_degrees(cls, value: object) -> float:
        degrees = cls._number(value)
        degrees = 0.0 if degrees is None else degrees
        if abs(degrees) <= math.tau + 0.01:
            degrees = math.degrees(degrees)
        return degrees % 360

    def _read_magnetic_heading(self, address: str) -> int:
        response = self._request(
            {
                "operation": "read_simvar",
                "address": address,
                "simvar": "PLANE HEADING DEGREES MAGNETIC",
                "unit": "Degrees",
                "index": None,
                "data_type": "number",
            }
        )
        if not response.get("ok"):
            raise RuntimeError(str(response.get("error") or "Could not read the current magnetic heading"))
        try:
            return int(round(float(response.get("value")))) % 360
        except (TypeError, ValueError) as error:
            raise RuntimeError("SimConnect returned an invalid magnetic heading") from error

    def _step_heading_bug(self, address: str, step: int) -> None:
        """Adjust the standard heading bug without requiring a selected cockpit bug."""
        response = self._request(
            {
                "operation": "read_simvar",
                "address": address,
                "simvar": "AUTOPILOT HEADING LOCK DIR",
                "unit": "Degrees",
                "index": None,
                "data_type": "number",
            }
        )
        if not response.get("ok"):
            raise RuntimeError(str(response.get("error") or "Could not read the current heading bug"))
        try:
            heading = int(round(float(response.get("value")))) % 360
        except (TypeError, ValueError) as error:
            raise RuntimeError("SimConnect returned an invalid heading bug") from error
        self._send_key_event(address, "HEADING_BUG_SET", (heading + step) % 360)

    def _step_simvar(self, address: str, mapping: dict[str, str | int], step: int) -> None:
        """Move a bounded, indexed SimVar by one discrete state."""
        simvar = str(mapping.get("simvar") or "").strip()
        unit = str(mapping.get("unit") or "").strip()
        if not simvar or not unit:
            raise RuntimeError("The selected dial control does not define a simulator value")
        minimum = int(mapping.get("minimum", 0))
        maximum = int(mapping.get("maximum", minimum))
        index = mapping.get("index")
        response = self._request(
            {
                "operation": "read_simvar",
                "address": address,
                "simvar": simvar,
                "unit": unit,
                "index": int(index) if index is not None else None,
                "data_type": "integer",
            }
        )
        if not response.get("ok"):
            raise RuntimeError(str(response.get("error") or f"Could not read {simvar}"))
        try:
            current = int(round(float(response.get("value"))))
        except (TypeError, ValueError) as error:
            raise RuntimeError(f"SimConnect returned an invalid value for {simvar}") from error
        target = max(minimum, min(maximum, current + step))
        if target == current:
            return
        response = self._request(
            {
                "operation": "set_simvar",
                "address": address,
                "simvar": simvar,
                "unit": unit,
                "index": int(index) if index is not None else None,
                "data_type": "integer",
                "value": target,
            }
        )
        if not response.get("ok"):
            raise RuntimeError(str(response.get("error") or f"Could not set {simvar}"))

    def _send_key_event(self, address: str, event: str, parameter: int = 0) -> None:
        response = self._request(
            {"operation": "key_event", "address": address, "event": event, "parameter": parameter}
        )
        if not response.get("ok"):
            raise RuntimeError(str(response.get("error") or f"SimConnect rejected {event}"))

    def copy_input(self, identifier: str) -> dict | None:
        return next((copy.deepcopy(item) for item in self.inputs() if item["id"] == identifier), None)
