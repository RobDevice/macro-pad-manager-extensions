# macro-pad-manager-msfs-simconnect-
# Macro Pad Manager MSFS SimConnect

Macro Pad Manager feature pack for Microsoft Flight Simulator 2020 through
SimConnect. It contributes standard SimVars as inputs and standard Key Events
plus writable SimVars as actions. It intentionally excludes aircraft-specific
L:Vars, H: events, and dynamic Input Events in the first release.

## MSFS Cockpit Dial

The `MSFS Cockpit Dial` module maps one physical dial to a standard simulator
cockpit control. Its Control setting covers autopilot altitude, heading,
vertical speed, and airspeed; COM/NAV frequency tuning; NAV course, transponder
digits, altimeter pressure, and G1000 PFD page navigation.

Each detent sends one standard SimConnect increment or decrement event. Heading
press synchronizes the heading bug to the current magnetic heading. G1000 PFD
Page and Page Group presses toggle the PFD cursor. Other controls intentionally
leave press unused when the real-world function belongs to a separate button or
varies by aircraft.

The PFD controls follow the standard G1000 events. Aircraft without matching
avionics can ignore those events; aircraft-specific L:Vars, H: events, and
dynamic Input Events remain out of scope.

The extension defaults to `127.0.0.1:500`. Configure another endpoint in the
extension's settings when SimConnect is exposed on a different host or port.

## Refreshing the official catalogue

```bash
python3 tools/import_msfs_catalogue.py
```

## Packaging

```bash
python3 scripts/package_extension.py ../extensions-repo/artifacts
```

Commit the resulting ZIP and matching catalogue entry to the distribution-only
`macro-pad-manager-extensions` repository.
