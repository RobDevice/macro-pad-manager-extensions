use std::collections::HashMap;
use std::io::{self, BufRead};

use serde::{Deserialize, Serialize};
use serde_json::Value;
use simconnect::proto::codec::PacketReader;
use simconnect::proto::enums::{DataRequestFlags, DataSetFlags, DataType, EventFlags, Period, RecvId};
use simconnect::proto::recv;
use simconnect::SimConnect;
use tokio::time::{timeout, Duration};

const READ_TIMEOUT: Duration = Duration::from_secs(1);
// Key events must start at the highest SimConnect priority, rather than an
// uncreated notification group or MSFS's own default-priority group.
const EVENT_PRIORITY_HIGHEST: u32 = 1;

#[derive(Deserialize)]
#[serde(tag = "operation", rename_all = "snake_case")]
enum Request {
    Probe { address: String },
    KeyEvent { address: String, event: String, parameter: Option<i32> },
    ListInputEvents { address: String },
    SetInputEvent { address: String, hash: u64, value: f64 },
    ReadSimvar { address: String, simvar: String, unit: Option<String>, index: Option<u32>, data_type: Option<String> },
    SetSimvar { address: String, simvar: String, unit: Option<String>, index: Option<u32>, data_type: Option<String>, value: Value },
}

#[derive(Serialize)]
struct Response {
    ok: bool,
    error: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    value: Option<Value>,
}

fn address_parts(address: &str) -> Result<(&str, u16), String> {
    address.rsplit_once(':')
        .ok_or_else(|| "SimConnect address must use host:port".to_owned())
        .and_then(|(host, port)| port.parse::<u16>().map(|port| (host, port)).map_err(|_| "SimConnect port must be a number".to_owned()))
}

fn datum_name(simvar: &str, index: Option<u32>) -> String {
    if simvar.contains(':') || index.unwrap_or(0) == 0 {
        simvar.to_owned()
    } else {
        format!("{}:{}", simvar, index.unwrap_or(0))
    }
}

fn datum_type(data_type: Option<&str>) -> DataType {
    match data_type.unwrap_or("number").to_ascii_lowercase().as_str() {
        "boolean" | "bool" | "integer" | "int" => DataType::Int32,
        "string" => DataType::String256,
        _ => DataType::Float64,
    }
}

fn simconnect_unit(unit: Option<&str>) -> Option<String> {
    let raw = unit?.trim();
    if raw.is_empty() || raw == "-" {
        return None;
    }

    // The documentation catalogue contains reader-friendly labels such as
    // "Feet (ft)". SimConnect expects the unit name itself, e.g. "Feet".
    let mut normalized = String::with_capacity(raw.len());
    let mut parentheses_depth = 0;
    for character in raw.chars() {
        match character {
            '(' => parentheses_depth += 1,
            ')' if parentheses_depth > 0 => parentheses_depth -= 1,
            _ if parentheses_depth == 0 => normalized.push(character),
            _ => {}
        }
    }
    let normalized = normalized.split_whitespace().collect::<Vec<_>>().join(" ");
    let lower = normalized.to_ascii_lowercase();
    if lower.starts_with("enum") || lower.starts_with("flags") || lower.starts_with("mask") || lower.starts_with("position") {
        return Some("Number".to_owned());
    }
    if lower.starts_with("string") {
        return Some("String".to_owned());
    }
    // Some catalogue entries include both a readable unit name and the unit
    // token required by SimConnect, for example "Inches of Mercury, inHg".
    // Send the concise token when one is present.
    if let Some((_, token)) = normalized.rsplit_once(',') {
        let token = token.trim();
        if !token.is_empty() && token.chars().all(|character| character.is_ascii_alphanumeric() || character == '/' || character == '%') {
            return Some(token.to_owned());
        }
    }
    Some(normalized)
}

#[derive(Hash, PartialEq, Eq)]
struct DefinitionKey {
    datum_name: String,
    unit: Option<String>,
    data_type: DataType,
}

struct Session {
    address: String,
    sim: SimConnect,
    definitions: HashMap<DefinitionKey, u32>,
    events: HashMap<String, u32>,
    next_definition_id: u32,
    next_request_id: u32,
    next_event_id: u32,
}

impl Session {
    async fn open(address: &str) -> Result<Self, String> {
        let (host, port) = address_parts(address)?;
        let sim = SimConnect::open_tcp("macro-pad-manager-msfs", host, port)
            .await
            .map_err(|error| error.to_string())?;
        Ok(Self {
            address: address.to_owned(),
            sim,
            definitions: HashMap::new(),
            events: HashMap::new(),
            next_definition_id: 100,
            next_request_id: 10_000,
            next_event_id: 1_000,
        })
    }

    fn next_definition_id(&mut self) -> u32 {
        let id = self.next_definition_id;
        self.next_definition_id = self.next_definition_id.saturating_add(1);
        id
    }

    fn next_request_id(&mut self) -> u32 {
        let id = self.next_request_id;
        self.next_request_id = self.next_request_id.saturating_add(1);
        id
    }

    fn next_event_id(&mut self) -> u32 {
        let id = self.next_event_id;
        self.next_event_id = self.next_event_id.saturating_add(1);
        id
    }

    async fn definition_id(
        &mut self,
        simvar: &str,
        unit: Option<&str>,
        index: Option<u32>,
        data_type: DataType,
    ) -> Result<(u32, Option<u32>), String> {
        let key = DefinitionKey {
            datum_name: datum_name(simvar, index),
            unit: simconnect_unit(unit),
            data_type,
        };
        if let Some(define_id) = self.definitions.get(&key) {
            return Ok((*define_id, None));
        }
        let define_id = self.next_definition_id();
        let send_id = self.sim.add_to_data_definition(
            define_id,
            &key.datum_name,
            key.unit.as_deref(),
            key.data_type,
            0.0,
            -1,
        )
        .await
        .map_err(|error| error.to_string())?;
        self.definitions.insert(key, define_id);
        Ok((define_id, Some(send_id)))
    }

    async fn event_id(&mut self, event: &str) -> Result<u32, String> {
        if let Some(event_id) = self.events.get(event) {
            return Ok(*event_id);
        }
        let event_id = self.next_event_id();
        self.sim.map_client_event_to_sim_event(event_id, event)
            .await
            .map_err(|error| error.to_string())?;
        self.events.insert(event.to_owned(), event_id);
        Ok(event_id)
    }
}

#[derive(Default)]
struct SessionManager {
    session: Option<Session>,
}

impl SessionManager {
    async fn session_for(&mut self, address: &str) -> Result<&mut Session, String> {
        let needs_connection = match self.session.as_ref() {
            Some(session) => session.address != address,
            None => true,
        };
        if needs_connection {
            self.session = Some(Session::open(address).await?);
        }
        Ok(self.session.as_mut().expect("session was created"))
    }

    fn invalidate(&mut self) {
        self.session = None;
    }
}

fn decode_value(data: &[u8], data_type: DataType) -> Result<Value, String> {
    match data_type {
        DataType::Int32 => data.get(..4)
            .and_then(|bytes| bytes.try_into().ok())
            .map(|bytes| Value::from(i32::from_le_bytes(bytes)))
            .ok_or_else(|| "SimConnect returned an incomplete integer value".to_owned()),
        DataType::Float64 => data.get(..8)
            .and_then(|bytes| bytes.try_into().ok())
            .map(|bytes| Value::from(f64::from_le_bytes(bytes)))
            .ok_or_else(|| "SimConnect returned an incomplete numeric value".to_owned()),
        DataType::String256 => {
            let end = data.iter().position(|byte| *byte == 0).unwrap_or(data.len());
            Ok(Value::from(String::from_utf8_lossy(&data[..end]).trim().to_owned()))
        }
        _ => Err("Unsupported SimConnect data type".to_owned()),
    }
}

fn encode_value(value: Value, data_type: DataType) -> Result<Vec<u8>, String> {
    match data_type {
        DataType::Int32 => {
            let number = value.as_i64().or_else(|| value.as_bool().map(|item| if item { 1 } else { 0 }))
                .ok_or_else(|| "This SimVar needs a whole-number value".to_owned())?;
            Ok((number as i32).to_le_bytes().to_vec())
        }
        DataType::Float64 => value.as_f64()
            .map(|number| number.to_le_bytes().to_vec())
            .ok_or_else(|| "This SimVar needs a numeric value".to_owned()),
        DataType::String256 => {
            let text = value.as_str().ok_or_else(|| "This SimVar needs text".to_owned())?;
            let mut bytes = vec![0; 256];
            let raw = text.as_bytes();
            let length = raw.len().min(255);
            bytes[..length].copy_from_slice(&raw[..length]);
            Ok(bytes)
        }
        _ => Err("Unsupported SimConnect data type".to_owned()),
    }
}

async fn handle(sessions: &mut SessionManager, request: Request) -> Result<Option<Value>, String> {
    match request {
        Request::Probe { address } => {
            sessions.session_for(&address).await?;
            Ok(None)
        }
        Request::KeyEvent { address, event, parameter } => {
            let session = sessions.session_for(&address).await?;
            let event_id = session.event_id(&event).await?;
            session.sim.transmit_client_event(
                0,
                event_id,
                parameter.unwrap_or(0),
                EVENT_PRIORITY_HIGHEST,
                EventFlags::GROUP_ID_IS_PRIORITY,
            )
                .await
                .map_err(|error| error.to_string())?;
            Ok(None)
        }
        Request::ListInputEvents { address } => {
            let session = sessions.session_for(&address).await?;
            let request_id = session.next_request_id();
            let send_id = session.sim.enumerate_input_events(request_id).await
                .map_err(|error| error.to_string())?;
            let mut events = Vec::new();
            loop {
                let packet = timeout(READ_TIMEOUT, session.sim.recv_ref()).await
                    .map_err(|_| "Timed out while listing aircraft input events".to_owned())?
                    .map_err(|error| error.to_string())?;
                let mut reader = PacketReader::new(&packet);
                let header = reader.header().map_err(|error| error.to_string())?;
                if header.id == RecvId::EnumerateInputEvents as u32 {
                    let page = recv::kittyhawk::parse_enumerate_input_events(&mut reader)
                        .map_err(|error| error.to_string())?;
                    if page.list.request_id != request_id {
                        continue;
                    }
                    events.extend(page.entries.into_iter().map(|entry| serde_json::json!({
                        "name": entry.name,
                        "hash": entry.hash,
                        "event_type": entry.event_type,
                    })));
                    if page.list.out_of == 0 || page.list.entry_number.saturating_add(1) >= page.list.out_of {
                        return Ok(Some(Value::Array(events)));
                    }
                }
                if header.id == RecvId::Exception as u32 {
                    let exception = recv::parse_exception(&mut reader).map_err(|error| error.to_string())?;
                    if exception.matches(send_id) {
                        return Err(format!("SimConnect rejected aircraft input-event discovery: {exception:?}"));
                    }
                }
            }
        }
        Request::SetInputEvent { address, hash, value } => {
            let session = sessions.session_for(&address).await?;
            session.sim.set_input_event(hash, &value.to_le_bytes()).await
                .map_err(|error| error.to_string())?;
            Ok(None)
        }
        Request::ReadSimvar { address, simvar, unit, index, data_type } => {
            let data_type = datum_type(data_type.as_deref());
            let session = sessions.session_for(&address).await?;
            let (define_id, definition_send_id) = session.definition_id(&simvar, unit.as_deref(), index, data_type).await?;
            let request_id = session.next_request_id();
            let request_send_id = session.sim.request_data_on_sim_object(
                request_id,
                define_id,
                0,
                Period::Once,
                DataRequestFlags::empty(),
                0,
                0,
                0,
            )
                .await
                .map_err(|error| error.to_string())?;
            loop {
                let packet = timeout(READ_TIMEOUT, session.sim.recv_ref()).await
                    .map_err(|_| format!("Timed out waiting for {simvar} from SimConnect"))?
                    .map_err(|error| error.to_string())?;
                let mut reader = PacketReader::new(&packet);
                let header = reader.header().map_err(|error| error.to_string())?;
                if header.id == RecvId::SimObjectData as u32 {
                    let data = recv::parse_sim_object_data(&mut reader).map_err(|error| error.to_string())?;
                    if data.request_id == request_id {
                        return decode_value(data.data, data_type).map(Some);
                    }
                }
                if header.id == RecvId::Exception as u32 {
                    let exception = recv::parse_exception(&mut reader).map_err(|error| error.to_string())?;
                    if exception.matches(request_send_id)
                        || definition_send_id.map(|send_id| exception.matches(send_id)).unwrap_or(false)
                    {
                        return Err(format!("SimConnect rejected {simvar}: {exception:?}"));
                    }
                }
            }
        }
        Request::SetSimvar { address, simvar, unit, index, data_type, value } => {
            let data_type = datum_type(data_type.as_deref());
            let session = sessions.session_for(&address).await?;
            let (define_id, _) = session.definition_id(&simvar, unit.as_deref(), index, data_type).await?;
            let bytes = encode_value(value, data_type)?;
            session.sim.set_data_on_sim_object(define_id, 0, DataSetFlags::empty(), 0, bytes.len() as u32, &bytes)
                .await
                .map_err(|error| error.to_string())?;
            Ok(None)
        }
    }
}

#[tokio::main(flavor = "current_thread")]
async fn main() {
    let mut sessions = SessionManager::default();
    for line in io::stdin().lock().lines() {
        let response = match line {
            Ok(line) => match serde_json::from_str::<Request>(&line) {
                Ok(request) => match handle(&mut sessions, request).await {
                    Ok(value) => Response { ok: true, error: None, value },
                    Err(error) => {
                        // A failed read or write can leave a TCP SimConnect session stale.
                        // The next request will open a clean session instead of queueing behind it.
                        sessions.invalidate();
                        Response { ok: false, error: Some(error), value: None }
                    }
                },
                Err(error) => Response { ok: false, error: Some(error.to_string()), value: None },
            },
            Err(error) => Response { ok: false, error: Some(error.to_string()), value: None },
        };
        println!("{}", serde_json::to_string(&response).expect("response is serializable"));
    }
}

#[cfg(test)]
mod tests {
    use super::simconnect_unit;

    #[test]
    fn normalizes_documentation_unit_labels_for_simconnect() {
        assert_eq!(simconnect_unit(Some("Feet (ft)")), Some("Feet".to_owned()));
        assert_eq!(simconnect_unit(Some("Feet (ft) per second")), Some("Feet per second".to_owned()));
        assert_eq!(simconnect_unit(Some("Inches of Mercury, inHg")), Some("inHg".to_owned()));
        assert_eq!(simconnect_unit(Some("Pounds per square foot, psf")), Some("psf".to_owned()));
    }

    #[test]
    fn maps_documentation_enum_labels_to_a_numeric_unit() {
        assert_eq!(simconnect_unit(Some("Enum: 0 = Off 1 = On")), Some("Number".to_owned()));
    }
}
