# Third-party notices

The optional native helper uses
[`flybywireless-simconnect`](https://crates.io/crates/flybywireless-simconnect)
version `0.1.5`, licensed under the MIT License. The dependency is linked as a
separate Rust crate and retains its own license terms.
