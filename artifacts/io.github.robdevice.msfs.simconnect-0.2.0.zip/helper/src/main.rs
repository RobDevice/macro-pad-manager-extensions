use std::io::{self, BufRead};

use serde::{Deserialize, Serialize};
use simconnect::proto::enums::EventFlags;
use simconnect::SimConnect;

#[derive(Deserialize)]
#[serde(tag = "operation", rename_all = "snake_case")]
enum Request {
    Probe { address: String },
    KeyEvent { address: String, event: String, parameter: Option<i32> },
}

#[derive(Serialize)]
struct Response {
    ok: bool,
    error: Option<String>,
}

fn address_parts(address: &str) -> Result<(&str, u16), String> {
    address.rsplit_once(':')
        .ok_or_else(|| "SimConnect address must use host:port".to_owned())
        .and_then(|(host, port)| port.parse::<u16>().map(|port| (host, port)).map_err(|_| "SimConnect port must be a number".to_owned()))
}

async fn handle(request: Request) -> Result<(), String> {
    match request {
        Request::Probe { address } => {
            let (host, port) = address_parts(&address)?;
            SimConnect::open_tcp("macro-pad-manager-msfs", host, port)
                .await
                .map_err(|error| error.to_string())?;
        }
        Request::KeyEvent { address, event, parameter } => {
            let (host, port) = address_parts(&address)?;
            let sim = SimConnect::open_tcp("macro-pad-manager-msfs", host, port)
                .await
                .map_err(|error| error.to_string())?;
            const EVENT_ID: u32 = 1;
            sim.map_client_event_to_sim_event(EVENT_ID, &event)
                .await
                .map_err(|error| error.to_string())?;
            sim.transmit_client_event(0, EVENT_ID, parameter.unwrap_or(0), 0, EventFlags::empty())
                .await
                .map_err(|error| error.to_string())?;
        }
    }
    Ok(())
}

#[tokio::main(flavor = "current_thread")]
async fn main() {
    for line in io::stdin().lock().lines() {
        let response = match line {
            Ok(line) => match serde_json::from_str::<Request>(&line) {
                Ok(request) => match handle(request).await {
                    Ok(()) => Response { ok: true, error: None },
                    Err(error) => Response { ok: false, error: Some(error) },
                },
                Err(error) => Response { ok: false, error: Some(error.to_string()) },
            },
            Err(error) => Response { ok: false, error: Some(error.to_string()) },
        };
        println!("{}", serde_json::to_string(&response).expect("response is serializable"));
    }
}
