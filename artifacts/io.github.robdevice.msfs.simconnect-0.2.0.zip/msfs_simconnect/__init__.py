from __future__ import annotations

import copy
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def _catalogue(name: str) -> list[dict]:
    path = ROOT / "catalogue" / name
    if not path.exists():
        return []
    return json.loads(path.read_text(encoding="utf-8"))


class Plugin:
    """Expose standard MSFS 2020 data and commands to the shared registries."""

    def settings_schema(self) -> dict:
        return {
            "properties": {
                "address": {
                    "type": "string",
                    "title": "SimConnect address",
                    "description": "Host and TCP port exposed by SimConnect.",
                    "default": "127.0.0.1:500",
                }
            }
        }

    def inputs(self) -> list[dict]:
        inputs: list[dict] = []
        for entry in _catalogue("simvars.json"):
            item = {
                "id": f"simvar.{entry['slug']}",
                "name": entry["name"],
                "description": entry["description"],
                "group": entry["group"],
                "unit": entry["unit"],
                "data_type": entry["data_type"],
                "indexable": entry["indexable"],
                "simvar": entry["name"],
            }
            if entry["indexable"]:
                item["settings_schema"] = {
                    "properties": {"index": {"type": "integer", "title": "Index", "default": 1}}
                }
            inputs.append(item)
        return inputs

    def actions(self) -> list[dict]:
        actions: list[dict] = []
        for entry in _catalogue("key_events.json"):
            actions.append(
                {
                    "id": f"key_event.{entry['slug']}",
                    "name": entry["name"],
                    "description": entry["description"],
                    "group": entry["group"],
                    "key_event": entry["name"],
                    "settings_schema": {
                        "properties": {
                            "parameter": {
                                "type": "integer",
                                "title": "Parameter",
                                "description": entry["parameters"] or "SimConnect event parameter.",
                                "default": 0,
                            }
                        }
                    },
                }
            )
        for entry in _catalogue("simvars.json"):
            if not entry["settable"]:
                continue
            actions.append(
                {
                    "id": f"set_simvar.{entry['slug']}",
                    "name": f"Set {entry['name']}",
                    "description": f"Write {entry['name']} through SimConnect.",
                    "group": f"Set SimVars / {entry['group']}",
                    "simvar": entry["name"],
                    "unit": entry["unit"],
                    "settings_schema": {
                        "properties": {
                            "value": {"type": entry["data_type"], "title": "Value"},
                            **({"index": {"type": "integer", "title": "Index", "default": 1}} if entry["indexable"] else {}),
                        }
                    },
                }
            )
        actions.append(
            {
                "id": "advanced_simvar_output",
                "name": "Advanced SimVar Output",
                "description": "Write a custom documented SimVar through SimConnect.",
                "group": "Advanced",
                "settings_schema": {
                    "properties": {
                        "simvar": {"type": "string", "title": "Simulation Variable"},
                        "unit": {"type": "string", "title": "Unit"},
                        "value": {"type": "number", "title": "Value"},
                        "index": {"type": "integer", "title": "Index", "default": 0},
                    }
                },
            }
        )
        return actions

    def connection_status(self, settings: dict | None = None) -> dict:
        # The daemon launches the helper. The browser only reports its configured target.
        address = str((settings or {}).get("address") or "127.0.0.1:500")
        return {"address": address, "state": "not_checked"}

    def copy_input(self, identifier: str) -> dict | None:
        return next((copy.deepcopy(item) for item in self.inputs() if item["id"] == identifier), None)
