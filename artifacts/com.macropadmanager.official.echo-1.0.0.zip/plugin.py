class Plugin:
    def modules(self):
        return [
            {
                "id": "com.macropadmanager.official.echo.say",
                "name": "Echo Type Text",
                "group": "Official Samples",
                "description": "Types configured text through the virtual keyboard.",
                "requires": ["press"],
                "default_settings": {"text": "Hello from the official catalogue"},
                "default_visual": {
                    "background": "#0f172a",
                    "foreground": "#ffffff",
                    "text": "ECHO",
                    "icon": None,
                },
                "settings_schema": {
                    "type": "object",
                    "properties": {
                        "text": {"type": "string", "title": "Text"}
                    }
                }
            }
        ]

    def execute_module(self, module_payload, event, context):
        if event.get("trigger_id") != "press":
            return
        context.type_text(module_payload.get("settings", {}).get("text", ""))
