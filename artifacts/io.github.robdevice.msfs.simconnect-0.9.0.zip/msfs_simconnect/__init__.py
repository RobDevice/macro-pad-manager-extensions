from __future__ import annotations

import copy
import json
import os
from pathlib import Path
import platform
import stat
import subprocess
import threading


ROOT = Path(__file__).resolve().parents[1]


DIAL_CONTROLS: dict[str, dict[str, str]] = {
    "Autopilot Altitude": {"left": "AP_ALT_VAR_DEC", "right": "AP_ALT_VAR_INC"},
    "Heading Bug": {"left": "HEADING_BUG_DEC", "right": "HEADING_BUG_INC", "press": "heading_sync"},
    "Autopilot Vertical Speed": {"left": "AP_VS_VAR_DEC", "right": "AP_VS_VAR_INC"},
    "Autopilot Airspeed": {"left": "AP_SPD_VAR_DEC", "right": "AP_SPD_VAR_INC"},
    "COM 1 Fine Frequency": {"left": "COM1_RADIO_FRACT_DEC", "right": "COM1_RADIO_FRACT_INC"},
    "COM 1 Coarse Frequency": {"left": "COM1_RADIO_WHOLE_DEC", "right": "COM1_RADIO_WHOLE_INC"},
    "COM 2 Fine Frequency": {"left": "COM2_RADIO_FRACT_DEC", "right": "COM2_RADIO_FRACT_INC"},
    "COM 2 Coarse Frequency": {"left": "COM2_RADIO_WHOLE_DEC", "right": "COM2_RADIO_WHOLE_INC"},
    "NAV 1 Fine Frequency": {"left": "NAV1_RADIO_FRACT_DEC", "right": "NAV1_RADIO_FRACT_INC"},
    "NAV 1 Coarse Frequency": {"left": "NAV1_RADIO_WHOLE_DEC", "right": "NAV1_RADIO_WHOLE_INC"},
    "NAV 2 Fine Frequency": {"left": "NAV2_RADIO_FRACT_DEC", "right": "NAV2_RADIO_FRACT_INC"},
    "NAV 2 Coarse Frequency": {"left": "NAV2_RADIO_WHOLE_DEC", "right": "NAV2_RADIO_WHOLE_INC"},
    "NAV 1 Course": {"left": "VOR1_OBI_DEC", "right": "VOR1_OBI_INC"},
    "NAV 1 Course (10 degrees)": {"left": "VOR1_OBI_FAST_DEC", "right": "VOR1_OBI_FAST_INC"},
    "NAV 2 Course": {"left": "VOR2_OBI_DEC", "right": "VOR2_OBI_INC"},
    "NAV 2 Course (10 degrees)": {"left": "VOR2_OBI_FAST_DEC", "right": "VOR2_OBI_FAST_INC"},
    "Transponder Digit 1": {"left": "XPNDR_1000_DEC", "right": "XPNDR_1000_INC"},
    "Transponder Digit 2": {"left": "XPNDR_100_DEC", "right": "XPNDR_100_INC"},
    "Transponder Digit 3": {"left": "XPNDR_10_DEC", "right": "XPNDR_10_INC"},
    "Transponder Digit 4": {"left": "XPNDR_1_DEC", "right": "XPNDR_1_INC"},
    "Altimeter Pressure": {"left": "KOHLSMAN_DEC", "right": "KOHLSMAN_INC"},
    "G1000 PFD Page": {"left": "G1000_PFD_PAGE_KNOB_DEC", "right": "G1000_PFD_PAGE_KNOB_INC", "press": "G1000_PFD_CURSOR_BUTTON"},
    "G1000 PFD Page Group": {"left": "G1000_PFD_GROUP_KNOB_DEC", "right": "G1000_PFD_GROUP_KNOB_INC", "press": "G1000_PFD_CURSOR_BUTTON"},
}


class _HelperBridge:
    """Keep the helper process alive while a profile polls SimConnect values."""

    def __init__(self) -> None:
        self._process: subprocess.Popen[str] | None = None
        self._lock = threading.Lock()

    def request(self, helper: Path, payload: dict) -> dict:
        with self._lock:
            if self._process is None or self._process.poll() is not None:
                self._process = subprocess.Popen(
                    [str(helper)], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                    text=True, bufsize=1,
                )
            if self._process.stdin is None or self._process.stdout is None:
                return {"ok": False, "error": "SimConnect helper streams are unavailable"}
            try:
                self._process.stdin.write(json.dumps(payload) + "\n")
                self._process.stdin.flush()
                line = self._process.stdout.readline()
                return json.loads(line or "{}")
            except (OSError, ValueError, json.JSONDecodeError) as error:
                self._process = None
                return {"ok": False, "error": str(error)}


def _catalogue(name: str) -> list[dict]:
    path = ROOT / "catalogue" / name
    if not path.exists():
        return []
    return json.loads(path.read_text(encoding="utf-8"))


class Plugin:
    """Expose standard MSFS 2020 data and commands to the shared registries."""

    def settings_schema(self) -> dict:
        return {
            "properties": {
                "address": {
                    "type": "string",
                    "title": "SimConnect address",
                    "description": "Host and TCP port exposed by SimConnect.",
                    "default": "127.0.0.1:500",
                }
            }
        }

    def __init__(self) -> None:
        self._bridge = _HelperBridge()

    def modules(self) -> list[dict]:
        return [
            {
                "id": "msfs.cockpit_dial",
                "name": "MSFS Cockpit Dial",
                "group": "Cockpit Controls",
                "description": "Configure a dial for common MSFS cockpit controls through standard SimConnect events.",
                "requires": ["rotary_left", "rotary_right", "press"],
                "default_settings": {"control": "Autopilot Altitude"},
                "settings_schema": {
                    "properties": {
                        "control": {
                            "type": "string",
                            "title": "Control",
                            "description": "The cockpit rotary control this dial represents.",
                            "enum": list(DIAL_CONTROLS),
                            "default": "Autopilot Altitude",
                        }
                    }
                },
            }
        ]

    @staticmethod
    def _helper() -> Path:
        return ROOT / "runtime" / f"{platform.system().lower()}-{platform.machine()}" / "macro-pad-manager-msfs-helper"

    @staticmethod
    def _address(settings: dict | None) -> str:
        return str((settings or {}).get("address") or "127.0.0.1:500")

    def _request(self, payload: dict) -> dict:
        helper = self._helper()
        if not helper.exists():
            return {"ok": False, "error": "SimConnect helper is unavailable on this platform"}
        if not os.access(helper, os.X_OK):
            return {"ok": False, "error": "The SimConnect helper is not allowed to run. Repair helper permissions in Extension Settings."}
        return self._bridge.request(helper, payload)

    def inputs(self) -> list[dict]:
        inputs: list[dict] = []
        for entry in _catalogue("simvars.json"):
            item = {
                "id": f"simvar.{entry['slug']}",
                "name": entry["name"],
                "description": entry["description"],
                "group": entry["group"],
                "unit": entry["unit"],
                "data_type": entry["data_type"],
                "indexable": entry["indexable"],
                "simvar": entry["name"],
            }
            properties: dict[str, dict] = {}
            if entry["indexable"]:
                properties["index"] = {"type": "integer", "title": "Index", "default": 1}
            if entry["data_type"] == "number":
                properties["decimal_places"] = {
                    "type": "integer",
                    "title": "Decimal places",
                    "description": "Number of digits to show after the decimal point.",
                    "default": self._default_decimal_places(entry),
                }
            if properties:
                item["settings_schema"] = {"properties": properties}
            inputs.append(item)
        return inputs

    @staticmethod
    def _default_decimal_places(entry: dict) -> int:
        name = str(entry.get("name", "")).lower()
        if "altitude" in name:
            return 0
        return 2

    @staticmethod
    def _format_readout_value(value, decimal_places: object) -> object:
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            return value
        try:
            places = max(0, min(6, int(decimal_places)))
        except (TypeError, ValueError):
            places = 2
        if places == 0:
            return str(int(round(value)))
        return f"{value:.{places}f}".rstrip("0").rstrip(".")

    def actions(self) -> list[dict]:
        actions: list[dict] = []
        for entry in _catalogue("key_events.json"):
            actions.append(
                {
                    "id": f"key_event.{entry['slug']}",
                    "name": entry["name"],
                    "description": entry["description"],
                    "group": entry["group"],
                    "key_event": entry["name"],
                    "settings_schema": {
                        "properties": {
                            "parameter": {
                                "type": "integer",
                                "title": "Parameter",
                                "description": entry["parameters"] or "SimConnect event parameter.",
                                "default": 0,
                            }
                        }
                    },
                }
            )
        for entry in _catalogue("simvars.json"):
            if not entry["settable"]:
                continue
            actions.append(
                {
                    "id": f"set_simvar.{entry['slug']}",
                    "name": f"Set {entry['name']}",
                    "description": f"Write {entry['name']} through SimConnect.",
                    "group": f"Set SimVars / {entry['group']}",
                    "simvar": entry["name"],
                    "unit": entry["unit"],
                    "data_type": entry["data_type"],
                    "settings_schema": {
                        "properties": {
                            "value": {"type": entry["data_type"], "title": "Value"},
                            **({"index": {"type": "integer", "title": "Index", "default": 1}} if entry["indexable"] else {}),
                        }
                    },
                }
            )
        actions.append(
            {
                "id": "advanced_simvar_output",
                "name": "Advanced SimVar Output",
                "description": "Write a custom documented SimVar through SimConnect.",
                "group": "Advanced",
                "settings_schema": {
                    "properties": {
                        "simvar": {"type": "string", "title": "Simulation Variable"},
                        "unit": {"type": "string", "title": "Unit"},
                        "value": {"type": "number", "title": "Value"},
                        "index": {"type": "integer", "title": "Index", "default": 0},
                    }
                },
            }
        )
        return actions

    def connection_status(self, settings: dict | None = None) -> dict:
        address = self._address(settings)
        helper = self._helper()
        if not helper.exists():
            return {"address": address, "state": "unsupported_platform"}
        if not os.access(helper, os.X_OK):
            return {
                "address": address,
                "state": "helper_not_executable",
                "error": "The SimConnect helper was installed without permission to run.",
                "remediation": "Repair helper permissions, then test the connection again.",
                "repairable": True,
                "repair_label": "Repair Helper Permissions",
            }
        try:
            response = self._request({"operation": "probe", "address": address})
            if response.get("ok"):
                return {
                    "address": address,
                    "state": "connected",
                    "message": "SimConnect accepted a connection at this address.",
                }
            return self._connection_failure(address, str(response.get("error") or "SimConnect did not return a response"))
        except (OSError, subprocess.SubprocessError, json.JSONDecodeError) as error:
            return self._connection_failure(address, str(error))

    @staticmethod
    def _connection_failure(address: str, error: str) -> dict:
        normalized_error = error.casefold()
        result = {"address": address, "state": "unavailable", "error": error}
        if "connection refused" in normalized_error:
            result.update(
                {
                    "message": f"No SimConnect service is listening at {address}.",
                    "remediation": (
                        "Start MSFS and the SimConnect TCP listener, or change the address to the endpoint "
                        "that MSFS is exposing. The extension cannot start SimConnect itself."
                    ),
                }
            )
        elif "timed out" in normalized_error:
            result.update(
                {
                    "message": f"SimConnect at {address} did not respond in time.",
                    "remediation": "Confirm that MSFS is running and that the configured host and port are reachable from this computer.",
                }
            )
        else:
            result.update(
                {
                    "message": f"SimConnect could not be reached at {address}.",
                    "remediation": "Check that MSFS is running and that the configured host and port are correct, then test again.",
                }
            )
        return result

    def repair_connection(self, settings: dict | None = None) -> dict:
        """Restore user execute permission on the packaged native helper."""
        helper = self._helper()
        if not helper.exists():
            return {"ok": False, "error": "SimConnect helper is unavailable on this platform"}
        try:
            helper.chmod(helper.stat().st_mode | stat.S_IXUSR)
        except OSError as error:
            return {"ok": False, "error": f"Could not repair helper permissions: {error}"}
        return {"ok": True, "message": "Helper permissions repaired"}

    def read_input(self, input_definition: dict, input_settings: dict | None = None, extension_settings: dict | None = None) -> dict:
        input_settings = input_settings or {}
        response = self._request(
            {
                "operation": "read_simvar",
                "address": self._address(extension_settings),
                "simvar": input_definition.get("simvar", ""),
                "unit": input_definition.get("unit") or None,
                "index": input_settings.get("index"),
                "data_type": input_definition.get("data_type", "number"),
            }
        )
        if not response.get("ok"):
            raise RuntimeError(str(response.get("error") or "SimConnect read failed"))
        return {
            "value": self._format_readout_value(
                response.get("value", "--"),
                input_settings.get("decimal_places", self._default_decimal_places(input_definition)),
            ),
            "unit": input_definition.get("unit", ""),
        }

    def execute_action(
        self,
        action: dict,
        action_settings: dict | None = None,
        extension_settings: dict | None = None,
    ) -> dict:
        """Run a documented Key Event or writable SimVar through SimConnect."""
        action_settings = action_settings or {}
        address = self._address(extension_settings)
        event = str(action.get("key_event") or "").strip()
        if event:
            return self._request({"operation": "key_event", "address": address, "event": event, "parameter": action_settings.get("parameter", 0)})
        simvar = str(action_settings.get("simvar") or action.get("simvar") or "").strip()
        if not simvar:
            return {"ok": False, "error": "No SimVar was selected"}
        return self._request(
            {
                "operation": "set_simvar",
                "address": address,
                "simvar": simvar,
                "unit": action_settings.get("unit") or action.get("unit") or None,
                "index": action_settings.get("index"),
                "data_type": action.get("data_type", "number"),
                "value": action_settings.get("value", 0),
            }
        )

    def execute_module(
        self,
        module_payload: dict,
        event: dict,
        _context,
        extension_settings: dict | None = None,
    ) -> None:
        """Handle the fixed, real-world control mappings exposed by MSFS Cockpit Dial."""
        if str(module_payload.get("type", "")) != "msfs.cockpit_dial":
            raise RuntimeError(f"Unsupported MSFS module: {module_payload.get('type', '')}")
        control = str(module_payload.get("settings", {}).get("control") or "Autopilot Altitude")
        mapping = DIAL_CONTROLS.get(control)
        if mapping is None:
            raise RuntimeError(f"Unsupported MSFS cockpit dial control: {control}")
        trigger = str(event.get("trigger_id", ""))
        address = self._address(extension_settings)
        if trigger == "press" and mapping.get("press") == "heading_sync":
            heading = self._read_magnetic_heading(address)
            self._send_key_event(address, "HEADING_BUG_SET", heading)
            return
        key_event = mapping.get(trigger)
        if key_event:
            self._send_key_event(address, key_event)

    def _read_magnetic_heading(self, address: str) -> int:
        response = self._request(
            {
                "operation": "read_simvar",
                "address": address,
                "simvar": "PLANE HEADING DEGREES MAGNETIC",
                "unit": "Degrees",
                "index": None,
                "data_type": "number",
            }
        )
        if not response.get("ok"):
            raise RuntimeError(str(response.get("error") or "Could not read the current magnetic heading"))
        try:
            return int(round(float(response.get("value")))) % 360
        except (TypeError, ValueError) as error:
            raise RuntimeError("SimConnect returned an invalid magnetic heading") from error

    def _send_key_event(self, address: str, event: str, parameter: int = 0) -> None:
        response = self._request(
            {"operation": "key_event", "address": address, "event": event, "parameter": parameter}
        )
        if not response.get("ok"):
            raise RuntimeError(str(response.get("error") or f"SimConnect rejected {event}"))

    def copy_input(self, identifier: str) -> dict | None:
        return next((copy.deepcopy(item) for item in self.inputs() if item["id"] == identifier), None)
