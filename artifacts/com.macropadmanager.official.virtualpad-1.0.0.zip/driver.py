from macro_pad_manager.core.layout import Bounds, ControlDefinition, DeviceLayout
from macro_pad_manager.daemon.drivers.base import Driver, DriverManifest


class Driver(Driver):
    manifest = DriverManifest(
        schema_version=1,
        type="driver",
        id="com.macropadmanager.official.virtualpad",
        name="Official Virtual Pad Driver",
        version="1.0.0",
        author="Macro Pad Manager",
        licence="MIT",
        description="Sample curated driver that demonstrates catalogue packaging without targeting real hardware.",
        min_app_version="0.1.0",
    )

    def detect(self):
        return None

    def layout(self):
        return DeviceLayout(
            driver_id=self.manifest.id,
            device_name="Official Virtual Pad",
            preview_width=160,
            preview_height=80,
            controls=[
                ControlDefinition(
                    id="button_1",
                    label="Button 1",
                    kind="button",
                    bounds=Bounds(x=12, y=12, width=56, height=56),
                    triggers=["press", "release"],
                    capabilities=["press", "release"],
                    runtime_ids={"press": 1, "release": 1},
                ),
                ControlDefinition(
                    id="button_2",
                    label="Button 2",
                    kind="button",
                    bounds=Bounds(x=92, y=12, width=56, height=56),
                    triggers=["press", "release"],
                    capabilities=["press", "release"],
                    runtime_ids={"press": 2, "release": 2},
                ),
            ],
        )

    def resolve_runtime_event(self, event):
        return None
